import sharp from 'sharp';
import { mkdir, rm } from 'node:fs/promises';
import { dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

const __dirname = dirname(fileURLToPath(import.meta.url));
const OUT = resolve(__dirname, '../public/icons');

// Remove all old icons first
await rm(OUT, { recursive: true, force: true });
await mkdir(OUT, { recursive: true });

const BLACK = '#000000';
const WHITE = '#ffffff';

/*
 * UNITY mark — "The Cradle"
 *
 * A geometric U formed by two straight vertical arms connected by a
 * prominent semicircular arc at the bottom. The arc dominates the
 * silhouette, giving the mark a cradle/containment quality that
 * communicates unity, protection, and convergence.
 *
 * No bridge line. No extra elements. Single continuous stroke.
 * Perfectly symmetric. Uniform stroke width. Round line caps.
 *
 * Proportions (viewBox 0 0 S S):
 *   armX     = S * 0.3125  (left arm x-position)
 *   armGap   = S * 0.375   (half-width between arms)
 *   topY     = S * 0.22    (top of arms)
 *   arcCY    = S * 0.55    (arc centre y — arms end here)
 *   arcR     = armGap      (perfect semicircle)
 *   strokeW  = S * 0.13    (uniform stroke)
 */
function markU(S, opts = {}) {
  const { strokeScale = 1 } = opts;
  const cx = S / 2;
  const armGap = S * 0.375;
  const leftX = cx - armGap;
  const rightX = cx + armGap;
  const topY = S * 0.22;
  const arcCY = S * 0.55;
  const arcR = armGap;
  const strokeW = S * 0.13 * strokeScale;

  return `<path d="M ${leftX} ${topY} L ${leftX} ${arcCY} A ${arcR} ${arcR} 0 0 0 ${rightX} ${arcCY} L ${rightX} ${topY}"
    stroke="${WHITE}" stroke-width="${strokeW}" stroke-linecap="round" stroke-linejoin="round" fill="none"/>`;
}

function svgDoc(S, inner, bg = BLACK, rx = S * 0.22) {
  return `<svg xmlns="http://www.w3.org/2000/svg" width="${S}" height="${S}" viewBox="0 0 ${S} ${S}" shape-rendering="geometricPrecision">
    <rect width="${S}" height="${S}" fill="${bg}" rx="${rx}"/>
    <g>${inner}</g>
  </svg>`;
}

function svgFg(S, inner) {
  return `<svg xmlns="http://www.w3.org/2000/svg" width="${S}" height="${S}" viewBox="0 0 ${S} ${S}" shape-rendering="geometricPrecision">${inner}</svg>`;
}

async function png(name, S, inner, { bg = BLACK, transparent = false, rx } = {}) {
  const svg = transparent ? svgFg(S, inner) : svgDoc(S, inner, bg, rx);
  await sharp(Buffer.from(svg)).png().toFile(resolve(OUT, name));
  console.log('  wrote', name, `${S}x${S}`);
}

// Maskable: mark scaled into central 66% safe zone, full-bleed bg
function maskableInner(S) {
  const sub = S * 0.6;
  return `<g transform="translate(${(S - sub) / 2}, ${(S - sub) / 2})">${markU(sub)}</g>`;
}
// Adaptive foreground: mark within central 50%
function adaptiveInner(S) {
  const sub = S * 0.5;
  return `<g transform="translate(${(S - sub) / 2}, ${(S - sub) / 2})">${markU(sub)}</g>`;
}

console.log('Generating UNITY icon pack ->', OUT);

// --- Core app + PWA icons ---
await png('app-icon-1024.png', 1024, markU(1024));
await png('icon-512.png', 512, markU(512));
await png('icon-192.png', 192, markU(192));
await png('apple-touch-icon.png', 180, markU(180));
await png('favicon-32.png', 32, markU(32, { strokeScale: 1.3 }));
await png('favicon-16.png', 16, markU(16, { strokeScale: 1.5 }));

// --- Maskable icons (safe-zone padding) ---
await png('maskable-icon-512.png', 512, maskableInner(512));
await png('maskable-icon-192.png', 192, maskableInner(192));

// --- Adaptive icon foreground (transparent bg) ---
await png('adaptive-icon.png', 432, adaptiveInner(432), { transparent: true });

// --- Android legacy + notification icons ---
await png('icon-144.png', 144, markU(144));
await png('icon-96.png', 96, markU(96));
await png('icon-72.png', 72, markU(72));
await png('icon-64.png', 64, markU(64));
await png('icon-48.png', 48, markU(48, { strokeScale: 1.2 }));
await png('icon-36.png', 36, markU(36, { strokeScale: 1.4 }));

// --- Monochrome icon (for Android 13+ themed icons) ---
await png('monochrome-icon-512.png', 512, markU(512));

// --- Splash assets ---
function splashInner(W, H) {
  const cx = W / 2;
  const markS = Math.min(W, H) * 0.2;
  const markY = H * 0.38;
  const mark = markU(markS);
  const markGroup = `<g transform="translate(${cx - markS / 2}, ${markY - markS / 2})">${mark}</g>`;
  const titleY = markY + markS / 2 + Math.min(W, H) * 0.07;
  const subY = titleY + Math.min(W, H) * 0.035;
  const titleSize = Math.min(W, H) * 0.055;
  const subSize = Math.min(W, H) * 0.018;
  return `${markGroup}
    <text x="${cx}" y="${titleY}" font-family="Inter, -apple-system, system-ui, sans-serif" font-weight="600" font-size="${titleSize.toFixed(1)}" fill="${WHITE}" text-anchor="middle" letter-spacing="2">UNITY</text>
    <text x="${cx}" y="${subY}" font-family="Inter, -apple-system, system-ui, sans-serif" font-weight="400" font-size="${subSize.toFixed(1)}" fill="${WHITE}" fill-opacity="0.45" text-anchor="middle" letter-spacing="${(subSize * 2.2).toFixed(1)}">GLOBAL CIVILIZATION</text>
  `;
}
function splashSvg(W, H) {
  return `<svg xmlns="http://www.w3.org/2000/svg" width="${W}" height="${H}" viewBox="0 0 ${W} ${H}" shape-rendering="geometricPrecision">
    <rect width="${W}" height="${H}" fill="${BLACK}"/>
    <g>${splashInner(W, H)}</g>
  </svg>`;
}
async function splash(name, W, H) {
  await sharp(Buffer.from(splashSvg(W, H))).png().toFile(resolve(OUT, name));
  console.log('  wrote', name, `${W}x${H}`);
}

const splashes = [
  ['apple-splash-1170-2532.png', 1170, 2532],
  ['apple-splash-1290-2796.png', 1290, 2796],
  ['apple-splash-1242-2208.png', 1242, 2208],
  ['apple-splash-1536-2048.png', 1536, 2048],
  ['apple-splash-1668-2388.png', 1668, 2388],
  ['apple-splash-2048-2732.png', 2048, 2732],
  ['splash-512.png', 512, 512],
  ['splash-640-1136.png', 640, 1136],
];
for (const [n, w, h] of splashes) await splash(n, w, h);

console.log('Done.');
