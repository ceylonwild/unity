import { Component, type ReactNode } from 'react';

interface Props { children: ReactNode; }
interface State { hasError: boolean; message?: string; }

export class ErrorBoundary extends Component<Props, State> {
  state: State = { hasError: false };

  static getDerivedStateFromError(error: Error): State {
    return { hasError: true, message: error.message };
  }

  componentDidCatch(error: Error) {
    console.error('[UNITY] Runtime error:', error);
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen flex flex-col items-center justify-center gap-4 p-8 text-center bg-unity-bg text-unity-primary">
          <div className="w-16 h-16 rounded-2xl border border-unity-border flex items-center justify-center">
            <span className="text-2xl font-bold tracking-tighter">U</span>
          </div>
          <h1 className="text-xl font-semibold">Something went wrong</h1>
          <p className="text-sm text-unity-muted max-w-sm">{this.state.message ?? 'An unexpected error occurred.'}</p>
          <button
            onClick={() => window.location.reload()}
            className="btn-primary mt-2"
          >
            Reload
          </button>
        </div>
      );
    }
    return this.props.children;
  }
}
