import { useRef, useState, useEffect } from 'react';
import { useSelf } from '@/lib/self';
import { createPost, uploadVideoToStorage, uploadImageToStorage } from '@/lib/feed';
import { Avatar } from '@/components/Avatar';
import { ImageIcon, SendIcon, CloseIcon } from '@/components/icons';
import { fileToImageDataUrl } from '@/lib/image';
import { showToast } from '@/lib/toast';

export function Composer({ onPosted }: { onPosted: () => void }) {
  const { self } = useSelf();
  const [text, setText] = useState('');
  const [mediaUrl, setMediaUrl] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    return () => {
      if (mediaUrl && mediaUrl.startsWith('blob:')) URL.revokeObjectURL(mediaUrl);
    };
  }, [mediaUrl]);

  const onPickMedia = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const isImage = file.type.startsWith('image/');
    const isVideo = file.type.startsWith('video/');

    if (!isImage && !isVideo) {
      showToast('Only images or videos are supported', 'error');
      return;
    }

    const maxSize = isVideo ? 50 * 1024 * 1024 : 8 * 1024 * 1024;
    if (file.size > maxSize) {
      showToast(isVideo ? 'Video must be under 50 MB' : 'Image must be under 8 MB', 'error');
      return;
    }

    try {
      if (mediaUrl && mediaUrl.startsWith('blob:')) URL.revokeObjectURL(mediaUrl);
      if (isImage) {
        const dataUrl = await fileToImageDataUrl(file, 1280);
        setMediaUrl(dataUrl);
      } else {
        setMediaUrl(URL.createObjectURL(file));
      }
    } catch {
      showToast('Could not process that file', 'error');
    }
    if (fileRef.current) fileRef.current.value = '';
  };

  const removeMedia = () => {
    if (mediaUrl && mediaUrl.startsWith('blob:')) URL.revokeObjectURL(mediaUrl);
    setMediaUrl(null);
  };

  const submit = async () => {
    if (!self || !text.trim() || busy) return;
    setBusy(true);
    try {
      let finalMediaUrl = mediaUrl;
      if (mediaUrl && mediaUrl.startsWith('blob:')) {
        const blob = await fetch(mediaUrl).then((r) => r.blob());
        const ext = (blob.type.split('/')[1] || 'mp4').split(';')[0];
        finalMediaUrl = await uploadVideoToStorage(new File([blob], `video.${ext}`, { type: blob.type || 'video/mp4' }));
        URL.revokeObjectURL(mediaUrl);
      } else if (mediaUrl && mediaUrl.startsWith('data:image')) {
        const res = await fetch(mediaUrl);
        const blob = await res.blob();
        const ext = blob.type.split('/')[1]?.split(';')[0] || 'jpeg';
        finalMediaUrl = await uploadImageToStorage(new File([blob], `image.${ext}`, { type: blob.type || 'image/jpeg' }));
      }
      await createPost(self.id, text.trim(), finalMediaUrl);
      setText('');
      setMediaUrl(null);
      onPosted();
      showToast('Published to the feed', 'success');
    } catch {
      showToast('Could not publish', 'error');
    } finally {
      setBusy(false);
    }
  };

  if (!self) return null;

  return (
    <div className="card p-4 animate-fade-up">
      <div className="flex gap-3">
        <Avatar src={self.avatar_url} name={self.name} size={44} verified={self.verified} />
        <div className="flex-1">
          <textarea
            value={text}
            onChange={(e) => setText(e.target.value)}
            placeholder="Share an idea with civilization…"
            rows={text ? 3 : 1}
            className="w-full bg-transparent resize-none outline-none text-[15px] placeholder-white/30 pt-2 transition-all"
          />
          {mediaUrl && (
            <div className="mt-2 relative rounded-xl overflow-hidden border border-[#2a2a2a]/80 group">
              {mediaUrl.startsWith('data:image') ? (
                <img src={mediaUrl} alt="preview" className="w-full max-h-72 object-cover" />
              ) : mediaUrl.startsWith('blob:') ? (
                <video src={mediaUrl} controls className="w-full max-h-72 object-cover" />
              ) : (
                <video src={mediaUrl} controls className="w-full max-h-72 object-cover" />
              )}
              <button
                onClick={removeMedia}
                className="absolute top-2 right-2 w-8 h-8 rounded-full glass-strong flex items-center justify-center hover:bg-white/20 transition-all"
                aria-label="Remove media"
              >
                <CloseIcon size={16} />
              </button>
            </div>
          )}
          <div className="flex items-center justify-between mt-2">
            <button
              onClick={() => fileRef.current?.click()}
              className="btn-icon w-9 h-9"
              aria-label="Add media"
            >
              <ImageIcon size={18} />
            </button>
            <button
              onClick={submit}
              disabled={!text.trim() || busy}
              className="btn-primary disabled:opacity-30 disabled:cursor-not-allowed py-2"
            >
              <SendIcon size={16} />
              Publish
            </button>
          </div>
        </div>
      </div>
      <input
        ref={fileRef}
        type="file"
        accept="image/*,video/*"
        onChange={onPickMedia}
        className="hidden"
      />
    </div>
  );
}
