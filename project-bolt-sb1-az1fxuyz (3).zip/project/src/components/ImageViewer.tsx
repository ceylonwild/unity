import { useEffect, useRef, useState, useCallback } from 'react';
import { CloseIcon } from '@/components/icons';

interface ImageViewerProps {
  src: string;
  onClose: () => void;
}

export function ImageViewer({ src, onClose }: ImageViewerProps) {
  const [scale, setScale] = useState(1);
  const [tx, setTx] = useState(0);
  const [ty, setTy] = useState(0);
  const [loaded, setLoaded] = useState(false);
  const [error, setError] = useState(false);
  const [visible, setVisible] = useState(false);
  const dragStart = useRef<{ x: number; y: number; tx: number; ty: number } | null>(null);
  const pinchStart = useRef<{ d: number; scale: number } | null>(null);
  const closeDragStart = useRef<{ x: number; y: number } | null>(null);
  const [closeDragY, setCloseDragY] = useState(0);

  const animateClose = useCallback(() => {
    setVisible(false);
    setTimeout(onClose, 280);
  }, [onClose]);

  useEffect(() => {
    document.body.style.overflow = 'hidden';
    const t = setTimeout(() => setVisible(true), 10);
    const onKey = (e: KeyboardEvent) => { if (e.key === 'Escape') animateClose(); };
    window.addEventListener('keydown', onKey);
    return () => { document.body.style.overflow = ''; clearTimeout(t); window.removeEventListener('keydown', onKey); };
  }, [animateClose]);

  const reset = useCallback(() => { setScale(1); setTx(0); setTy(0); }, []);

  const onPointerDown = (e: React.PointerEvent) => {
    if (scale > 1) {
      dragStart.current = { x: e.clientX, y: e.clientY, tx, ty };
    } else {
      closeDragStart.current = { x: e.clientX, y: e.clientY };
    }
  };

  const onPointerMove = (e: React.PointerEvent) => {
    if (dragStart.current && scale > 1) {
      setTx(dragStart.current.tx + (e.clientX - dragStart.current.x));
      setTy(dragStart.current.ty + (e.clientY - dragStart.current.y));
    } else if (closeDragStart.current) {
      const dy = e.clientY - closeDragStart.current.y;
      if (dy > 0) setCloseDragY(dy);
      else setCloseDragY(0);
    }
  };

  const onPointerUp = () => {
    if (closeDragStart.current && closeDragY > 120) {
      animateClose();
      return;
    }
    setCloseDragY(0);
    dragStart.current = null;
    closeDragStart.current = null;
  };

  const onWheel = (e: React.WheelEvent) => {
    e.preventDefault();
    const delta = e.deltaY > 0 ? -0.2 : 0.2;
    setScale((s) => Math.max(1, Math.min(5, +(s + delta).toFixed(2))));
  };

  const onDoubleClick = () => {
    if (scale > 1) { reset(); } else { setScale(2.5); }
  };

  const onTouchStart = (e: React.TouchEvent) => {
    if (e.touches.length === 2) {
      const d = Math.hypot(e.touches[0].clientX - e.touches[1].clientX, e.touches[0].clientY - e.touches[1].clientY);
      pinchStart.current = { d, scale };
      closeDragStart.current = null;
    }
  };

  const onTouchMove = (e: React.TouchEvent) => {
    if (e.touches.length === 2 && pinchStart.current) {
      e.preventDefault();
      const d = Math.hypot(e.touches[0].clientX - e.touches[1].clientX, e.touches[0].clientY - e.touches[1].clientY);
      const factor = d / pinchStart.current.d;
      setScale(Math.max(1, Math.min(5, +(pinchStart.current.scale * factor).toFixed(2))));
    }
  };

  const onTouchEnd = () => {
    pinchStart.current = null;
  };

  const bgOpacity = visible ? Math.max(0, 1 - closeDragY / 300) : 1;
  const imgScale = closeDragY > 0 ? Math.max(0.6, 1 - closeDragY / 600) : 1;

  return (
    <div
      className="fixed inset-0 z-[10000] flex items-center justify-center"
      style={{
        background: `rgba(0,0,0,${bgOpacity * 0.98})`,
        opacity: visible ? 1 : 0,
        transition: 'opacity 0.3s ease-out, background 0.15s ease-out',
      }}
    >
      {/* Top bar */}
      <div
        className="absolute top-0 left-0 right-0 z-10 px-4 pt-4 pb-10 bg-gradient-to-b from-black/60 to-transparent"
        style={{ opacity: closeDragY < 60 ? 1 : 0, transition: 'opacity 0.2s' }}
      >
        <div className="flex items-center justify-end">
          <button
            onClick={animateClose}
            className="w-10 h-10 rounded-full glass-strong flex items-center justify-center text-white hover:bg-white/25 active:scale-90 transition-all"
            aria-label="Close"
          >
            <CloseIcon size={20} />
          </button>
        </div>
      </div>

      {/* Loading spinner */}
      {!loaded && !error && (
        <div className="absolute inset-0 flex items-center justify-center">
          <div className="w-8 h-8 border-2 border-white/20 border-t-white/80 rounded-full animate-spin" />
        </div>
      )}

      {/* Error fallback */}
      {error && (
        <div className="absolute inset-0 flex flex-col items-center justify-center gap-3">
          <p className="text-white/60 text-sm">Could not load image</p>
          <button onClick={animateClose} className="px-4 py-2 rounded-full glass-strong text-xs text-white/80 hover:text-white active:scale-95 transition-all">
            Close
          </button>
        </div>
      )}

      {/* Zoom reset pill */}
      {scale > 1 && (
        <div className="absolute bottom-6 left-1/2 -translate-x-1/2 z-10" style={{ opacity: closeDragY < 60 ? 1 : 0, transition: 'opacity 0.2s' }}>
          <button
            onClick={reset}
            className="px-4 py-2 rounded-full glass-strong text-xs text-white/80 hover:text-white active:scale-95 transition-all"
          >
            Reset zoom
          </button>
        </div>
      )}

      {/* Image container */}
      <div
        className="w-full h-full flex items-center justify-center overflow-hidden"
        style={{ touchAction: 'none' }}
        onPointerDown={onPointerDown}
        onPointerMove={onPointerMove}
        onPointerUp={onPointerUp}
        onPointerCancel={onPointerUp}
        onWheel={onWheel}
        onDoubleClick={onDoubleClick}
        onTouchStart={onTouchStart}
        onTouchMove={onTouchMove}
        onTouchEnd={onTouchEnd}
      >
        <img
          src={src}
          alt=""
          className="max-w-full max-h-full object-contain select-none"
          draggable={false}
          onLoad={() => setLoaded(true)}
          onError={() => setError(true)}
          style={{
            transform: `translate(${tx}px, ${ty}px) scale(${scale * imgScale})`,
            opacity: loaded ? 1 : 0,
            transition: dragStart.current || closeDragY > 0 ? 'none' : 'transform 0.25s cubic-bezier(0.22,1,0.36,1), opacity 0.3s ease-out',
            willChange: 'transform',
          }}
        />
      </div>
    </div>
  );
}
