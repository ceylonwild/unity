import { useState, useEffect } from 'react';
import { useAuth } from '@/lib/auth';
import { isSupabaseConfigured } from '@/lib/supabase';
import { LogoGlyph } from '@/components/Brand';
import { showToast } from '@/lib/toast';

const COUNTRIES = [
  'Global', 'Singapore', 'Japan', 'Italy', 'Nigeria', 'Mexico',
  'United States', 'United Kingdom', 'Brazil', 'India', 'Germany',
  'South Korea', 'Australia', 'Canada', 'France', 'Sweden', 'Kenya',
  'United Arab Emirates', 'Switzerland', 'Netherlands',
];
const COUNTRY_CODES: Record<string, string> = {
  Global: 'WO', Singapore: 'SG', Japan: 'JP', Italy: 'IT', Nigeria: 'NG',
  Mexico: 'MX', 'United States': 'US', 'United Kingdom': 'GB', Brazil: 'BR',
  India: 'IN', Germany: 'DE', 'South Korea': 'KR', Australia: 'AU', Canada: 'CA',
  France: 'FR', Sweden: 'SE', Kenya: 'KE', 'United Arab Emirates': 'AE',
  Switzerland: 'CH', Netherlands: 'NL',
};
const INTERESTS = [
  'Science', 'Art', 'Technology', 'Climate', 'Governance',
  'Space', 'Philosophy', 'Music', 'Design', 'Economics',
];

type Mode = 'signin' | 'signup';

export function AuthScreen() {
  const { signIn, signUp } = useAuth();
  const [mode, setMode] = useState<Mode>('signup');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [handle, setHandle] = useState('');
  const [country, setCountry] = useState('Global');
  const [bio, setBio] = useState('');
  const [interests, setInterests] = useState<string[]>([]);
  const [registrationOpen, setRegistrationOpen] = useState(true);
  const [maintenanceMode, setMaintenanceMode] = useState(false);

  useEffect(() => {
    void (async () => {
      try {
        const { data } = await supabase.from('platform_settings').select('*').maybeSingle();
        if (data) {
          setRegistrationOpen(data.registration_open !== false);
          setMaintenanceMode(data.maintenance_mode === true);
        }
      } catch { /* graceful — allow access */ }
    })();
  }, []);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const toggleInterest = (i: string) =>
    setInterests((prev) => (prev.includes(i) ? prev.filter((x) => x !== i) : [...prev, i]));

  const submit = async () => {
    if (busy) return;
    setError(null);
    if (!email.trim() || !password) {
      setError('Enter your email and password.');
      return;
    }
    if (mode === 'signup' && !name.trim()) {
      setError('Enter your name to receive your citizen identity.');
      return;
    }
    if (mode === 'signup' && !registrationOpen) {
      setError('New registrations are currently closed by administrators.');
      return;
    }
    setBusy(true);
    try {
      if (mode === 'signin') {
        const { error } = await signIn(email.trim(), password);
        if (error) setError(error);
      } else {
        const meta = {
          name: name.trim(),
          handle: handle.trim().toLowerCase().replace(/[^a-z0-9_]/g, '') || undefined,
          country,
          country_code: COUNTRY_CODES[country] ?? 'WO',
          bio: bio.trim(),
          interests,
        };
        const { error } = await signUp(email.trim(), password, meta);
        if (error) {
          setError(error);
        } else {
          showToast('Welcome to UNITY', 'success');
        }
      }
    } catch {
      setError('Something went wrong. Please try again.');
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="min-h-screen flex flex-col items-center justify-center px-5 py-10">
      {/* Brand mark */}
      <div className="flex flex-col items-center mb-8 animate-fade-up">
        <div className="w-24 h-24 rounded-2xl glass flex items-center justify-center mb-5 glow-soft">
          <LogoGlyph size={56} />
        </div>
        <h1 className="text-3xl font-semibold tracking-tightest text-unity-primary">UNITY</h1>
        <p className="text-[11px] tracking-[0.35em] text-unity-faint uppercase mt-1.5">Global Civilization</p>
      </div>

      {!isSupabaseConfigured && (
        <div className="w-full max-w-md mb-4 text-sm text-amber-400/90 bg-amber-500/10 border border-amber-500/20 rounded-xl px-4 py-3 text-center">
          Backend not configured. Set VITE_SUPABASE_URL and VITE_SUPABASE_ANON_KEY in your deployment environment variables.
        </div>
      )}

      {maintenanceMode && mode === 'signin' && (
        <div className="w-full max-w-md mb-4 text-sm text-amber-400/90 bg-amber-500/10 border border-amber-500/20 rounded-xl px-4 py-3 text-center">
          UNITY is undergoing scheduled maintenance. Some features may be temporarily unavailable.
        </div>
      )}

      {mode === 'signup' && !registrationOpen && (
        <div className="w-full max-w-md mb-4 text-sm text-rose-400/90 bg-rose-500/10 border border-rose-500/20 rounded-xl px-4 py-3 text-center">
          New registrations are currently closed. Please check back later.
        </div>
      )}

      <div className="w-full max-w-md animate-fade-up">
        <div className="card p-7">
          {/* Mode toggle */}
          <div className="flex gap-1 p-1 rounded-full bg-unity-surface border border-unity-border mb-6">
            {(['signup', 'signin'] as const).map((m) => (
              <button
                key={m}
                onClick={() => { setMode(m); setError(null); }}
                className={`flex-1 py-2 rounded-full text-sm font-medium transition-all ${
                  mode === m ? 'bg-unity-btn-primary-bg text-unity-btn-primary-text' : 'text-unity-muted hover:text-unity-primary'
                }`}
              >
                {m === 'signup' ? 'Register' : 'Sign in'}
              </button>
            ))}
          </div>

          <div className="space-y-4">
            {mode === 'signup' && (
              <>
                <Field label="Full name">
                  <input value={name} onChange={(e) => setName(e.target.value)} placeholder="Your name" className="input-field" autoFocus />
                </Field>
                <Field label="Handle">
                  <div className="relative">
                    <span className="absolute left-4 top-1/2 -translate-y-1/2 text-white/30 text-sm">@</span>
                    <input value={handle} onChange={(e) => setHandle(e.target.value)} placeholder="yourhandle" className="input-field pl-8" />
                  </div>
                </Field>
                <Field label="Country">
                  <select value={country} onChange={(e) => setCountry(e.target.value)} className="input-field appearance-none">
                    {COUNTRIES.map((c) => <option key={c} value={c} className="bg-unity-surface-strong text-unity-primary">{c}</option>)}
                  </select>
                </Field>
                <Field label="Short bio (optional)">
                  <textarea value={bio} onChange={(e) => setBio(e.target.value)} rows={2} placeholder="A line about you…" className="input-field resize-none" />
                </Field>
                <div>
                  <label className="text-xs text-unity-faint mb-2 block">Interests · {interests.length} selected</label>
                  <div className="flex flex-wrap gap-2">
                    {INTERESTS.map((i) => (
                      <button
                        key={i}
                        onClick={() => toggleInterest(i)}
                        className={`px-3 py-1.5 rounded-full text-sm border transition-all ${
                          interests.includes(i)
                            ? 'btn-primary border-transparent'
                            : 'glass-panel text-unity-muted border-unity-border hover:border-unity-muted/40'
                        }`}
                      >
                        {i}
                      </button>
                    ))}
                  </div>
                </div>
              </>
            )}

            <Field label="Email">
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="you@unity.civilization"
                className="input-field"
                autoFocus={mode === 'signin'}
              />
            </Field>
            <Field label="Password">
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="At least 6 characters"
                className="input-field"
                onKeyDown={(e) => e.key === 'Enter' && submit()}
              />
            </Field>

            {error && (
              <div className="text-sm text-rose-400/90 bg-rose-500/10 border border-rose-500/20 rounded-xl px-3 py-2">
                {error}
              </div>
            )}

            <button onClick={submit} disabled={busy || !isSupabaseConfigured} className="btn-primary w-full disabled:opacity-50">
              {busy ? 'Working…' : mode === 'signup' ? 'Receive Identity' : 'Enter UNITY'}
            </button>

            <p className="text-center text-xs text-unity-faint leading-relaxed pt-1">
              {mode === 'signup'
                ? 'Registration creates your permanent citizen identity and account.'
                : 'New to UNITY? Switch to Register to create your identity.'}
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div>
      <label className="text-xs text-unity-faint mb-1.5 block">{label}</label>
      {children}
    </div>
  );
}
