import { VerifiedIcon } from '@/components/icons';

export function VerifiedBadge({ size = 14, className = '' }: { size?: number; className?: string }) {
  return <VerifiedIcon size={size} className={`text-unity-primary shrink-0 ${className}`} />;
}
