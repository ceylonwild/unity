import { useEffect, useState, useCallback } from 'react';
import type { AppNotification } from '@/types';
import { CloseIcon, BellIcon, HeartIcon, CommentIcon, UserPlusIcon, VerifiedIcon, TrashIcon } from '@/components/icons';
import { Avatar } from '@/components/Avatar';
import { fetchNotifications, markNotificationRead, markAllNotificationsRead, deleteNotification, subscribeToNotifications } from '@/lib/notifications';
import { fetchCitizenByUserId } from '@/lib/feed';
import { timeAgo } from '@/lib/utils';
import { CitizenProfileModal } from '@/components/CitizenProfileModal';
import type { Citizen } from '@/types';

export function NotificationsPanel({ onClose, onUnreadChange }: { onClose: () => void; onUnreadChange?: (count: number) => void }) {
  const [notifications, setNotifications] = useState<AppNotification[]>([]);
  const [loading, setLoading] = useState(true);
  const [openProfile, setOpenProfile] = useState<Citizen | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      setNotifications(await fetchNotifications(40));
    } catch {
      // graceful
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { void load(); }, [load]);

  // Live-update when new notifications arrive and sync unread count to parent.
  useEffect(() => {
    const unsub = subscribeToNotifications(() => { void load(); });
    return unsub;
  }, [load]);

  useEffect(() => {
    if (onUnreadChange) onUnreadChange(notifications.filter((n) => !n.read).length);
  }, [notifications, onUnreadChange]);

  const handleRead = async (id: string) => {
    setNotifications((prev) => prev.map((n) => n.id === id ? { ...n, read: true } : n));
    try { await markNotificationRead(id); } catch { /* graceful */ }
  };

  const handleMarkAll = async () => {
    setNotifications((prev) => prev.map((n) => ({ ...n, read: true })));
    try { await markAllNotificationsRead(); } catch { /* graceful */ }
  };

  const handleDelete = async (id: string) => {
    setNotifications((prev) => prev.filter((n) => n.id !== id));
    try { await deleteNotification(id); } catch { /* graceful */ }
  };

  const openActorProfile = async (actorId: string | null) => {
    if (!actorId) return;
    try {
      const c = await fetchCitizenByUserId(actorId);
      if (c) setOpenProfile(c);
    } catch { /* graceful */ }
  };

  return (
    <div className="fixed inset-0 z-[9100] flex items-center justify-center p-4 animate-fade-in" onClick={onClose}>
      <div className="absolute inset-0 bg-unity-bg/90 backdrop-blur-xl" />
      <div
        className="relative glass-strong rounded-3xl w-full max-w-md max-h-[85vh] overflow-y-auto no-scrollbar animate-scale-in"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="sticky top-0 z-10 glass-strong border-b border-unity-border p-4 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <BellIcon size={20} className="text-unity-primary" />
            <h2 className="font-semibold text-lg">Notifications</h2>
          </div>
          <div className="flex items-center gap-1">
            {notifications.some((n) => !n.read) && (
              <button onClick={handleMarkAll} className="text-xs text-unity-muted hover:text-unity-primary transition-colors px-2 py-1">
                Mark all read
              </button>
            )}
            <button onClick={onClose} className="btn-icon"><CloseIcon size={20} /></button>
          </div>
        </div>

        {loading ? (
          <div className="p-8 flex items-center justify-center">
            <div className="w-7 h-7 rounded-full border-2 border-white/10 border-t-white/60 animate-spin" />
          </div>
        ) : notifications.length === 0 ? (
          <div className="p-12 text-center">
            <BellIcon size={32} className="text-unity-faint mx-auto mb-3" />
            <p className="text-unity-muted text-sm">No notifications yet.</p>
          </div>
        ) : (
          <div className="divide-y divide-unity-border">
            {notifications.map((n) => (
              <NotificationRow
                key={n.id}
                notification={n}
                onRead={() => handleRead(n.id)}
                onDelete={() => handleDelete(n.id)}
                onOpenActor={() => openActorProfile(n.actor_id)}
              />
            ))}
          </div>
        )}
      </div>

      {openProfile && (
        <CitizenProfileModal
          citizenId={openProfile.id}
          fallback={{ name: openProfile.name, handle: openProfile.handle, avatar: openProfile.avatar_url, verified: openProfile.verified }}
          onClose={() => setOpenProfile(null)}
        />
      )}
    </div>
  );
}

function NotificationRow({
  notification: n,
  onRead,
  onDelete,
  onOpenActor,
}: {
  notification: AppNotification;
  onRead: () => void;
  onDelete: () => void;
  onOpenActor: () => void;
}) {
  const icon = () => {
    switch (n.type) {
      case 'like': return <HeartIcon size={14} className="text-rose-400" filled />;
      case 'comment': return <CommentIcon size={14} className="text-sky-400" />;
      case 'follow': return <UserPlusIcon size={14} className="text-emerald-400" />;
      case 'verification': return <VerifiedIcon size={14} className="text-unity-primary" />;
      default: return <BellIcon size={14} className="text-unity-muted" />;
    }
  };

  const label = () => {
    switch (n.type) {
      case 'like': return 'liked your post';
      case 'comment': return 'commented on your post';
      case 'follow': return 'started following you';
      case 'verification': return n.message || 'Verification update';
      case 'admin': return n.message || 'Platform announcement';
      default: return n.message || 'Notification';
    }
  };

  return (
    <div
      className={`flex items-start gap-3 p-4 transition-colors ${n.read ? '' : 'bg-unity-surface/40'}`}
      onClick={onRead}
    >
      <button onClick={onOpenActor} className="shrink-0 mt-0.5">
        <div className="w-9 h-9 rounded-full glass-panel flex items-center justify-center">
          {icon()}
        </div>
      </button>
      <div className="flex-1 min-w-0">
        <p className="text-sm text-unity-primary">
          {n.type === 'follow' || n.type === 'like' || n.type === 'comment' ? (
            <>Someone {label()}</>
          ) : (
            label()
          )}
        </p>
        {n.message && n.type === 'comment' && (
          <p className="text-xs text-unity-faint mt-0.5 truncate">"{n.message}"</p>
        )}
        <div className="text-[11px] text-unity-faint mt-1">{timeAgo(n.created_at)}</div>
      </div>
      {!n.read && <span className="w-2 h-2 rounded-full bg-unity-primary shrink-0 mt-2" />}
      <button onClick={(e) => { e.stopPropagation(); onDelete(); }} className="btn-icon w-7 h-7 shrink-0 text-unity-faint hover:text-rose-400">
        <TrashIcon size={14} />
      </button>
    </div>
  );
}
