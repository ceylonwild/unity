import { UnityMark } from '@/components/icons';

export function Wordmark({ size = 'md' }: { size?: 'sm' | 'md' | 'lg' }) {
  const text = size === 'lg' ? 'text-3xl' : size === 'sm' ? 'text-lg' : 'text-xl';
  const icon = size === 'lg' ? 52 : size === 'sm' ? 32 : 42;
  const sub = size === 'lg' ? 'text-[10px]' : size === 'sm' ? 'text-[9px]' : 'text-[9px]';
  return (
    <div className="flex items-center gap-3.5 select-none">
      <UnityMark size={icon} className="text-unity-primary" />
      <div className="leading-none">
        <div className={`font-semibold tracking-tightest text-unity-primary ${text}`}>UNITY</div>
        <div className={`${sub} tracking-[0.35em] text-unity-faint uppercase mt-0.5`}>Global Civilization</div>
      </div>
    </div>
  );
}

export function LogoGlyph({ size = 44, className = '' }: { size?: number; className?: string }) {
  return <UnityMark size={size} className={`text-unity-primary ${className}`} />;
}
