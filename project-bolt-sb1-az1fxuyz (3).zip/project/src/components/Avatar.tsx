import { VerifiedIcon } from '@/components/icons';

export function Avatar({
  src,
  name,
  size = 44,
  ring = false,
  verified = false,
}: {
  src: string | null;
  name: string;
  size?: number;
  ring?: boolean;
  verified?: boolean;
}) {
  const initials = name
    .split(' ')
    .filter(Boolean)
    .map((w) => w[0])
    .slice(0, 2)
    .join('')
    .toUpperCase();
  return (
    <div className="relative shrink-0" style={{ width: size, height: size }}>
      <div
        className={`w-full h-full rounded-full overflow-hidden flex items-center justify-center bg-unity-surface border border-unity-border ${ring ? 'ring-2 ring-unity-primary/30' : ''}`}
      >
        {src ? (
          <img src={src} alt={name} className="w-full h-full object-cover" loading="lazy" />
        ) : (
          <span className="text-unity-muted font-medium" style={{ fontSize: size * 0.36 }}>
            {initials}
          </span>
        )}
      </div>
      {verified && (
        <span className="absolute -bottom-0.5 -right-0.5 w-4 h-4 rounded-full bg-unity-bg flex items-center justify-center">
          <VerifiedIcon size={14} className="text-unity-primary" />
        </span>
      )}
    </div>
  );
}
