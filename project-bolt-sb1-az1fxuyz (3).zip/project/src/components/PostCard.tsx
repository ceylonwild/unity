import { useState, useRef, useEffect } from 'react';
import type { Post, Comment } from '@/types';
import { Avatar } from '@/components/Avatar';
import { CitizenProfileModal } from '@/components/CitizenProfileModal';
import { VerifiedBadge } from '@/components/VerifiedBadge';
import { ConfirmDialog } from '@/components/ConfirmDialog';
import { ReportModal } from '@/components/ReportModal';
import { ImageViewer } from '@/components/ImageViewer';
import { VideoViewer, type VideoPost } from '@/components/VideoViewer';
import {
  HeartIcon, CommentIcon, SaveIcon, ShareIcon, SendIcon, MoreIcon,
  EditIcon, TrashIcon, FlagIcon, PinIcon, PlayIcon,
} from '@/components/icons';
import { timeAgo, formatNumber } from '@/lib/utils';
import { togglePostLike, togglePostSave, fetchComments, addComment, updatePost, deletePost, togglePostFeatured } from '@/lib/feed';
import { useSelf } from '@/lib/self';
import { useAuth } from '@/lib/auth';
import { showToast } from '@/lib/toast';

function isVideoUrl(url: string): boolean {
  return /\.(mp4|webm|mov|m4v|ogg)(\?|$)/i.test(url) || url.includes('video/');
}

export function PostCard({ post, onChange, onDeleted, onOpenProfile, videoPosts }: { post: Post; onChange: (p: Post) => void; onDeleted?: (id: string) => void; onOpenProfile?: (citizenId: string) => void; videoPosts?: Post[] }) {
  const { self } = useSelf();
  const { isAdmin } = useAuth();
  const [showComments, setShowComments] = useState(false);
  const [comments, setComments] = useState<Comment[]>([]);
  const [commentText, setCommentText] = useState('');
  const [loadingComments, setLoadingComments] = useState(false);
  const [busy, setBusy] = useState(false);
  const [showProfile, setShowProfile] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const [editing, setEditing] = useState(false);
  const [editText, setEditText] = useState(post.content);
  const [confirmDelete, setConfirmDelete] = useState(false);
  const openProfile = () => {
    if (onOpenProfile) onOpenProfile(post.author_id);
    else setShowProfile(true);
  };
  const [reporting, setReporting] = useState(false);
  const [reportingCommentId, setReportingCommentId] = useState<string | null>(null);
  const [imageViewer, setImageViewer] = useState<string | null>(null);
  const [videoViewerIndex, setVideoViewerIndex] = useState<number | null>(null);
  const menuRef = useRef<HTMLDivElement>(null);

  const isOwner = self?.id === post.author_id;
  const canModerate = isAdmin;

  useEffect(() => {
    if (!menuOpen) return;
    const handler = (e: MouseEvent) => {
      if (menuRef.current && !menuRef.current.contains(e.target as Node)) setMenuOpen(false);
    };
    document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, [menuOpen]);

  const onLike = async () => {
    if (busy) return;
    setBusy(true);
    try {
      const { liked, count } = await togglePostLike(post);
      onChange({ ...post, liked_by_me: liked, likes_count: count });
    } catch {
      showToast('Could not update like', 'error');
    } finally {
      setBusy(false);
    }
  };

  const onSave = async () => {
    if (busy) return;
    setBusy(true);
    try {
      const { saved, count } = await togglePostSave(post);
      onChange({ ...post, saved_by_me: saved, saves_count: count });
    } catch {
      showToast('Could not update save', 'error');
    } finally {
      setBusy(false);
    }
  };

  const onShare = async () => {
    const url = `${window.location.origin}/?post=${post.id}`;
    const shareData = { title: `${post.author_name} on UNITY`, text: post.content.slice(0, 120), url };
    if (navigator.share) {
      try { await navigator.share(shareData); } catch { /* cancelled */ }
    } else {
      try { await navigator.clipboard.writeText(url); showToast('Post link copied', 'success'); }
      catch { showToast('Could not copy link', 'error'); }
    }
  };

  const openComments = async () => {
    if (!showComments) {
      setShowComments(true);
      setLoadingComments(true);
      try { setComments(await fetchComments(post.id)); } catch { /* graceful */ }
      finally { setLoadingComments(false); }
    } else { setShowComments(false); }
  };

  const submitComment = async () => {
    if (!commentText.trim() || !self) return;
    const text = commentText.trim();
    setCommentText('');
    try {
      await addComment(post.id, self.id, text);
      const updated = await fetchComments(post.id);
      setComments(updated);
      onChange({ ...post, comments_count: updated.length });
    } catch {
      showToast('Could not post comment', 'error');
      setCommentText(text);
    }
  };

  const saveEdit = async () => {
    if (!editText.trim()) return;
    setBusy(true);
    try {
      await updatePost(post.id, editText.trim());
      onChange({ ...post, content: editText.trim(), edited_at: new Date().toISOString() });
      setEditing(false);
      showToast('Post updated', 'success');
    } catch {
      showToast('Could not update post', 'error');
    } finally {
      setBusy(false);
    }
  };

  const onDeleteConfirm = async () => {
    setBusy(true);
    try {
      await deletePost(post.id);
      onDeleted?.(post.id);
      showToast('Post deleted', 'success');
    } catch {
      showToast('Could not delete post', 'error');
    } finally {
      setBusy(false);
      setConfirmDelete(false);
    }
  };

  const onFeature = async () => {
    setMenuOpen(false);
    try {
      const featured = await togglePostFeatured(post.id, post.featured);
      onChange({ ...post, featured });
      showToast(featured ? 'Post featured' : 'Post unfeatured', 'success');
    } catch {
      showToast('Could not update post', 'error');
    }
  };

  return (
    <>
      <article className="card p-5 animate-fade-up">
        {/* Header */}
        <div className="flex items-start gap-3">
          <button onClick={openProfile} className="shrink-0 hover:opacity-90 transition-opacity" aria-label={`View ${post.author_name}'s profile`}>
            <Avatar src={post.author_avatar} name={post.author_name} size={44} verified={post.author_verified} />
          </button>
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-1.5 flex-wrap">
              <button onClick={openProfile} className="font-medium text-[15px] hover:underline underline-offset-4 transition-all">
                {post.author_name}
              </button>
              {post.author_verified && <VerifiedBadge size={14} />}
              <span className="text-white/30 text-sm">@{post.author_handle}</span>
              <span className="text-white/30 text-sm">· {timeAgo(post.created_at)}</span>
              {post.edited_at && <span className="text-white/25 text-xs italic">(edited)</span>}
            </div>
            <div className="text-xs text-white/40 mt-0.5 flex items-center gap-1.5">
              {post.featured && (
                <span className="inline-flex items-center gap-1 text-amber-400/80">
                  <PinIcon size={11} /> Featured
                </span>
              )}
              {post.featured && <span>·</span>}
              Citizen · {post.author_verified ? 'Verified' : 'Member'}
            </div>
          </div>

          {/* Three-dot menu */}
          <div className="relative shrink-0" ref={menuRef}>
            <button onClick={() => setMenuOpen((v) => !v)} className="btn-icon w-8 h-8" aria-label="Post options">
              <MoreIcon size={18} />
            </button>
            {menuOpen && (
              <div className="absolute right-0 top-full mt-1 w-44 glass-strong rounded-xl border border-unity-border py-1 z-30 animate-fade-in">
                {isOwner && (
                  <button
                    onClick={() => { setMenuOpen(false); setEditing(true); setEditText(post.content); }}
                    className="w-full flex items-center gap-2.5 px-3.5 py-2.5 text-sm text-unity-muted hover:text-unity-primary hover:bg-white/[0.04] transition-all"
                  >
                    <EditIcon size={15} /> Edit post
                  </button>
                )}
                {canModerate && !isOwner && (
                  <button
                    onClick={() => { setMenuOpen(false); setEditing(true); setEditText(post.content); }}
                    className="w-full flex items-center gap-2.5 px-3.5 py-2.5 text-sm text-unity-muted hover:text-unity-primary hover:bg-white/[0.04] transition-all"
                  >
                    <EditIcon size={15} /> Edit (admin)
                  </button>
                )}
                {canModerate && (
                  <button
                    onClick={onFeature}
                    className="w-full flex items-center gap-2.5 px-3.5 py-2.5 text-sm text-unity-muted hover:text-amber-400 hover:bg-white/[0.04] transition-all"
                  >
                    <PinIcon size={15} /> {post.featured ? 'Unfeature' : 'Feature'}
                  </button>
                )}
                {(isOwner || canModerate) && (
                  <button
                    onClick={() => { setMenuOpen(false); setConfirmDelete(true); }}
                    className="w-full flex items-center gap-2.5 px-3.5 py-2.5 text-sm text-rose-400/80 hover:text-rose-400 hover:bg-rose-500/10 transition-all"
                  >
                    <TrashIcon size={15} /> {isOwner ? 'Delete' : 'Delete (admin)'}
                  </button>
                )}
                {!isOwner && (
                  <button
                    onClick={() => { setMenuOpen(false); setReporting(true); }}
                    className="w-full flex items-center gap-2.5 px-3.5 py-2.5 text-sm text-unity-muted hover:text-amber-400 hover:bg-white/[0.04] transition-all"
                  >
                    <FlagIcon size={15} /> Report
                  </button>
                )}
              </div>
            )}
          </div>
        </div>

        {/* Content / Edit mode */}
        {editing ? (
          <div className="mt-4 space-y-3">
            <textarea
              value={editText}
              onChange={(e) => setEditText(e.target.value)}
              rows={4}
              className="input-field resize-none"
              autoFocus
            />
            <div className="flex gap-2">
              <button onClick={() => { setEditing(false); setEditText(post.content); }} className="btn-ghost">Cancel</button>
              <button onClick={saveEdit} disabled={busy || !editText.trim()} className="btn-primary disabled:opacity-40">
                {busy ? 'Saving…' : 'Save changes'}
              </button>
            </div>
          </div>
        ) : (
          <p className="mt-4 text-[15px] leading-relaxed text-white/90 whitespace-pre-wrap text-balance">
            {post.content}
          </p>
        )}

        {post.image_url && !editing && (
          <div className="mt-4 rounded-xl overflow-hidden border border-[#2a2a2a]/80 relative group cursor-pointer" onClick={() => {
            if (isVideoUrl(post.image_url!)) {
              setVideoViewerIndex(0);
            } else {
              setImageViewer(post.image_url!);
            }
          }}>
            {isVideoUrl(post.image_url!) ? (
              <>
                <video src={post.image_url!} className="w-full max-h-[520px] object-cover" preload="metadata" muted />
                <div className="absolute inset-0 flex items-center justify-center bg-black/30">
                  <div className="w-14 h-14 rounded-full glass-strong flex items-center justify-center">
                    <PlayIcon />
                  </div>
                </div>
              </>
            ) : (
              <img src={post.image_url!} alt="" className="w-full max-h-[520px] object-cover" loading="lazy" />
            )}
          </div>
        )}

        {/* Actions */}
        {!editing && (
          <div className="mt-4 flex items-center gap-1">
            <button onClick={onLike} className={`action-btn ${post.liked_by_me ? 'text-rose-400' : ''}`} aria-label="Like">
              <HeartIcon size={18} filled={post.liked_by_me} />
              {post.likes_count > 0 && <span className="text-xs tabular-nums">{formatNumber(post.likes_count)}</span>}
            </button>
            <button onClick={openComments} className="action-btn" aria-label="Comment">
              <CommentIcon size={18} />
              {post.comments_count > 0 && <span className="text-xs tabular-nums">{formatNumber(post.comments_count)}</span>}
            </button>
            <button onClick={onSave} className={`action-btn ${post.saved_by_me ? 'text-white' : ''}`} aria-label="Save">
              <SaveIcon size={18} filled={post.saved_by_me} />
            </button>
            <button onClick={onShare} className="action-btn ml-auto" aria-label="Share">
              <ShareIcon size={18} />
            </button>
          </div>
        )}

        {/* Comments */}
        {showComments && !editing && (
          <div className="mt-4 pt-4 border-t border-[#2a2a2a]/80 space-y-3 animate-fade-in">
            <div className="flex items-center gap-2">
              <input
                value={commentText}
                onChange={(e) => setCommentText(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && submitComment()}
                placeholder="Add a comment…"
                className="input-field flex-1 py-2 text-sm"
              />
              <button onClick={submitComment} disabled={!commentText.trim()} className="btn-icon disabled:opacity-30">
                <SendIcon size={18} />
              </button>
            </div>
            {loadingComments ? (
              <div className="space-y-2">
                {[0, 1].map((i) => <div key={i} className="h-12 rounded-lg animate-shimmer" />)}
              </div>
            ) : comments.length === 0 ? (
              <p className="text-sm text-white/30 text-center py-3">No comments yet. Start the conversation.</p>
            ) : (
              comments.map((c) => (
                <div key={c.id} className="flex gap-2.5">
                  <Avatar src={c.author_avatar} name={c.author_name} size={28} verified={c.author_verified} />
                  <div className="flex-1 min-w-0">
                    <div className="glass-panel rounded-xl px-3 py-2">
                      <div className="flex items-center gap-1.5">
                        <span className="font-medium text-sm">{c.author_name}</span>
                        {c.author_verified && <VerifiedBadge size={12} />}
                        <span className="text-white/30 text-xs">@{c.author_handle}</span>
                        {c.author_id !== self?.id && (
                          <button
                            onClick={() => setReportingCommentId(c.id)}
                            className="ml-auto text-white/20 hover:text-amber-400 transition-colors"
                            aria-label="Report comment"
                          >
                            <FlagIcon size={12} />
                          </button>
                        )}
                      </div>
                      <p className="text-sm text-white/80 mt-0.5">{c.content}</p>
                    </div>
                    <div className="text-[11px] text-white/30 mt-1 ml-3">{timeAgo(c.created_at)}</div>
                  </div>
                </div>
              ))
            )}
          </div>
        )}
      </article>

      {showProfile && (
        <CitizenProfileModal
          citizenId={post.author_id}
          fallback={{ name: post.author_name, handle: post.author_handle, avatar: post.author_avatar, verified: post.author_verified }}
          onClose={() => setShowProfile(false)}
        />
      )}

      {confirmDelete && (
        <ConfirmDialog
          title="Delete post?"
          message="This post will be permanently removed. This action cannot be undone."
          confirmLabel="Delete"
          destructive
          onConfirm={onDeleteConfirm}
          onCancel={() => setConfirmDelete(false)}
        />
      )}

      {reporting && (
        <ReportModal targetType="post" targetId={post.id} onClose={() => setReporting(false)} />
      )}
      {reportingCommentId && (
        <ReportModal targetType="comment" targetId={reportingCommentId} onClose={() => setReportingCommentId(null)} />
      )}
      {imageViewer && (
        <ImageViewer src={imageViewer} onClose={() => setImageViewer(null)} />
      )}
      {videoViewerIndex !== null && (() => {
        const vids = (videoPosts ?? [post]).filter(p => p.image_url && isVideoUrl(p.image_url));
        const startIdx = Math.max(0, vids.findIndex(p => p.id === post.id));
        return (
          <VideoViewer
            posts={vids.map((p) => ({
              id: p.id,
              src: p.image_url!,
              authorName: p.author_name,
              authorHandle: p.author_handle,
              authorAvatar: p.author_avatar,
              authorVerified: p.author_verified,
              content: p.content,
              likes: p.likes_count,
              comments: p.comments_count,
            }))}
            startIndex={startIdx}
            onClose={() => setVideoViewerIndex(null)}
          />
        );
      })()}
    </>
  );
}
