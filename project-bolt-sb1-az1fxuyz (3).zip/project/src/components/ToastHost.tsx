import { useEffect, useState } from 'react';
import { subscribeToToasts } from '@/lib/toast';
import { CheckIcon, CloseIcon } from '@/components/icons';

export function ToastHost() {
  const [toasts, setToasts] = useState<{ id: number; message: string; kind: string }[]>([]);

  useEffect(() => subscribeToToasts(setToasts), []);

  return (
    <div className="fixed top-16 left-1/2 -translate-x-1/2 z-[9500] flex flex-col items-center gap-2 pointer-events-none">
      {toasts.map((t) => (
        <div
          key={t.id}
          className="toast-item pointer-events-auto flex items-center gap-2.5 pl-3.5 pr-4 py-2.5 rounded-full glass-strong text-sm text-white shadow-2xl animate-toast-in"
        >
          <span className={`w-5 h-5 rounded-full flex items-center justify-center shrink-0 ${t.kind === 'success' ? 'bg-emerald-500/20 text-emerald-300' : t.kind === 'error' ? 'bg-rose-500/20 text-rose-300' : 'bg-white/10 text-white/70'}`}>
            {t.kind === 'error' ? <CloseIcon size={13} /> : <CheckIcon size={13} />}
          </span>
          {t.message}
        </div>
      ))}
    </div>
  );
}
