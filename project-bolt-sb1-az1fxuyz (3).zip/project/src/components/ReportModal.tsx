import { useState } from 'react';
import { CloseIcon, FlagIcon } from '@/components/icons';
import { createReport } from '@/lib/reports';
import { showToast } from '@/lib/toast';
import type { ReportTarget } from '@/types';

const REASONS = [
  'Spam or repetitive content',
  'Harassment or hate speech',
  'Misinformation',
  'Impersonation',
  'Inappropriate or explicit content',
  'Other',
];

export function ReportModal({
  targetType,
  targetId,
  onClose,
}: {
  targetType: ReportTarget;
  targetId: string;
  onClose: () => void;
}) {
  const [reason, setReason] = useState('');
  const [custom, setCustom] = useState('');
  const [busy, setBusy] = useState(false);

  const submit = async () => {
    const finalReason = reason === 'Other' ? custom.trim() : reason;
    if (!finalReason) { showToast('Please select a reason', 'error'); return; }
    setBusy(true);
    try {
      await createReport(targetType, targetId, finalReason);
      showToast('Report submitted. Thank you.', 'success');
      onClose();
    } catch {
      showToast('Could not submit report', 'error');
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="fixed inset-0 z-[9100] flex items-center justify-center p-4 animate-fade-in" onClick={onClose}>
      <div className="absolute inset-0 bg-black/90 backdrop-blur-xl" />
      <div
        className="relative glass-strong rounded-3xl w-full max-w-md max-h-[85vh] overflow-y-auto no-scrollbar p-6 animate-scale-in"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between mb-5">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-amber-500/10 flex items-center justify-center text-amber-400">
              <FlagIcon size={18} />
            </div>
            <h2 className="font-semibold text-lg">Report Content</h2>
          </div>
          <button onClick={onClose} className="btn-icon"><CloseIcon size={20} /></button>
        </div>

        <p className="text-sm text-unity-faint mb-4">Help us keep UNITY safe. Select a reason for your report.</p>

        <div className="space-y-2 mb-4">
          {REASONS.map((r) => (
            <button
              key={r}
              onClick={() => setReason(r)}
              className={`w-full text-left px-4 py-3 rounded-xl border transition-all text-sm ${
                reason === r
                  ? 'bg-unity-surface-strong border-unity-primary text-unity-primary'
                  : 'glass-panel border-unity-border text-unity-muted hover:border-unity-muted/40'
              }`}
            >
              {r}
            </button>
          ))}
        </div>

        {reason === 'Other' && (
          <textarea
            value={custom}
            onChange={(e) => setCustom(e.target.value)}
            rows={3}
            placeholder="Describe the issue…"
            className="input-field resize-none mb-4"
          />
        )}

        <button onClick={submit} disabled={busy || !reason || (reason === 'Other' && !custom.trim())} className="btn-primary w-full disabled:opacity-40">
          {busy ? 'Submitting…' : 'Submit Report'}
        </button>
      </div>
    </div>
  );
}
