import { useEffect, useRef, useState, useCallback } from 'react';
import { CloseIcon, HeartIcon, CommentIcon, ShareIcon } from '@/components/icons';
import { Avatar } from '@/components/Avatar';
import { VerifiedBadge } from '@/components/VerifiedBadge';
import { formatNumber } from '@/lib/utils';

export interface VideoPost {
  id: string;
  src: string;
  authorName: string;
  authorHandle: string;
  authorAvatar: string | null;
  authorVerified: boolean;
  content: string;
  likes: number;
  comments: number;
}

interface VideoViewerProps {
  posts: VideoPost[];
  startIndex: number;
  onClose: () => void;
}

export function VideoViewer({ posts, startIndex, onClose }: VideoViewerProps) {
  const [index, setIndex] = useState(startIndex);
  const [dragY, setDragY] = useState(0);
  const [visible, setVisible] = useState(false);
  const dragStart = useRef<{ y: number } | null>(null);
  const containerRef = useRef<HTMLDivElement>(null);

  const goNext = useCallback(() => {
    setIndex((i) => Math.min(i + 1, posts.length - 1));
    setDragY(0);
  }, [posts.length]);

  const goPrev = useCallback(() => {
    setIndex((i) => Math.max(i - 1, 0));
    setDragY(0);
  }, []);

  useEffect(() => {
    document.body.style.overflow = 'hidden';
    const t = setTimeout(() => setVisible(true), 10);
    return () => { document.body.style.overflow = ''; clearTimeout(t); };
  }, []);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') animateClose();
      if (e.key === 'ArrowUp') goPrev();
      if (e.key === 'ArrowDown') goNext();
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [onClose, goNext, goPrev]);

  const animateClose = useCallback(() => {
    setVisible(false);
    setTimeout(onClose, 280);
  }, [onClose]);

  const onPointerDown = (e: React.PointerEvent) => {
    dragStart.current = { y: e.clientY };
  };

  const onPointerMove = (e: React.PointerEvent) => {
    if (dragStart.current) {
      const dy = e.clientY - dragStart.current.y;
      setDragY(dy);
    }
  };

  const onPointerUp = () => {
    if (dragStart.current) {
      if (dragY < -80 && index < posts.length - 1) goNext();
      else if (dragY > 80 && index > 0) goPrev();
      else setDragY(0);
    }
    dragStart.current = null;
  };

  const post = posts[index];
  if (!post) return null;

  const hasPrev = index > 0;
  const hasNext = index < posts.length - 1;

  return (
    <div
      className="fixed inset-0 z-[10000] bg-black"
      style={{
        opacity: visible ? 1 : 0,
        transition: 'opacity 0.3s ease-out',
        touchAction: 'none',
      }}
    >
      {/* Close button */}
      <div className="absolute top-4 right-4 z-30">
        <button
          onClick={animateClose}
          className="w-10 h-10 rounded-full glass-strong flex items-center justify-center text-white hover:bg-white/25 active:scale-90 transition-all"
          aria-label="Close"
        >
          <CloseIcon size={20} />
        </button>
      </div>

      {/* Navigation hints */}
      {hasPrev && (
        <div className="absolute top-1/2 -translate-y-1/2 left-4 z-30 text-white/30 animate-pulse-slow" style={{ opacity: Math.abs(dragY) < 20 ? 1 : 0, transition: 'opacity 0.2s' }}>
          <ChevronUp />
        </div>
      )}
      {hasNext && (
        <div className="absolute bottom-28 left-1/2 -translate-x-1/2 z-30 text-white/30 animate-pulse-slow flex flex-col items-center gap-1" style={{ opacity: Math.abs(dragY) < 20 ? 1 : 0, transition: 'opacity 0.2s' }}>
          <ChevronDown />
        </div>
      )}

      {/* Video container with swipe */}
      <div
        ref={containerRef}
        className="w-full h-full relative overflow-hidden"
        onPointerDown={onPointerDown}
        onPointerMove={onPointerMove}
        onPointerUp={onPointerUp}
        onPointerCancel={onPointerUp}
        style={{
          transform: `translateY(${dragY * 0.5}px)`,
          transition: dragY === 0 ? 'transform 0.4s cubic-bezier(0.22,1,0.36,1)' : 'none',
        }}
      >
        <VideoSlide key={post.id} post={post} active={true} onEnded={goNext} />
      </div>

      {/* Progress dots */}
      {posts.length > 1 && (
        <div className="absolute top-3 left-1/2 -translate-x-1/2 z-30 flex gap-1.5">
          {posts.map((_, i) => (
            <div
              key={i}
              className={`h-1 rounded-full transition-all duration-300 ${i === index ? 'w-6 bg-white' : 'w-1.5 bg-white/30'}`}
            />
          ))}
        </div>
      )}
    </div>
  );
}

function VideoSlide({ post, active, onEnded }: { post: VideoPost; active: boolean; onEnded: () => void }) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const [playing, setPlaying] = useState(true);
  const [muted, setMuted] = useState(true);
  const [progress, setProgress] = useState(0);
  const [duration, setDuration] = useState(0);
  const [showControls, setShowControls] = useState(true);
  const [buffering, setBuffering] = useState(false);
  const [fullscreen, setFullscreen] = useState(false);
  const lastTap = useRef(0);
  const controlsTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  useEffect(() => {
    const onFsChange = () => setFullscreen(Boolean(document.fullscreenElement));
    document.addEventListener('fullscreenchange', onFsChange);
    return () => document.removeEventListener('fullscreenchange', onFsChange);
  }, []);

  useEffect(() => {
    const v = videoRef.current;
    if (!v) return;
    if (active) {
      v.currentTime = 0;
      setBuffering(true);
      void v.play().then(() => { setPlaying(true); setBuffering(false); }).catch(() => { setPlaying(false); setBuffering(false); });
    } else {
      v.pause();
    }
  }, [active]);

  const toggleFullscreen = (e: React.MouseEvent) => {
    e.stopPropagation();
    const v = videoRef.current;
    if (!v) return;
    if (document.fullscreenElement) {
      void document.exitFullscreen();
      setFullscreen(false);
    } else {
      void v.requestFullscreen?.().then(() => setFullscreen(true)).catch(() => {});
    }
  };

  const togglePlay = () => {
    const v = videoRef.current;
    if (!v) return;
    if (v.paused) { void v.play(); setPlaying(true); }
    else { v.pause(); setPlaying(false); }
    setShowControls(true);
  };

  const onVideoClick = () => {
    const now = Date.now();
    if (now - lastTap.current < 300) {
      // Double-tap: seek 10s forward
      const v = videoRef.current;
      if (v) v.currentTime = Math.min(v.currentTime + 10, v.duration);
      lastTap.current = 0;
    } else {
      lastTap.current = now;
      togglePlay();
    }
  };

  const toggleMute = (e: React.MouseEvent) => {
    e.stopPropagation();
    const v = videoRef.current;
    if (!v) return;
    v.muted = !v.muted;
    setMuted(v.muted);
  };

  const onTimeUpdate = () => {
    const v = videoRef.current;
    if (!v) return;
    setProgress(v.currentTime);
    setDuration(v.duration || 0);
  };

  const onSeek = (e: React.MouseEvent) => {
    e.stopPropagation();
    const v = videoRef.current;
    if (!v || !duration) return;
    const rect = (e.currentTarget as HTMLElement).getBoundingClientRect();
    const pct = (e.clientX - rect.left) / rect.width;
    v.currentTime = pct * duration;
    setProgress(v.currentTime);
  };

  const showControlsTemporarily = () => {
    setShowControls(true);
    if (controlsTimer.current) clearTimeout(controlsTimer.current);
    controlsTimer.current = setTimeout(() => {
      if (playing) setShowControls(false);
    }, 3000);
  };

  useEffect(() => {
    showControlsTemporarily();
    return () => { if (controlsTimer.current) clearTimeout(controlsTimer.current); };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [playing]);

  const pct = duration > 0 ? (progress / duration) * 100 : 0;

  return (
    <div className="absolute inset-0 flex items-center justify-center" onClick={showControlsTemporarily}>
      <video
        ref={videoRef}
        src={post.src}
        muted={muted}
        playsInline
        autoPlay
        onClick={onVideoClick}
        onTimeUpdate={onTimeUpdate}
        onLoadedMetadata={onTimeUpdate}
        onWaiting={() => setBuffering(true)}
        onPlaying={() => setBuffering(false)}
        onEnded={onEnded}
        className="w-full h-full object-contain"
      />

      {/* Buffering indicator */}
      {buffering && (
        <div className="absolute inset-0 flex items-center justify-center pointer-events-none z-10">
          <div className="w-10 h-10 border-2 border-white/20 border-t-white/80 rounded-full animate-spin" />
        </div>
      )}

      {/* Pause overlay */}
      {!playing && !buffering && (
        <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
          <div className="w-16 h-16 rounded-full glass-strong flex items-center justify-center animate-fade-in">
            <PlayIcon />
          </div>
        </div>
      )}

      {/* Top controls (mute + fullscreen) */}
      <div
        className="absolute top-16 right-4 z-20 flex gap-2"
        style={{ opacity: showControls ? 1 : 0, transition: 'opacity 0.3s' }}
      >
        <button
          onClick={toggleMute}
          className="w-10 h-10 rounded-full glass-strong flex items-center justify-center text-white/80 hover:text-white active:scale-90 transition-all"
          aria-label={muted ? 'Unmute' : 'Mute'}
        >
          {muted ? <MutedIcon /> : <VolumeIcon />}
        </button>
        <button
          onClick={toggleFullscreen}
          className="w-10 h-10 rounded-full glass-strong flex items-center justify-center text-white/80 hover:text-white active:scale-90 transition-all"
          aria-label={fullscreen ? 'Exit fullscreen' : 'Fullscreen'}
        >
          <FullscreenIcon />
        </button>
      </div>

      {/* Progress bar — TikTok-style at bottom */}
      <div
        className="absolute bottom-0 left-0 right-0 z-20"
        style={{ opacity: showControls ? 1 : 0, transition: 'opacity 0.3s' }}
        onClick={onSeek}
      >
        <div className="h-1 bg-white/20 cursor-pointer">
          <div
            className="h-full bg-white rounded-r-full"
            style={{ width: `${pct}%`, transition: 'width 0.15s linear' }}
          />
        </div>
      </div>

      {/* Bottom info overlay */}
      <div
        className="absolute bottom-0 left-0 right-0 p-5 pt-12 bg-gradient-to-t from-black/85 via-black/40 to-transparent pointer-events-none"
        style={{ opacity: showControls ? 1 : 0, transition: 'opacity 0.3s' }}
      >
        <div className="flex items-center gap-3 mb-3">
          <Avatar src={post.authorAvatar} name={post.authorName} size={40} verified={post.authorVerified} />
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-1.5">
              <span className="font-medium text-white text-sm">{post.authorName}</span>
              {post.authorVerified && <VerifiedBadge size={12} />}
            </div>
            <div className="text-xs text-white/50">@{post.authorHandle}</div>
          </div>
        </div>
        <p className="text-sm text-white/90 mb-3 line-clamp-3">{post.content}</p>
        <div className="flex items-center gap-5">
          <div className="flex items-center gap-1.5 text-white/70">
            <HeartIcon size={18} />
            <span className="text-xs tabular-nums">{formatNumber(post.likes)}</span>
          </div>
          <div className="flex items-center gap-1.5 text-white/70">
            <CommentIcon size={18} />
            <span className="text-xs tabular-nums">{formatNumber(post.comments)}</span>
          </div>
          <div className="flex items-center gap-1.5 text-white/70">
            <ShareIcon size={18} />
          </div>
        </div>
      </div>
    </div>
  );
}

function ChevronUp() {
  return (
    <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M18 15l-6-6-6 6" />
    </svg>
  );
}

function ChevronDown() {
  return (
    <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M6 9l6 6 6-6" />
    </svg>
  );
}

function PlayIcon() {
  return (
    <svg width="28" height="28" viewBox="0 0 24 24" fill="white">
      <path d="M8 5v14l11-7z" />
    </svg>
  );
}

function MutedIcon() {
  return (
    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M11 5L6 9H2v6h4l5 4V5z" />
      <line x1="23" y1="9" x2="17" y2="15" />
      <line x1="17" y1="9" x2="23" y2="15" />
    </svg>
  );
}

function VolumeIcon() {
  return (
    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M11 5L6 9H2v6h4l5 4V5z" />
      <path d="M15.54 8.46a5 5 0 010 7.07" />
      <path d="M19.07 4.93a10 10 0 010 14.14" />
    </svg>
  );
}

function FullscreenIcon() {
  return (
    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M8 3H5a2 2 0 00-2 2v3" />
      <path d="M21 8V5a2 2 0 00-2-2h-3" />
      <path d="M3 16v3a2 2 0 002 2h3" />
      <path d="M16 21h3a2 2 0 002-2v-3" />
    </svg>
  );
}
