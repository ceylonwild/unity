import { useEffect, useRef } from 'react';
import { useSettings } from '@/lib/settings';

/** Subtle animated starfield + nebula backdrop for the UNITY shell. */
export function Starfield() {
  const { starfield } = useSettings();
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let raf = 0;
    let w = 0;
    let h = 0;
    let stars: { x: number; y: number; z: number; r: number; tw: number }[] = [];

    const resize = () => {
      w = canvas.width = window.innerWidth * window.devicePixelRatio;
      h = canvas.height = window.innerHeight * window.devicePixelRatio;
      canvas.style.width = `${window.innerWidth}px`;
      canvas.style.height = `${window.innerHeight}px`;
      const count = Math.min(160, Math.floor((w * h) / 18000));
      stars = Array.from({ length: count }, () => ({
        x: Math.random() * w,
        y: Math.random() * h,
        z: Math.random() * 0.8 + 0.2,
        r: Math.random() * 1.2 + 0.3,
        tw: Math.random() * Math.PI * 2,
      }));
    };

    const draw = (t: number) => {
      ctx.clearRect(0, 0, w, h);
      const isLight = document.documentElement.getAttribute('data-theme') === 'light';
      const starColor = isLight ? '0,0,0' : '255,255,255';
      for (const s of stars) {
        const alpha = 0.25 + 0.35 * Math.sin(t * 0.001 + s.tw) + 0.4 * s.z;
        ctx.beginPath();
        ctx.fillStyle = `rgba(${starColor},${Math.max(0, alpha) * s.z * (isLight ? 0.15 : 1)})`;
        ctx.arc(s.x, s.y, s.r * s.z, 0, Math.PI * 2);
        ctx.fill();
        // slow drift
        s.y += s.z * 0.05;
        if (s.y > h) {
          s.y = 0;
          s.x = Math.random() * w;
        }
      }
      raf = requestAnimationFrame(draw);
    };

    resize();
    raf = requestAnimationFrame(draw);
    window.addEventListener('resize', resize);
    return () => {
      cancelAnimationFrame(raf);
      window.removeEventListener('resize', resize);
    };
  }, []);

  if (!starfield) {
    return <div className="fixed inset-0 -z-10" style={{ background: 'var(--unity-bg)' }} />;
  }

  return (
    <div className="fixed inset-0 -z-10 pointer-events-none">
      {/* Base */}
      <div className="absolute inset-0" style={{ background: 'var(--unity-bg)' }} />
      {/* Nebula gradients */}
      <div className="absolute inset-0 opacity-60" style={{
        background: `radial-gradient(ellipse at 50% 0%, var(--unity-nebula-1), transparent 55%), radial-gradient(ellipse at 80% 90%, var(--unity-nebula-2), transparent 50%)`,
      }} />
      <canvas ref={canvasRef} className="absolute inset-0" style={{ opacity: 'var(--unity-starfield-opacity)' }} />
      {/* vignette */}
      <div className="absolute inset-0" style={{ background: 'radial-gradient(ellipse at center, transparent 40%, var(--unity-vignette) 100%)' }} />
    </div>
  );
}
