import { useEffect, useState } from 'react';
import type { Citizen, Post } from '@/types';
import { fetchCitizenById, fetchPostsByAuthor, isFollowingCitizen, toggleFollowCitizen, fetchSuggestedCitizens } from '@/lib/feed';
import { Avatar } from '@/components/Avatar';
import { Wordmark } from '@/components/Brand';
import { VerifiedBadge } from '@/components/VerifiedBadge';
import { CloseIcon, UserPlusIcon, UserCheckIcon, FlagIcon, PinIcon, GlobeIcon } from '@/components/icons';
import { ReportModal } from '@/components/ReportModal';
import { timeAgo, formatNumber } from '@/lib/utils';
import { useSelf } from '@/lib/self';
import { showToast } from '@/lib/toast';

export function CitizenProfileModal({
  citizenId,
  fallback,
  onClose,
}: {
  citizenId: string;
  fallback?: { name: string; handle: string; avatar: string | null; verified: boolean };
  onClose: () => void;
}) {
  const { self } = useSelf();
  const [citizen, setCitizen] = useState<Citizen | null>(null);
  const [posts, setPosts] = useState<Post[]>([]);
  const [loading, setLoading] = useState(true);
  const [tab, setTab] = useState<'posts' | 'media' | 'about'>('posts');
  const [following, setFollowing] = useState(false);
  const [followBusy, setFollowBusy] = useState(false);
  const [followers, setFollowers] = useState(0);
  const [followingCount, setFollowingCount] = useState(0);
  const [reporting, setReporting] = useState(false);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const [c, p] = await Promise.all([
          fetchCitizenById(citizenId),
          fetchPostsByAuthor(citizenId, 30),
        ]);
        if (!cancelled) {
          setCitizen(c);
          setPosts(p);
          if (c) {
            try {
              const [isF, fStats] = await Promise.all([
                isFollowingCitizen(c.id),
                fetchFollowCounts(c.id),
              ]);
              if (!cancelled) {
                setFollowing(isF);
                setFollowers(fStats.followers);
                setFollowingCount(fStats.following);
              }
            } catch { /* graceful */ }
          }
        }
      } catch {
        // graceful — fallback used below
      } finally {
        if (!cancelled) setLoading(false);
      }
    })();
    return () => { cancelled = true; };
  }, [citizenId]);

  const name = citizen?.name ?? fallback?.name ?? 'Unknown Citizen';
  const handle = citizen?.handle ?? fallback?.handle ?? 'unknown';
  const avatar = citizen?.avatar_url ?? fallback?.avatar ?? null;
  const verified = citizen?.verified ?? fallback?.verified ?? false;
  const mediaPosts = posts.filter((p) => p.image_url);
  const isSelf = self?.id === citizen?.id;

  const onFollowToggle = async () => {
    if (!citizen) return;
    setFollowBusy(true);
    try {
      const next = await toggleFollowCitizen(citizen.id, following);
      setFollowing(next);
      setFollowers((f) => f + (next ? 1 : -1));
      showToast(next ? `Following ${name}` : `Unfollowed ${name}`, 'success');
    } catch {
      showToast('Could not update follow status', 'error');
    } finally {
      setFollowBusy(false);
    }
  };

  return (
    <>
      <div className="fixed inset-0 z-[9000] flex items-center justify-center p-4 animate-fade-in" onClick={onClose}>
        <div className="absolute inset-0 bg-black/90 backdrop-blur-xl" />
        <div
          className="relative glass-strong rounded-3xl w-full max-w-md max-h-[88vh] overflow-y-auto no-scrollbar animate-scale-in"
          onClick={(e) => e.stopPropagation()}
        >
          {loading ? (
            <div className="p-8 flex items-center justify-center">
              <div className="w-7 h-7 rounded-full border-2 border-white/10 border-t-white/60 animate-spin" />
            </div>
          ) : citizen ? (
            <>
              {/* Banner */}
              {citizen.banner_url && (
                <div className="relative h-28 overflow-hidden rounded-t-3xl">
                  <img src={citizen.banner_url} alt="" className="w-full h-full object-cover" loading="lazy" />
                  <div className="absolute inset-0 bg-gradient-to-b from-transparent to-black/60" />
                </div>
              )}

              {/* Header */}
              <div className="sticky top-0 z-10 glass-strong border-b border-[#2a2a2a] p-4 flex items-center justify-between">
                <Wordmark size="sm" />
                <div className="flex items-center gap-1">
                  {!isSelf && (
                    <button onClick={() => setReporting(true)} className="btn-icon" aria-label="Report profile">
                      <FlagIcon size={16} />
                    </button>
                  )}
                  <button onClick={onClose} className="btn-icon"><CloseIcon size={20} /></button>
                </div>
              </div>

              {/* Identity hero */}
              <div className={`p-6 ${citizen.banner_url ? '-mt-12 relative' : ''}`}>
                <div className="flex gap-5">
                  <Avatar src={avatar} name={name} size={84} ring verified={verified} />
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <h2 className="text-xl font-semibold tracking-tightest truncate">{name}</h2>
                      {verified && <VerifiedBadge size={16} />}
                    </div>
                    <div className="text-sm text-white/40 mt-0.5">@{handle}</div>
                    <div className="flex flex-wrap gap-2 mt-3">
                      <span className="px-2.5 py-1 rounded-full bg-white/[0.05] border border-[#2a2a2a]/80 text-[11px] text-white/70">{citizen.country}</span>
                      <span className="px-2.5 py-1 rounded-full bg-white/[0.05] border border-[#2a2a2a]/80 text-[11px] text-white/70">{citizen.language}</span>
                    </div>
                    {citizen.bio && <p className="text-sm text-white/60 mt-3">{citizen.bio}</p>}
                  </div>
                </div>

                {/* Follow button */}
                {!isSelf && (
                  <button
                    onClick={onFollowToggle}
                    disabled={followBusy}
                    className={`mt-4 w-full py-2.5 rounded-xl font-medium text-sm transition-all flex items-center justify-center gap-2 disabled:opacity-50 ${
                      following
                        ? 'glass-panel text-white/70 hover:text-rose-400 hover:border-rose-500/30'
                        : 'btn-primary'
                    }`}
                  >
                    {following ? <><UserCheckIcon size={16} /> Following</> : <><UserPlusIcon size={16} /> Follow</>}
                  </button>
                )}

                {/* Stats */}
                <div className="grid grid-cols-4 gap-2 mt-5">
                  <Stat label="Posts" value={posts.length} />
                  <Stat label="Followers" value={followers} />
                  <Stat label="Following" value={followingCount} />
                  <Stat label="Skills" value={citizen.skills.length} />
                </div>
              </div>

              {/* Tabs */}
              <div className="px-6 flex gap-1 border-b border-[#2a2a2a]/80">
                {(['posts', 'media', 'about'] as const).map((t) => (
                  <button
                    key={t}
                    onClick={() => setTab(t)}
                    className={`px-4 py-2.5 text-sm font-medium capitalize transition-all border-b-2 ${
                      tab === t ? 'text-white border-white' : 'text-white/40 border-transparent hover:text-white/70'
                    }`}
                  >
                    {t}
                  </button>
                ))}
              </div>

              {/* Tab content */}
              <div className="p-6 pt-4">
                {tab === 'posts' && (
                  posts.length === 0 ? (
                    <p className="text-sm text-white/30 text-center py-8">No posts yet.</p>
                  ) : (
                    <div className="space-y-3">
                      {posts.map((p) => (
                        <div key={p.id} className="glass-panel rounded-xl p-4">
                          {p.featured && (
                            <div className="text-[10px] text-amber-400/80 uppercase tracking-wide mb-1.5 flex items-center gap-1">
                              <GlobeIcon size={10} /> Featured
                            </div>
                          )}
                          <p className="text-sm text-white/85 whitespace-pre-wrap line-clamp-4">{p.content}</p>
                          <div className="flex items-center gap-4 mt-3 text-xs text-white/30">
                            <span>{timeAgo(p.created_at)}</span>
                            {p.edited_at && <span className="italic">edited</span>}
                            <span>{formatNumber(p.likes_count)} likes</span>
                            <span>{formatNumber(p.comments_count)} comments</span>
                          </div>
                        </div>
                      ))}
                    </div>
                  )
                )}

                {tab === 'media' && (
                  mediaPosts.length === 0 ? (
                    <p className="text-sm text-white/30 text-center py-8">No media published.</p>
                  ) : (
                    <div className="grid grid-cols-2 gap-2">
                      {mediaPosts.map((p) => (
                        <div key={p.id} className="aspect-square rounded-xl overflow-hidden border border-[#2a2a2a]/80">
                          <img src={p.image_url!} alt="" className="w-full h-full object-cover" loading="lazy" />
                        </div>
                      ))}
                    </div>
                  )
                )}

                {tab === 'about' && (
                  <div className="space-y-4">
                    {citizen.skills.length > 0 && <DetailList title="Skills" items={citizen.skills} />}
                    {citizen.achievements.length > 0 && <DetailList title="Achievements" items={citizen.achievements} />}
                    {citizen.interests.length > 0 && <DetailList title="Interests" items={citizen.interests} />}
                    {citizen.languages.length > 0 && <DetailList title="Languages" items={citizen.languages} />}
                    <div className="glass-panel rounded-xl p-4">
                      <div className="text-[10px] text-white/40 uppercase tracking-wide mb-2">Education</div>
                      <p className="text-sm text-white/80">{citizen.education || '—'}</p>
                    </div>
                    {citizen.portfolio_links.length > 0 && (
                      <div className="glass-panel rounded-xl p-4">
                        <div className="text-[10px] text-white/40 uppercase tracking-wide mb-2">Portfolio Links</div>
                        <div className="space-y-2">
                          {citizen.portfolio_links.map((link, i) => (
                            <a key={i} href={link} target="_blank" rel="noreferrer" className="block text-sm text-white/80 hover:text-white truncate underline-offset-4 hover:underline">
                              {link}
                            </a>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                )}
              </div>

              {/* Footer */}
              <div className="flex items-center justify-between px-6 py-4 border-t border-[#2a2a2a]/80">
                <div>
                  <div className="text-[9px] tracking-[0.25em] text-white/30 uppercase">Citizen ID</div>
                  <div className="text-xs text-white/50 mt-0.5 font-mono">{citizen.id.slice(0, 8).toUpperCase()}</div>
                </div>
                <div className="text-right">
                  <div className="text-[9px] tracking-[0.25em] text-white/30 uppercase">Joined</div>
                  <div className="text-xs text-white/50 mt-0.5">{new Date(citizen.created_at).toLocaleDateString('en', { year: 'numeric', month: 'short', day: 'numeric' })}</div>
                </div>
              </div>
            </>
          ) : (
            <div className="p-8">
              <div className="flex items-center justify-between mb-6">
                <Wordmark size="sm" />
                <button onClick={onClose} className="btn-icon"><CloseIcon size={20} /></button>
              </div>
              <div className="flex gap-5">
                <Avatar src={avatar} name={name} size={84} ring verified={verified} />
                <div>
                  <h2 className="text-xl font-semibold tracking-tightest">{name}</h2>
                  <div className="text-sm text-white/40 mt-0.5">@{handle}</div>
                </div>
              </div>
              <p className="text-sm text-white/40 mt-5">Full profile details unavailable for this citizen.</p>
            </div>
          )}
        </div>
      </div>

      {reporting && (
        <ReportModal targetType="profile" targetId={citizenId} onClose={() => setReporting(false)} />
      )}
    </>
  );
}

import { supabase } from '@/lib/supabase';

async function fetchFollowCounts(citizenId: string): Promise<{ followers: number; following: number }> {
  const { data: citizen } = await supabase.from('citizens').select('user_id').eq('id', citizenId).maybeSingle();
  if (!citizen?.user_id) return { followers: 0, following: 0 };
  const [f, fo] = await Promise.all([
    supabase.from('follows').select('follower_id', { count: 'exact', head: true }).eq('following_id', citizen.user_id),
    supabase.from('follows').select('following_id', { count: 'exact', head: true }).eq('follower_id', citizen.user_id),
  ]);
  return { followers: f.count ?? 0, following: fo.count ?? 0 };
}

function Stat({ label, value }: { label: string; value: number }) {
  return (
    <div className="glass-panel rounded-xl p-2.5 text-center">
      <div className="text-base font-semibold tabular-nums">{formatNumber(value)}</div>
      <div className="text-[10px] text-white/40 uppercase tracking-wide mt-0.5">{label}</div>
    </div>
  );
}

function DetailList({ title, items }: { title: string; items: string[] }) {
  return (
    <div className="glass-panel rounded-xl p-4">
      <div className="text-[10px] text-white/40 uppercase tracking-wide mb-2">{title}</div>
      <div className="flex flex-wrap gap-1.5">
        {items.slice(0, 6).map((i, idx) => (
          <span key={idx} className="px-2 py-0.5 rounded-full bg-white/[0.05] text-[11px] text-white/70">{i}</span>
        ))}
      </div>
    </div>
  );
}
