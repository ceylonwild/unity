import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import App from './App.tsx';
import { AuthProvider } from '@/lib/auth';
import { SelfProvider } from '@/lib/self';
import { ToastHost } from '@/components/ToastHost';
import { ErrorBoundary } from '@/components/ErrorBoundary';
import './index.css';

const rootEl = document.getElementById('root');
if (!rootEl) throw new Error('Root element not found');

createRoot(rootEl).render(
  <StrictMode>
    <ErrorBoundary>
      <AuthProvider>
        <SelfProvider>
          <App />
          <ToastHost />
        </SelfProvider>
      </AuthProvider>
    </ErrorBoundary>
  </StrictMode>
);
