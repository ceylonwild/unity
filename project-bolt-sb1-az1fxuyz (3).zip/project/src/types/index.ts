export type ModuleId =
  | 'home'
  | 'planet'
  | 'citizen'
  | 'orion'
  | 'knowledge'
  | 'wallet'
  | 'communication'
  | 'governance'
  | 'space'
  | 'settings'
  | 'admin'
  | 'search'
  | 'help'
  | 'legal';

export type UserRole = 'admin' | 'moderator' | 'citizen';

export interface Citizen {
  id: string;
  user_id: string | null;
  name: string;
  handle: string;
  country: string;
  country_code: string;
  language: string;
  bio: string;
  skills: string[];
  education: string;
  achievements: string[];
  interests: string[];
  avatar_url: string | null;
  banner_url: string | null;
  portfolio_links: string[];
  languages: string[];
  verified: boolean;
  is_admin: boolean;
  role: UserRole;
  suspended: boolean;
  last_announcement_seen: string | null;
  created_at: string;
}

export interface Post {
  id: string;
  author_id: string;
  author_name: string;
  author_handle: string;
  author_avatar: string | null;
  author_verified: boolean;
  author_is_admin: boolean;
  content: string;
  image_url: string | null;
  likes_count: number;
  comments_count: number;
  saves_count: number;
  liked_by_me: boolean;
  saved_by_me: boolean;
  featured: boolean;
  edited_at: string | null;
  created_at: string;
}

export interface Comment {
  id: string;
  post_id: string;
  author_id: string;
  author_name: string;
  author_handle: string;
  author_avatar: string | null;
  author_verified: boolean;
  content: string;
  created_at: string;
}

export type NotificationType = 'follow' | 'like' | 'comment' | 'reply' | 'verification' | 'admin' | 'announcement';

export interface AppNotification {
  id: string;
  user_id: string;
  actor_id: string | null;
  type: NotificationType;
  entity_id: string | null;
  entity_type: string | null;
  message: string;
  read: boolean;
  created_at: string;
}

export type ReportTarget = 'post' | 'profile' | 'comment';
export type ReportStatus = 'open' | 'reviewed' | 'resolved' | 'dismissed';

export interface Report {
  id: string;
  reporter_id: string;
  target_type: ReportTarget;
  target_id: string;
  reason: string;
  status: ReportStatus;
  created_at: string;
}

export interface OrionMessage {
  id: string;
  role: 'user' | 'orion';
  content: string;
  mode: string;
  created_at: number;
}

export interface Transaction {
  id: string;
  type: 'credit' | 'debit';
  amount: number;
  counterparty: string;
  description: string;
  created_at: string;
}

export interface Proposal {
  id: string;
  title: string;
  description: string;
  author: string;
  status: 'active' | 'passed' | 'failed';
  votes_for: number;
  votes_against: number;
  created_at: string;
}

export interface Course {
  id: string;
  title: string;
  instructor: string;
  category: string;
  lessons: number;
  duration: string;
  level: 'Foundations' | 'Intermediate' | 'Advanced';
  progress: number;
  rating: number;
  cover: string;
}

export interface FollowCounts {
  followers: number;
  following: number;
}
