import { useState, useEffect, useCallback } from 'react';
import type { ModuleId } from '@/types';
import { Starfield } from '@/components/Starfield';
import { Wordmark, LogoGlyph } from '@/components/Brand';
import {
  HomeIcon, PlanetIcon, CitizenIcon, OrionIcon, MenuIcon,
  SearchIcon, BellIcon, CloseIcon,
} from '@/components/icons';
import { useAuth } from '@/lib/auth';
import { useSelf } from '@/lib/self';
import { useSettings } from '@/lib/settings';
import { AuthScreen } from '@/components/AuthScreen';
import { NotificationsPanel } from '@/components/NotificationsPanel';
import { fetchUnreadCount, subscribeToNotifications } from '@/lib/notifications';
import { HomeView } from '@/views/HomeView';
import { PlanetView } from '@/views/PlanetView';
import { CitizenView } from '@/views/CitizenView';
import { OrionView } from '@/views/OrionView';
import { KnowledgeView } from '@/views/KnowledgeView';
import { WalletView } from '@/views/WalletView';
import { CommunicationView } from '@/views/CommunicationView';
import { GovernanceView } from '@/views/GovernanceView';
import { SpaceView } from '@/views/SpaceView';
import { SettingsView } from '@/views/SettingsView';
import { SearchView } from '@/views/SearchView';
import { AdminView } from '@/views/AdminView';
import { HelpView } from '@/views/HelpView';
import { LegalView } from '@/views/LegalView';
import { CitizenProfilePage } from '@/views/CitizenProfilePage';
import { MenuPage } from '@/views/MenuPage';
import type { Citizen } from '@/types';

const PRIMARY_NAV: { id: ModuleId; label: string; Icon: typeof HomeIcon }[] = [
  { id: 'home', label: 'Home', Icon: HomeIcon },
  { id: 'planet', label: 'Planet', Icon: PlanetIcon },
  { id: 'citizen', label: 'Citizen', Icon: CitizenIcon },
  { id: 'orion', label: 'ORION', Icon: OrionIcon },
];

export function App() {
  const { session, initializing, isAdmin, signOut } = useAuth();
  const { self } = useSelf();
  const settings = useSettings();
  const [active, setActive] = useState<ModuleId>('home');
  const [menuOpen, setMenuOpen] = useState(false);
  const [showNotifications, setShowNotifications] = useState(false);
  const [unreadCount, setUnreadCount] = useState(0);
  const [profileCitizenId, setProfileCitizenId] = useState<string | null>(null);

  // Apply persisted theme + motion preference on load and whenever they change,
  // so light mode is active immediately — not only after visiting Settings.
  useEffect(() => {
    const root = document.documentElement;
    root.setAttribute('data-theme', settings.highContrast ? 'contrast' : settings.theme);
    root.classList.toggle('reduce-motion', settings.reduceMotion);
    root.classList.toggle('high-contrast', settings.highContrast);
  }, [settings.theme, settings.highContrast, settings.reduceMotion]);

  const refreshUnread = useCallback(async () => {
    if (!session) { setUnreadCount(0); return; }
    try { setUnreadCount(await fetchUnreadCount()); } catch { /* graceful */ }
  }, [session]);

  useEffect(() => {
    if (!session) return;
    void refreshUnread();
    const unsub = subscribeToNotifications(refreshUnread);
    return unsub;
  }, [session, refreshUnread]);

  const navigate = (id: ModuleId) => {
    setActive(id);
    setMenuOpen(false);
    setProfileCitizenId(null);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const openProfile = (citizen: Citizen) => {
    setProfileCitizenId(citizen.id);
    setMenuOpen(false);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const openProfileById = (id: string) => {
    setProfileCitizenId(id);
    setMenuOpen(false);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  if (initializing) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center gap-5">
        <div className="w-24 h-24 rounded-2xl glass flex items-center justify-center animate-orion-glow glow-soft">
          <LogoGlyph size={56} />
        </div>
        <div className="text-[10px] tracking-[0.35em] text-unity-faint uppercase">Initializing Civilization Layer</div>
      </div>
    );
  }

  if (!session) {
    return <AuthScreen />;
  }

  // Full-screen profile page
  if (profileCitizenId) {
    return (
      <div className="min-h-screen text-unity-primary">
        <Starfield />
        <CitizenProfilePage
          citizenId={profileCitizenId}
          onBack={() => { setProfileCitizenId(null); window.scrollTo({ top: 0 }); }}
          onOpenProfile={openProfile}
        />
        <BottomNav active={active} navigate={navigate} onMenu={() => setMenuOpen(true)} />
      </div>
    );
  }

  // Full-screen menu page
  if (menuOpen) {
    return (
      <div className="min-h-screen text-unity-primary">
        <Starfield />
        <MenuPage
          self={self}
          isAdmin={isAdmin}
          unreadCount={unreadCount}
          onNavigate={navigate}
          onOpenProfile={() => { if (self) openProfile(self); }}
          onShowNotifications={() => { setMenuOpen(false); setShowNotifications(true); }}
          onLogout={signOut}
          onClose={() => setMenuOpen(false)}
        />
        <BottomNav active={active} navigate={navigate} onMenu={() => setMenuOpen(false)} />
      </div>
    );
  }

  return (
    <div className="min-h-screen text-unity-primary">
      <Starfield />

      <header className="sticky top-0 z-40">
        <div className="glass border-b border-unity-border">
          <div className="mx-auto max-w-6xl px-5 h-14 flex items-center justify-between">
            <button onClick={() => navigate('home')} className="flex items-center gap-3.5 hover:opacity-80 transition-opacity">
              <LogoGlyph size={38} />
              <div className="leading-none">
                <div className="font-semibold tracking-tightest text-base text-unity-primary">UNITY</div>
                <div className="text-[9px] tracking-[0.3em] text-unity-faint uppercase">Global Civilization</div>
              </div>
            </button>
            <div className="flex items-center gap-1">
              <button onClick={() => navigate('search')} className="btn-icon" aria-label="Search">
                <SearchIcon size={18} />
              </button>
              <button onClick={() => setShowNotifications(true)} className="btn-icon relative" aria-label="Notifications">
                <BellIcon size={18} />
                {unreadCount > 0 && (
                  <span className="absolute -top-0.5 -right-0.5 min-w-[16px] h-4 px-1 rounded-full bg-rose-500 text-white text-[9px] font-bold flex items-center justify-center">
                    {unreadCount > 99 ? '99+' : unreadCount}
                  </span>
                )}
              </button>
              {self && (
                <button onClick={() => openProfile(self)} className="ml-1 shrink-0 hover:opacity-80 transition-opacity" aria-label="Your profile">
                  <div className="w-7 h-7 rounded-full overflow-hidden border border-unity-border">
                    {self.avatar_url ? (
                      <img src={self.avatar_url} alt={self.name} className="w-full h-full object-cover" />
                    ) : (
                      <div className="w-full h-full bg-unity-surface flex items-center justify-center text-[10px] font-medium text-unity-muted">
                        {self.name.split(' ').filter(Boolean).map((w) => w[0]).slice(0, 2).join('').toUpperCase()}
                      </div>
                    )}
                  </div>
                </button>
              )}
            </div>
          </div>
        </div>
      </header>

      <main className="mx-auto max-w-6xl px-5 pb-28 pt-6">
        {!self ? (
          <div className="flex flex-col items-center justify-center py-20 gap-4">
            <div className="w-8 h-8 rounded-full border-2 border-unity-border border-t-unity-muted animate-spin" />
            <p className="text-unity-muted text-sm">Loading your citizen profile…</p>
            <button
              onClick={() => window.location.reload()}
              className="btn-ghost py-2 text-xs"
            >
              Retry
            </button>
          </div>
        ) : (
        <div key={active} className="animate-fade-up">
          {active === 'home' && <HomeView onNavigate={navigate} onOpenProfile={openProfileById} />}
          {active === 'search' && <SearchView onNavigate={navigate} onOpenProfile={openProfile} />}
          {active === 'planet' && <PlanetView />}
          {active === 'citizen' && <CitizenView />}
          {active === 'orion' && <OrionView />}
          {active === 'knowledge' && <KnowledgeView />}
          {active === 'wallet' && <WalletView />}
          {active === 'communication' && <CommunicationView />}
          {active === 'governance' && <GovernanceView />}
          {active === 'space' && <SpaceView />}
          {active === 'settings' && <SettingsView onLogout={signOut} />}
          {active === 'help' && <HelpView onBack={() => navigate('home')} />}
          {active === 'legal' && <LegalView onBack={() => navigate('settings')} />}
          {active === 'admin' && isAdmin && <AdminView />}
          {active === 'admin' && !isAdmin && (
            <div className="flex items-center justify-center py-20">
              <p className="text-unity-muted text-sm">Access restricted to administrators.</p>
            </div>
          )}
        </div>
        )}
      </main>

      {showNotifications && (
        <NotificationsPanel onClose={() => { setShowNotifications(false); void refreshUnread(); }} onUnreadChange={setUnreadCount} />
      )}

      <BottomNav active={active} navigate={navigate} onMenu={() => setMenuOpen(true)} />
    </div>
  );
}

function BottomNav({ active, navigate, onMenu }: { active: ModuleId; navigate: (id: ModuleId) => void; onMenu: () => void }) {
  return (
    <nav className="fixed bottom-4 left-1/2 -translate-x-1/2 z-[8000] pointer-events-auto w-[calc(100%-2rem)] max-w-sm safe-bottom">
      <div className="glass-strong rounded-full px-2 py-2 flex items-center justify-around shadow-2xl glow-soft">
        {PRIMARY_NAV.map(({ id, label, Icon }) => {
          const isActive = active === id;
          const isOrion = id === 'orion';
          return (
            <button
              key={id}
              onClick={() => navigate(id)}
              className="group relative flex flex-col items-center justify-center w-14 h-12 rounded-full transition-all duration-300"
              aria-label={label}
            >
              <div
                className={`absolute inset-0 rounded-full transition-all duration-300 ${
                  isActive
                    ? isOrion
                      ? 'bg-unity-surface-strong animate-orion-glow'
                      : 'bg-unity-surface-strong'
                    : 'group-hover:bg-unity-surface'
                }`}
              />
              <Icon
                size={22}
                className={`relative transition-colors duration-300 ${
                  isActive ? 'text-unity-primary' : 'text-unity-muted group-hover:text-unity-primary'
                } ${isOrion && isActive ? 'animate-pulse-slow' : ''}`}
              />
              {isActive && (
                <span className="absolute -bottom-0.5 w-1 h-1 rounded-full bg-unity-primary" />
              )}
            </button>
          );
        })}
        <button
          onClick={onMenu}
          className="group relative flex flex-col items-center justify-center w-14 h-12 rounded-full transition-all duration-300"
          aria-label="Menu"
        >
          <div className="absolute inset-0 rounded-full transition-all duration-300 group-hover:bg-unity-surface" />
          <MenuIcon size={22} className="relative transition-colors duration-300 text-unity-muted group-hover:text-unity-primary" />
        </button>
      </div>
    </nav>
  );
}

export default App;
