import { useEffect, useRef, useState } from 'react';
import type { OrionMessage } from '@/types';
import { OrionIcon, SendIcon, ZapIcon, SearchIcon, KnowledgeIcon, SpaceIcon, GovernanceIcon, TrashIcon } from '@/components/icons';
import { useAuth } from '@/lib/auth';
import { showToast } from '@/lib/toast';

const MODES = [
  { id: 'assistant', label: 'Assistant', desc: 'Daily help & quick answers', Icon: ZapIcon },
  { id: 'research', label: 'Research', desc: 'Analyze information deeply', Icon: SearchIcon },
  { id: 'learning', label: 'Learning', desc: 'Teach & explain any subject', Icon: KnowledgeIcon },
  { id: 'coding', label: 'Coding', desc: 'Programming assistance', Icon: SpaceIcon },
  { id: 'planning', label: 'Planning', desc: 'Goals & strategy', Icon: GovernanceIcon },
] as const;

const SUGGESTIONS: Record<string, string[]> = {
  assistant: ['Summarize the state of fusion energy', 'Plan my day around deep work', 'What is the UNITY Citizen ID?'],
  research: ['Analyze trends in global AI regulation', 'Compare ocean vs forest carbon sinks', 'Survey space debris mitigation'],
  learning: ['Explain quantum entanglement simply', 'Teach me the basics of graph theory', 'What is the Kardashev scale?'],
  coding: ['Write a React hook for debounced search', 'Explain async/await vs promises', 'Optimize this SQL query plan'],
  planning: ['Design a 90-day learning roadmap', 'Strategy for a community launch', 'Break down a Mars settlement plan'],
};

function generateReply(mode: string, input: string): string {
  const m = input.toLowerCase();
  const base = `ORION · ${MODES.find((x) => x.id === mode)?.label} mode\n\n`;
  if (mode === 'coding') {
    if (m.includes('hook') || m.includes('debounce')) {
      return `${base}Here's a typed debounced-search hook:\n\n\`\`\`ts\nfunction useDebounced<T>(value: T, delay = 300): T {\n  const [v, setV] = useState(value);\n  useEffect(() => {\n    const t = setTimeout(() => setV(value), delay);\n    return () => clearTimeout(t);\n  }, [value, delay]);\n  return v;\n}\n\`\`\`\n\nIt returns the value only after the user stops typing for \`delay\` ms. Drop it in front of a fetch to avoid spamming your API.`;
    }
    return `${base}Approach: break the problem into inputs, transformation, and output. Identify the invariants, then write the smallest function that satisfies them. Add types at the boundaries. Share the specific code and I'll refine it line by line.`;
  }
  if (mode === 'research') {
    return `${base}Synthesis across current sources:\n\n• The dominant signal is acceleration — adoption curves are compressing.\n• Secondary signal: regulatory and ethical frameworks lag capability by ~18–36 months.\n• Counter-signal: open, decentralized alternatives are growing faster than incumbent platforms in several regions.\n\nRecommendation: monitor the gap between capability and governance as the leading indicator. I can produce a full literature map on request.`;
  }
  if (mode === 'learning') {
    return `${base}Let's build intuition first.\n\n1. The core idea — a system where the whole is more than the sum of its parts.\n2. A simple model — start with two connected elements and observe emergent behavior.\n3. A real example — this appears everywhere from neural networks to ecosystems.\n\nWant me to go deeper on any of these, or generate exercises to test your understanding?`;
  }
  if (mode === 'planning') {
    return `${base}Strategic frame:\n\n• North star: define the single outcome that matters most in 90 days.\n• Phase 1 (weeks 1–3): foundations — remove blockers, gather resources.\n• Phase 2 (weeks 4–8): compounding work — the actions that build on each other.\n• Phase 3 (weeks 9–12): integration and review.\n\nWeekly checkpoint: one question — "did last week's work make this week's easier?" If not, restructure.`;
  }
  return `${base}Here's my take: ${input.length > 60 ? input.slice(0, 60) + '…' : input} — this connects to several deeper threads across knowledge, governance, and infrastructure. I can research it, teach the fundamentals, or help you act on it. Which direction is most useful?`;
}

const HISTORY_KEY = 'unity:orion_history';

export function OrionView() {
  const { user } = useAuth();
  const [mode, setMode] = useState<string>('assistant');
  const [messages, setMessages] = useState<OrionMessage[]>([]);
  const [input, setInput] = useState('');
  const [typing, setTyping] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  const storageKey = user ? `${HISTORY_KEY}:${user.id}` : HISTORY_KEY;

  useEffect(() => {
    try {
      const saved = localStorage.getItem(storageKey);
      if (saved) setMessages(JSON.parse(saved));
      else setMessages([]);
    } catch { /* ignore */ }
  }, [storageKey]);

  useEffect(() => {
    if (messages.length > 0) {
      localStorage.setItem(storageKey, JSON.stringify(messages.slice(-50)));
    }
  }, [messages, storageKey]);

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: 'smooth' });
  }, [messages, typing]);

  const send = (text: string) => {
    const t = text.trim();
    if (!t || typing) return;
    const userMsg: OrionMessage = { id: crypto.randomUUID(), role: 'user', content: t, mode, created_at: Date.now() };
    setMessages((prev) => [...prev, userMsg]);
    setInput('');
    setTyping(true);
    setTimeout(() => {
      const reply: OrionMessage = {
        id: crypto.randomUUID(),
        role: 'orion',
        content: generateReply(mode, t),
        mode,
        created_at: Date.now(),
      };
      setMessages((prev) => [...prev, reply]);
      setTyping(false);
    }, 900 + Math.random() * 700);
  };

  const clearHistory = () => {
    setMessages([]);
    localStorage.removeItem(storageKey);
    showToast('Conversation cleared', 'success');
  };

  const currentMode = MODES.find((m) => m.id === mode)!;

  return (
    <div className="space-y-4">
      <div className="card p-6 relative overflow-hidden animate-fade-up">
        <div className="absolute -right-10 -top-10 w-48 h-48 rounded-full bg-unity-surface blur-3xl animate-orion-glow" />
        <div className="relative flex items-center gap-4">
          <div className="relative">
            <div className="w-14 h-14 rounded-2xl bg-unity-surface border border-unity-border flex items-center justify-center">
              <OrionIcon size={28} className="text-unity-primary animate-pulse-slow" />
            </div>
          </div>
          <div className="flex-1">
            <div className="flex items-center gap-2">
              <h1 className="text-2xl font-semibold tracking-tightest">ORION</h1>
              <span className="px-2 py-0.5 rounded-full bg-emerald-400/10 border border-emerald-400/20 text-[10px] text-emerald-300 tracking-wide">ONLINE</span>
            </div>
            <p className="text-sm text-unity-muted mt-0.5">{currentMode.desc}</p>
          </div>
          {messages.length > 0 && (
            <button onClick={clearHistory} className="btn-icon" aria-label="Clear conversation"><TrashIcon size={16} /></button>
          )}
        </div>
      </div>

      <div className="flex gap-2 overflow-x-auto no-scrollbar pb-1">
        {MODES.map((m) => (
          <button
            key={m.id}
            onClick={() => setMode(m.id)}
            className={`shrink-0 flex items-center gap-2 px-4 py-2.5 rounded-full text-sm border transition-all ${
              mode === m.id ? 'bg-unity-btn-primary-bg text-unity-btn-primary-text border-transparent' : 'bg-unity-surface text-unity-muted border-unity-border hover:bg-unity-surface-strong'
            }`}
          >
            <m.Icon size={15} />
            {m.label}
          </button>
        ))}
      </div>

      <div className="card p-0 overflow-hidden flex flex-col" style={{ height: 'min(60vh, 560px)' }}>
        <div ref={scrollRef} className="flex-1 overflow-y-auto p-5 space-y-4">
          {messages.length === 0 ? (
            <div className="h-full flex flex-col items-center justify-center text-center px-6">
              <OrionIcon size={40} className="text-unity-faint mb-4 animate-pulse-slow" />
              <h3 className="text-lg font-medium mb-1">ORION is ready</h3>
              <p className="text-sm text-unity-faint max-w-xs">Ask anything. I assist, research, teach, code, and plan — across the entire knowledge layer.</p>
              <div className="grid sm:grid-cols-2 gap-2 mt-6 w-full max-w-md">
                {SUGGESTIONS[mode].map((s) => (
                  <button key={s} onClick={() => send(s)} className="glass-panel rounded-xl p-3 text-left text-sm text-unity-muted hover:bg-unity-surface-strong transition-all hover:text-unity-primary">{s}</button>
                ))}
              </div>
            </div>
          ) : (
            messages.map((m) => <MessageBubble key={m.id} msg={m} />)
          )}
          {typing && (
            <div className="flex gap-3 animate-fade-in">
              <div className="w-8 h-8 rounded-full bg-unity-surface border border-unity-border flex items-center justify-center shrink-0">
                <OrionIcon size={16} className="text-unity-muted animate-pulse-slow" />
              </div>
              <div className="glass-panel rounded-2xl px-4 py-3 flex items-center gap-1">
                {[0, 1, 2].map((i) => (
                  <span key={i} className="w-1.5 h-1.5 rounded-full bg-unity-muted" style={{ animation: `pulseSlow 1s ${i * 0.2}s infinite` }} />
                ))}
              </div>
            </div>
          )}
        </div>

        <div className="border-t border-unity-border p-3">
          <div className="flex items-center gap-2">
            <input
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && send(input)}
              placeholder={`Message ORION · ${currentMode.label}…`}
              className="flex-1 input-field rounded-full"
            />
            <button onClick={() => send(input)} disabled={!input.trim() || typing} className="w-10 h-10 rounded-full bg-unity-btn-primary-bg text-unity-btn-primary-text flex items-center justify-center disabled:opacity-30 transition-all active:scale-95">
              <SendIcon size={16} />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

function MessageBubble({ msg }: { msg: OrionMessage }) {
  const isOrion = msg.role === 'orion';
  const segments = renderContent(msg.content);
  return (
    <div className={`flex gap-3 animate-fade-up ${isOrion ? '' : 'flex-row-reverse'}`}>
      <div className={`w-8 h-8 rounded-full flex items-center justify-center shrink-0 ${isOrion ? 'bg-unity-surface border border-unity-border' : 'bg-unity-surface-strong'}`}>
        {isOrion ? <OrionIcon size={16} className="text-unity-muted" /> : <span className="text-xs text-unity-muted">You</span>}
      </div>
      <div className={`max-w-[80%] rounded-2xl px-4 py-3 ${isOrion ? 'glass-panel' : 'bg-unity-surface-strong border border-unity-border'}`}>
        <div className="text-sm leading-relaxed text-unity-primary space-y-2">
          {segments.map((seg, i) => seg.kind === 'code' ? (
            <pre key={i} className="bg-black/40 rounded-lg p-3 overflow-x-auto text-xs font-mono text-unity-muted my-1">{seg.text}</pre>
          ) : (
            <p key={i} className="whitespace-pre-wrap">{seg.text}</p>
          ))}
        </div>
      </div>
    </div>
  );
}

function renderContent(content: string): { kind: 'text' | 'code'; text: string }[] {
  const parts: { kind: 'text' | 'code'; text: string }[] = [];
  const regex = /```(\w*)\n?([\s\S]*?)```/g;
  let last = 0;
  let match;
  while ((match = regex.exec(content)) !== null) {
    if (match.index > last) parts.push({ kind: 'text', text: content.slice(last, match.index).trim() });
    parts.push({ kind: 'code', text: match[2].trim() });
    last = regex.lastIndex;
  }
  if (last < content.length) parts.push({ kind: 'text', text: content.slice(last).trim() });
  return parts.length ? parts : [{ kind: 'text', text: content }];
}
