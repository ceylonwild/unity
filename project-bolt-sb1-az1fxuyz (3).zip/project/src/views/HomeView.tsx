import { useCallback, useEffect, useState } from 'react';
import type { Post, ModuleId } from '@/types';
import { fetchPosts, subscribeToPosts } from '@/lib/feed';
import { useSelf } from '@/lib/self';
import { PostCard } from '@/components/PostCard';
import { Composer } from '@/components/Composer';
import { Wordmark } from '@/components/Brand';
import { OrionIcon, TrendingIcon, ZapIcon, KnowledgeIcon } from '@/components/icons';

export function HomeView({ onNavigate, onOpenProfile }: { onNavigate: (id: ModuleId) => void; onOpenProfile?: (citizenId: string) => void }) {
  const { self } = useSelf();
  const [posts, setPosts] = useState<Post[]>([]);
  const [loadingPosts, setLoadingPosts] = useState(true);
  const [error, setError] = useState(false);
  const [refreshKey, setRefreshKey] = useState(0);

  const load = useCallback(async () => {
    setLoadingPosts(true);
    setError(false);
    try {
      setPosts(await fetchPosts());
    } catch {
      setError(true);
    } finally {
      setLoadingPosts(false);
    }
  }, []);

  useEffect(() => {
    load();
  }, [load, refreshKey]);

  // Realtime: refetch on any social-table change (new post, like, save, comment).
  useEffect(() => {
    const unsub = subscribeToPosts(() => { void load(); });
    return unsub;
  }, [load]);

  const updatePost = (p: Post) => {
    setPosts((prev) => prev.map((x) => (x.id === p.id ? p : x)));
  };

  return (
    <div className="grid lg:grid-cols-[1fr_300px] gap-6">
      {/* Feed column */}
      <div className="space-y-4">
        {/* Hero / status strip for first-time feel */}
        <div className="card p-5 mb-1 relative overflow-hidden animate-fade-up">
          <div className="absolute -right-10 -top-10 w-40 h-40 rounded-full bg-white/[0.03] blur-2xl" />
          <div className="relative flex items-center justify-between">
            <div>
              <div className="text-xs tracking-[0.3em] text-white/40 uppercase mb-1">Home Feed</div>
              <h1 className="text-2xl font-semibold tracking-tightest">Welcome back, {self?.name.split(' ')[0] ?? 'Citizen'}</h1>
              <p className="text-sm text-white/50 mt-1">Ideas and signals from across civilization.</p>
            </div>
            <Wordmark size="sm" />
          </div>
        </div>

        <Composer onPosted={() => setRefreshKey((k) => k + 1)} />

        {/* Smart feed suggestions */}
        <div className="flex items-center gap-2 px-1 pt-2">
          <ZapIcon size={14} className="text-white/40" />
          <span className="text-xs text-white/40 tracking-wide uppercase">Smart Feed · AI-curated</span>
        </div>

        {loadingPosts ? (
          <div className="space-y-4">
            {[0, 1, 2].map((i) => (
              <div key={i} className="card p-5 space-y-3">
                <div className="flex gap-3">
                  <div className="w-11 h-11 rounded-full bg-white/[0.06] animate-shimmer" />
                  <div className="flex-1 space-y-2">
                    <div className="h-3 w-32 rounded bg-white/[0.06] animate-shimmer" />
                    <div className="h-2 w-20 rounded bg-white/[0.04] animate-shimmer" />
                  </div>
                </div>
                <div className="h-3 w-full rounded bg-white/[0.04] animate-shimmer" />
                <div className="h-3 w-4/5 rounded bg-white/[0.04] animate-shimmer" />
              </div>
            ))}
          </div>
        ) : error ? (
          <div className="card p-8 text-center">
            <p className="text-white/60">We couldn't load the feed right now.</p>
            <button onClick={load} className="btn-ghost mt-4">Try again</button>
          </div>
        ) : posts.length === 0 ? (
          <div className="card p-8 text-center">
            <p className="text-white/50">The feed is quiet. Be the first to share.</p>
          </div>
        ) : (
          <div className="space-y-4">
            {posts.map((p) => (
              <PostCard key={p.id} post={p} onChange={updatePost} onOpenProfile={onOpenProfile} videoPosts={posts} />
            ))}
          </div>
        )}
      </div>

      {/* Right rail — trending + ORION prompt */}
      <aside className="hidden lg:flex flex-col gap-4 sticky top-20 self-start max-h-[calc(100vh-6rem)] overflow-y-auto no-scrollbar pb-4">
        <div className="card p-5">
          <div className="flex items-center gap-2 mb-4">
            <TrendingIcon size={16} className="text-white/50" />
            <span className="text-sm font-medium">Trending in Civilization</span>
          </div>
          <ul className="space-y-3">
            {[
              { tag: 'Knowledge Commons', count: '12.4k' },
              { tag: 'Climate Restoration', count: '8.1k' },
              { tag: 'Citizen ID Protocol', count: '6.7k' },
              { tag: 'Orbital Economy', count: '4.3k' },
              { tag: 'AI Alignment', count: '3.9k' },
            ].map((t) => (
              <li key={t.tag} className="group cursor-pointer">
                <div className="text-sm font-medium group-hover:text-white text-white/80 transition-colors">{t.tag}</div>
                <div className="text-xs text-white/30 mt-0.5">{t.count} discussions</div>
              </li>
            ))}
          </ul>
        </div>

        <button
          onClick={() => onNavigate('orion')}
          className="card p-5 text-left hover:bg-white/[0.06] transition-all group relative overflow-hidden"
        >
          <div className="absolute -right-8 -top-8 w-32 h-32 rounded-full bg-white/[0.04] blur-2xl group-hover:bg-white/[0.07] transition-all" />
          <div className="relative">
            <div className="flex items-center gap-2 mb-2">
              <OrionIcon size={18} className="text-white animate-pulse-slow" />
              <span className="text-sm font-medium">Ask ORION</span>
            </div>
            <p className="text-xs text-white/50 leading-relaxed">
              Your AI intelligence system — research, learning, coding, planning. Always on.
            </p>
          </div>
        </button>

        <button
          onClick={() => onNavigate('knowledge')}
          className="card p-5 text-left hover:bg-white/[0.06] transition-all group"
        >
          <div className="flex items-center gap-2 mb-2">
            <KnowledgeIcon size={18} className="text-white/60 group-hover:text-white transition-colors" />
            <span className="text-sm font-medium">Continue Learning</span>
          </div>
          <p className="text-xs text-white/50 leading-relaxed">
            3 courses in progress. Resume where you left off.
          </p>
        </button>
      </aside>
    </div>
  );
}
