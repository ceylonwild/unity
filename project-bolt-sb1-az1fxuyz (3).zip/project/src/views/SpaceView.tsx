import { useState } from 'react';
import { SpaceIcon, ArrowRightIcon, ZapIcon } from '@/components/icons';
import { useCountUp, formatNumber } from '@/lib/utils';

const MISSIONS = [
  { id: '1', name: 'Skylon-X Orbital Stack', agency: 'UNITY Aerospace', status: 'active', progress: 68, desc: 'Reusable orbital delivery system for low-cost access to LEO.', cover: 'https://images.pexels.com/photos/73871/space-satellite-dish-radio-telescope-73871.jpeg?auto=compress&cs=tinysrgb&w=800' },
  { id: '2', name: 'Helios Solar Array', agency: 'Planetary Energy', status: 'planning', progress: 12, desc: 'Orbital solar collection beaming power to surface stations.', cover: 'https://images.pexels.com/photos/4109998/pexels-photo-4109998.jpeg?auto=compress&cs=tinysrgb&w=800' },
  { id: '3', name: 'Areo Habitat Phase 1', agency: 'UNITY Space', status: 'research', progress: 34, desc: 'Pressurized habitat modules for sustained Mars presence.', cover: 'https://images.pexels.com/photos/3989815/pexels-photo-3989815.jpeg?auto=compress&cs=tinysrgb&w=800' },
  { id: '4', name: 'Deep Field Survey', agency: 'Orion Observatory', status: 'active', progress: 82, desc: 'Mapping exoplanet candidates within 50 light-years.', cover: 'https://images.pexels.com/photos/110854/pexels-photo-110854.jpeg?auto=compress&cs=tinysrgb&w=800' },
];

const STATS = [
  { label: 'Active Missions', value: 47, suffix: '' },
  { label: 'Orbital Objects', value: 12400, suffix: '' },
  { label: 'Research Papers', value: 8200, suffix: '' },
  { label: 'Partner Agencies', value: 28, suffix: '' },
];

export function SpaceView() {
  const [selected, setSelected] = useState<typeof MISSIONS[number] | null>(null);

  if (selected) {
    return (
      <div className="space-y-5 animate-fade-up max-w-3xl mx-auto">
        <button onClick={() => setSelected(null)} className="text-sm text-white/50 hover:text-white transition-colors flex items-center gap-1.5">
          <ArrowRightIcon size={16} className="rotate-180" /> All missions
        </button>
        <div className="card p-0 overflow-hidden">
          <div className="relative h-64">
            <img src={selected.cover} alt="" className="w-full h-full object-cover" />
            <div className="absolute inset-0 bg-gradient-to-t from-black via-black/40 to-transparent" />
            <div className="absolute bottom-5 left-5 right-5">
              <span className="px-2.5 py-1 rounded-full bg-white/10 backdrop-blur text-[11px] border border-white/20 capitalize">{selected.status}</span>
              <h1 className="text-2xl font-semibold tracking-tightest mt-2">{selected.name}</h1>
              <p className="text-sm text-white/60">{selected.agency}</p>
            </div>
          </div>
          <div className="p-6">
            <p className="text-white/70 leading-relaxed">{selected.desc}</p>
            <div className="mt-5">
              <div className="flex justify-between text-sm text-white/50 mb-2"><span>Mission Progress</span><span>{selected.progress}%</span></div>
              <div className="h-2 rounded-full bg-white/[0.06] overflow-hidden"><div className="h-full bg-white/40 rounded-full transition-all duration-1000" style={{ width: `${selected.progress}%` }} /></div>
            </div>
            <div className="grid grid-cols-3 gap-3 mt-6">
              {[{ l: 'Phase', v: '2 of 4' }, { l: 'Timeline', v: '2027' }, { l: 'Budget', v: '4.2M UC' }].map((s) => (
                <div key={s.l} className="glass-panel rounded-xl p-3 text-center"><div className="text-lg font-semibold">{s.v}</div><div className="text-xs text-white/40">{s.l}</div></div>
              ))}
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="card p-7 relative overflow-hidden animate-fade-up">
        <div className="absolute inset-0 opacity-50" style={{ background: 'radial-gradient(ellipse at 80% 30%, rgba(60,80,120,0.2), transparent 55%)' }} />
        <div className="relative">
          <div className="flex items-center gap-2 mb-2">
            <SpaceIcon size={18} className="text-white/60" />
            <span className="text-xs tracking-[0.3em] text-white/40 uppercase">Space Module</span>
          </div>
          <h1 className="text-3xl font-semibold tracking-tightest">Exploration Hub</h1>
          <p className="text-white/50 mt-2 max-w-xl">Missions, science, research, and technology advancing humanity beyond the surface.</p>
        </div>
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        {STATS.map((s, i) => <StatCard key={s.label} {...s} delay={i * 80} />)}
      </div>

      <div className="flex items-center gap-2 px-1">
        <ZapIcon size={14} className="text-white/40" />
        <span className="text-xs text-white/40 tracking-wide uppercase">Active Missions</span>
      </div>

      <div className="grid sm:grid-cols-2 gap-4">
        {MISSIONS.map((m, i) => (
          <button key={m.id} onClick={() => setSelected(m)} className="card p-0 overflow-hidden text-left hover:bg-white/[0.06] transition-all group animate-fade-up" style={{ animationDelay: `${i * 70}ms` }}>
            <div className="relative h-40 overflow-hidden">
              <img src={m.cover} alt="" className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />
              <div className="absolute inset-0 bg-gradient-to-t from-black/90 to-transparent" />
              <span className="absolute top-3 left-3 px-2.5 py-1 rounded-full bg-black/60 backdrop-blur text-[11px] text-white/80 border border-white/10 capitalize">{m.status}</span>
            </div>
            <div className="p-4">
              <h3 className="font-medium leading-snug">{m.name}</h3>
              <div className="text-xs text-white/40 mt-0.5">{m.agency}</div>
              <p className="text-sm text-white/50 mt-2 line-clamp-2">{m.desc}</p>
              <div className="mt-3 h-1.5 rounded-full bg-white/[0.06] overflow-hidden">
                <div className="h-full bg-white/40 rounded-full transition-all duration-1000" style={{ width: `${m.progress}%` }} />
              </div>
            </div>
          </button>
        ))}
      </div>
    </div>
  );
}

function StatCard({ label, value, suffix, delay }: { label: string; value: number; suffix: string; delay: number }) {
  const v = useCountUp(value, 1400);
  return (
    <div className="card p-5 animate-fade-up" style={{ animationDelay: `${delay}ms` }}>
      <div className="text-2xl font-semibold tracking-tightest">{formatNumber(v)}{suffix}</div>
      <div className="text-xs text-white/40 mt-1">{label}</div>
    </div>
  );
}
