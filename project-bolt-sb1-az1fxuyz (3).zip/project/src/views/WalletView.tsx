import { useCallback, useEffect, useState } from 'react';
import { WalletIcon, ArrowRightIcon, QrIcon, SendIcon, ZapIcon, CloseIcon } from '@/components/icons';
import { useCountUp, formatNumber } from '@/lib/utils';
import { useSelf } from '@/lib/self';
import { fetchWalletTransactions, getWalletBalance, sendCredits, seedStipend, subscribeToWallet, type WalletTxnRow } from '@/lib/modules';
import { showToast } from '@/lib/toast';

export function WalletView() {
  const { self } = useSelf();
  const [balance, setBalance] = useState(0);
  const [txns, setTxns] = useState<WalletTxnRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [showSend, setShowSend] = useState(false);
  const animatedBalance = useCountUp(balance, 1200);

  const load = useCallback(async () => {
    if (!self) return;
    setLoading(true);
    try {
      await seedStipend(self.id);
      const [bal, list] = await Promise.all([getWalletBalance(self.id), fetchWalletTransactions(self.id)]);
      setBalance(bal);
      setTxns(list);
    } catch { showToast('Could not load wallet', 'error'); }
    finally { setLoading(false); }
  }, [self]);

  useEffect(() => { void load(); }, [load]);
  useEffect(() => { const unsub = subscribeToWallet(() => void load()); return unsub; }, [load]);

  const creditsEarned = txns.filter((t) => t.type === 'credit').reduce((s, t) => s + t.amount, 0);

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-2 mb-1">
        <WalletIcon size={16} className="text-unity-muted" />
        <span className="text-xs tracking-[0.3em] text-unity-faint uppercase">Wallet</span>
      </div>

      <div className="card p-7 relative overflow-hidden animate-fade-up">
        <div className="absolute -right-12 -top-12 w-48 h-48 rounded-full bg-unity-surface blur-3xl" />
        <div className="relative">
          <div className="text-xs text-unity-faint uppercase tracking-wide">Total Balance</div>
          <div className="flex items-baseline gap-2 mt-2">
            <span className="text-4xl font-semibold tracking-tightest">{formatNumber(animatedBalance)}</span>
            <span className="text-unity-faint text-sm">UC</span>
          </div>
          <div className="flex items-center gap-1.5 mt-2 text-xs text-emerald-400/80">
            <ZapIcon size={12} />
            <span>{loading ? 'Loading…' : `${formatNumber(creditsEarned)} UC earned total`}</span>
          </div>
          <div className="flex gap-2 mt-6">
            <button onClick={() => setShowSend(true)} className="btn-primary flex-1 py-2.5"><SendIcon size={16} /> Send</button>
            <button className="btn-ghost flex-1 py-2.5"><QrIcon size={16} /> Receive</button>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-3 gap-3">
        {[
          { label: 'Credits Earned', value: loading ? '—' : formatNumber(creditsEarned) },
          { label: 'Transactions', value: loading ? '—' : String(txns.length) },
          { label: 'Balance', value: loading ? '—' : formatNumber(balance) },
        ].map((s) => (
          <div key={s.label} className="card p-4 text-center animate-fade-up">
            <div className="text-xl font-semibold">{s.value}</div>
            <div className="text-[11px] text-unity-faint mt-0.5">{s.label}</div>
          </div>
        ))}
      </div>

      <div className="card p-5 animate-fade-up">
        <h2 className="font-medium mb-4">Recent Activity</h2>
        {loading ? (
          <div className="space-y-2">{[0, 1, 2].map((i) => <div key={i} className="h-12 rounded-lg animate-shimmer" />)}</div>
        ) : txns.length === 0 ? (
          <p className="text-sm text-unity-muted text-center py-4">No transactions yet.</p>
        ) : (
          <div className="space-y-1">
            {txns.map((t) => (
              <div key={t.id} className="flex items-center gap-3 py-3 border-b border-unity-border last:border-0">
                <div className={`w-10 h-10 rounded-full flex items-center justify-center ${t.type === 'credit' ? 'bg-emerald-400/10 text-emerald-300' : 'bg-unity-surface text-unity-muted'}`}>
                  {t.type === 'credit' ? <ArrowRightIcon size={16} className="rotate-180" /> : <ArrowRightIcon size={16} />}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="text-sm font-medium truncate">{t.counterparty}</div>
                  <div className="text-xs text-unity-faint truncate">{t.description}</div>
                </div>
                <div className={`text-sm font-medium ${t.type === 'credit' ? 'text-emerald-300' : 'text-unity-muted'}`}>
                  {t.type === 'credit' ? '+' : '−'}{t.amount} UC
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {showSend && self && <SendModal citizenId={self.id} onClose={() => setShowSend(false)} onSent={() => { setShowSend(false); void load(); }} />}
    </div>
  );
}

function SendModal({ citizenId, onClose, onSent }: { citizenId: string; onClose: () => void; onSent: () => void }) {
  const [recipient, setRecipient] = useState('');
  const [amount, setAmount] = useState('');
  const [note, setNote] = useState('');
  const [busy, setBusy] = useState(false);

  const submit = async () => {
    if (!recipient.trim() || !amount) return;
    setBusy(true);
    try {
      await sendCredits(citizenId, recipient.trim(), parseInt(amount, 10), note.trim());
      showToast('Credits sent', 'success');
      onSent();
    } catch (e) {
      showToast(e instanceof Error ? e.message : 'Transfer failed', 'error');
    } finally { setBusy(false); }
  };

  return (
    <div className="fixed inset-0 z-[9000] flex items-center justify-center p-5 animate-fade-in" onClick={onClose}>
      <div className="absolute inset-0 bg-black/80 backdrop-blur-md" />
      <div className="relative glass-strong rounded-3xl p-7 max-w-sm w-full animate-scale-in" onClick={(e) => e.stopPropagation()}>
        <div className="flex items-center justify-between mb-5">
          <h3 className="text-lg font-semibold">Send Credits</h3>
          <button onClick={onClose} className="btn-icon w-8 h-8"><CloseIcon size={18} /></button>
        </div>
        <div className="space-y-4">
          <div><label className="text-xs text-unity-faint mb-1.5 block">Recipient</label><input value={recipient} onChange={(e) => setRecipient(e.target.value)} placeholder="@citizen" className="input-field" autoFocus /></div>
          <div><label className="text-xs text-unity-faint mb-1.5 block">Amount (UC)</label><input type="number" value={amount} onChange={(e) => setAmount(e.target.value)} placeholder="0" className="input-field" /></div>
          <div><label className="text-xs text-unity-faint mb-1.5 block">Note (optional)</label><input value={note} onChange={(e) => setNote(e.target.value)} placeholder="What's this for?" className="input-field" /></div>
          <button onClick={submit} disabled={busy || !recipient.trim() || !amount} className="btn-primary w-full disabled:opacity-40">{busy ? 'Sending…' : 'Confirm Send'}</button>
        </div>
      </div>
    </div>
  );
}
