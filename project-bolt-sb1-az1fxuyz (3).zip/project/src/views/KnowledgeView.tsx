import { useState } from 'react';
import type { Course } from '@/types';
import { KnowledgeIcon, SearchIcon, ArrowRightIcon, CheckIcon, ZapIcon } from '@/components/icons';

const COURSES: Course[] = [
  { id: '1', title: 'Foundations of Systems Thinking', instructor: 'Aria Voss', category: 'Systems', lessons: 24, duration: '6h 20m', level: 'Foundations', progress: 65, rating: 4.9, cover: 'https://images.pexels.com/photos/1181271/pexels-photo-1181271.jpeg?auto=compress&cs=tinysrgb&w=600' },
  { id: '2', title: 'Climate Restoration Engineering', instructor: 'Lena Marchetti', category: 'Climate', lessons: 32, duration: '9h 10m', level: 'Advanced', progress: 20, rating: 4.8, cover: 'https://images.pexels.com/photos/957024/forest-park-bench-957024.jpeg?auto=compress&cs=tinysrgb&w=600' },
  { id: '3', title: 'Knowledge Graphs from Scratch', instructor: 'Kaito Nakamura', category: 'Computer Science', lessons: 18, duration: '5h 40m', level: 'Intermediate', progress: 0, rating: 4.7, cover: 'https://images.pexels.com/photos/1181467/pexels-photo-1181467.jpeg?auto=compress&cs=tinysrgb&w=600' },
  { id: '4', title: 'Designing AI Interfaces', instructor: 'Sofia Reyes', category: 'Design', lessons: 15, duration: '4h 05m', level: 'Intermediate', progress: 100, rating: 5.0, cover: 'https://images.pexels.com/photos/196645/pexels-photo-196645.jpeg?auto=compress&cs=tinysrgb&w=600' },
  { id: '5', title: 'Orbital Mechanics Essentials', instructor: 'Yuki Tanaka', category: 'Space', lessons: 28, duration: '8h 30m', level: 'Advanced', progress: 0, rating: 4.8, cover: 'https://images.pexels.com/photos/73871/space-satellite-dish-radio-telescope-73871.jpeg?auto=compress&cs=tinysrgb&w=600' },
  { id: '6', title: 'Inclusive Civic Technology', instructor: 'Marcus Okafor', category: 'Society', lessons: 20, duration: '5h 50m', level: 'Foundations', progress: 10, rating: 4.6, cover: 'https://images.pexels.com/photos/1181396/pexels-photo-1181396.jpeg?auto=compress&cs=tinysrgb&w=600' },
];

const CATEGORIES = ['All', 'Systems', 'Climate', 'Computer Science', 'Design', 'Space', 'Society'];

export function KnowledgeView() {
  const [category, setCategory] = useState('All');
  const [query, setQuery] = useState('');
  const [selected, setSelected] = useState<Course | null>(null);

  const filtered = COURSES.filter((c) =>
    (category === 'All' || c.category === category) &&
    (query === '' || c.title.toLowerCase().includes(query.toLowerCase()) || c.instructor.toLowerCase().includes(query.toLowerCase()))
  );

  const inProgress = COURSES.filter((c) => c.progress > 0 && c.progress < 100);

  if (selected) {
    return <CourseDetail course={selected} onBack={() => setSelected(null)} />;
  }

  return (
    <div className="space-y-6">
      <div className="card p-6 animate-fade-up">
        <div className="flex items-center gap-2 mb-2">
          <KnowledgeIcon size={18} className="text-white/50" />
          <span className="text-xs tracking-[0.3em] text-white/40 uppercase">Knowledge Hub</span>
        </div>
        <h1 className="text-3xl font-semibold tracking-tightest">Global Learning Ecosystem</h1>
        <p className="text-white/50 mt-2 max-w-xl">A unified knowledge network — courses, learning paths, and progress tracking from educators across civilization.</p>
      </div>

      {inProgress.length > 0 && (
        <div>
          <div className="flex items-center gap-2 mb-3 px-1">
            <ZapIcon size={14} className="text-white/40" />
            <span className="text-xs text-white/40 tracking-wide uppercase">Continue Learning</span>
          </div>
          <div className="grid sm:grid-cols-2 gap-3">
            {inProgress.map((c) => (
              <button key={c.id} onClick={() => setSelected(c)} className="card p-4 text-left flex gap-4 hover:bg-white/[0.06] transition-all group">
                <img src={c.cover} alt="" className="w-20 h-20 rounded-xl object-cover shrink-0" />
                <div className="flex-1 min-w-0">
                  <div className="font-medium text-sm truncate">{c.title}</div>
                  <div className="text-xs text-white/40 mt-0.5">{c.instructor}</div>
                  <div className="mt-3">
                    <div className="flex justify-between text-[11px] text-white/40 mb-1">
                      <span>Progress</span><span>{c.progress}%</span>
                    </div>
                    <div className="h-1.5 rounded-full bg-white/[0.06] overflow-hidden">
                      <div className="h-full bg-white/40 rounded-full" style={{ width: `${c.progress}%` }} />
                    </div>
                  </div>
                </div>
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Search */}
      <div className="relative">
        <SearchIcon size={18} className="absolute left-4 top-1/2 -translate-y-1/2 text-white/30" />
        <input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Search courses, instructors…" className="input-field pl-11" />
      </div>

      <div className="flex gap-2 overflow-x-auto no-scrollbar pb-1">
        {CATEGORIES.map((c) => (
          <button key={c} onClick={() => setCategory(c)} className={`shrink-0 px-4 py-2 rounded-full text-sm border transition-all ${category === c ? 'bg-white text-black border-white' : 'bg-white/[0.04] text-white/60 border-white/[0.08] hover:bg-white/[0.08]'}`}>{c}</button>
        ))}
      </div>

      <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {filtered.map((c, i) => (
          <button key={c.id} onClick={() => setSelected(c)} className="card p-0 overflow-hidden text-left hover:bg-white/[0.06] transition-all group animate-fade-up" style={{ animationDelay: `${i * 60}ms` }}>
            <div className="relative h-40 overflow-hidden">
              <img src={c.cover} alt="" className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent" />
              <span className="absolute top-3 left-3 px-2.5 py-1 rounded-full bg-black/60 backdrop-blur text-[11px] text-white/80 border border-white/10">{c.level}</span>
              {c.progress === 100 && (
                <span className="absolute top-3 right-3 px-2.5 py-1 rounded-full bg-emerald-500/20 text-emerald-300 text-[11px] border border-emerald-400/30 flex items-center gap-1">
                  <CheckIcon size={12} /> Complete
                </span>
              )}
            </div>
            <div className="p-4">
              <div className="text-[11px] text-white/40 uppercase tracking-wide">{c.category}</div>
              <h3 className="font-medium mt-1 leading-snug line-clamp-2">{c.title}</h3>
              <div className="text-xs text-white/40 mt-1">{c.instructor}</div>
              <div className="flex items-center justify-between mt-3 text-xs text-white/40">
                <span>{c.lessons} lessons · {c.duration}</span>
                <span className="text-white/60">★ {c.rating}</span>
              </div>
            </div>
          </button>
        ))}
      </div>
    </div>
  );
}

function CourseDetail({ course, onBack }: { course: Course; onBack: () => void }) {
  return (
    <div className="space-y-5 animate-fade-up">
      <button onClick={onBack} className="text-sm text-white/50 hover:text-white transition-colors flex items-center gap-1.5">
        <ArrowRightIcon size={16} className="rotate-180" /> Back to Knowledge
      </button>
      <div className="card p-0 overflow-hidden">
        <div className="relative h-56">
          <img src={course.cover} alt="" className="w-full h-full object-cover" />
          <div className="absolute inset-0 bg-gradient-to-t from-black via-black/40 to-transparent" />
          <div className="absolute bottom-5 left-5 right-5">
            <div className="text-xs text-white/60 uppercase tracking-wide">{course.category} · {course.level}</div>
            <h1 className="text-2xl font-semibold tracking-tightest mt-1">{course.title}</h1>
            <p className="text-sm text-white/60 mt-1">By {course.instructor}</p>
          </div>
        </div>
        <div className="p-6">
          <div className="flex items-center justify-between text-sm text-white/50 mb-2">
            <span>Course Progress</span><span>{course.progress}%</span>
          </div>
          <div className="h-2 rounded-full bg-white/[0.06] overflow-hidden mb-6">
            <div className="h-full bg-white/40 rounded-full transition-all duration-1000" style={{ width: `${course.progress}%` }} />
          </div>
          <div className="grid sm:grid-cols-3 gap-3 mb-6">
            <div className="glass-panel rounded-xl p-3 text-center"><div className="text-lg font-semibold">{course.lessons}</div><div className="text-xs text-white/40">Lessons</div></div>
            <div className="glass-panel rounded-xl p-3 text-center"><div className="text-lg font-semibold">{course.duration}</div><div className="text-xs text-white/40">Duration</div></div>
            <div className="glass-panel rounded-xl p-3 text-center"><div className="text-lg font-semibold">★ {course.rating}</div><div className="text-xs text-white/40">Rating</div></div>
          </div>
          <h3 className="font-medium mb-3">Curriculum</h3>
          <div className="space-y-2">
            {Array.from({ length: Math.min(6, course.lessons) }).map((_, i) => (
              <div key={i} className="flex items-center gap-3 glass-panel rounded-xl p-3">
                <div className={`w-8 h-8 rounded-full flex items-center justify-center text-xs ${i < Math.floor(course.lessons * course.progress / 100) ? 'bg-white text-black' : 'bg-white/[0.06] text-white/50'}`}>
                  {i < Math.floor(course.lessons * course.progress / 100) ? <CheckIcon size={14} /> : i + 1}
                </div>
                <div className="flex-1 text-sm text-white/80">Lesson {i + 1}: {['Introduction','Core concepts','Practical application','Case study','Advanced patterns','Synthesis'][i]}</div>
                <span className="text-xs text-white/30">{Math.floor(Math.random() * 20 + 10)}m</span>
              </div>
            ))}
          </div>
          <button className="btn-primary w-full mt-6">{course.progress > 0 ? 'Continue Learning' : 'Start Course'}</button>
        </div>
      </div>
    </div>
  );
}
