import type { ModuleId } from '@/types';
import { Avatar } from '@/components/Avatar';
import { Wordmark } from '@/components/Brand';
import { VerifiedBadge } from '@/components/VerifiedBadge';
import {
  CloseIcon, ArrowRightIcon, BellIcon, SaveIcon, KnowledgeIcon, WalletIcon,
  CommunicationIcon, GovernanceIcon, SpaceIcon, SettingsIcon, ShieldIcon,
  HelpIcon, InfoIcon, LogOutIcon, UserIcon,
} from '@/components/icons';
import type { Citizen } from '@/types';

interface MenuPageProps {
  self: Citizen | null;
  isAdmin: boolean;
  unreadCount: number;
  onNavigate: (id: ModuleId) => void;
  onOpenProfile: () => void;
  onShowNotifications: () => void;
  onLogout: () => void;
  onClose: () => void;
}

export function MenuPage({
  self, isAdmin, unreadCount, onNavigate, onOpenProfile,
  onShowNotifications, onLogout, onClose,
}: MenuPageProps) {
  const MODULES: { id: ModuleId; label: string; desc: string; Icon: typeof KnowledgeIcon }[] = [
    { id: 'knowledge', label: 'Knowledge', desc: 'Global learning ecosystem', Icon: KnowledgeIcon },
    { id: 'wallet', label: 'Wallet', desc: 'Digital resources & payments', Icon: WalletIcon },
    { id: 'communication', label: 'Communication', desc: 'Messages & communities', Icon: CommunicationIcon },
    { id: 'governance', label: 'Governance', desc: 'Proposals & voting', Icon: GovernanceIcon },
    { id: 'space', label: 'Space', desc: 'Missions & exploration', Icon: SpaceIcon },
  ];

  const QUICK_ACTIONS: { label: string; desc: string; Icon: typeof BellIcon; badge?: number; onClick: () => void }[] = [
    { label: 'Notifications', desc: unreadCount > 0 ? `${unreadCount} unread` : 'All caught up', Icon: BellIcon, badge: unreadCount, onClick: onShowNotifications },
    { label: 'Saved Posts', desc: 'Your bookmarked content', Icon: SaveIcon, onClick: () => onNavigate('home') },
    { label: 'Settings', desc: 'Preferences & system', Icon: SettingsIcon, onClick: () => onNavigate('settings') },
  ];

  const FOOTER_ITEMS: { label: string; Icon: typeof HelpIcon; onClick: () => void }[] = [
    { label: 'Help & Support', Icon: HelpIcon, onClick: () => onNavigate('help') },
    { label: 'Privacy & Legal', Icon: InfoIcon, onClick: () => onNavigate('legal') },
  ];

  return (
    <div className="fixed inset-0 z-[9000] animate-fade-in overflow-y-auto no-scrollbar">
      <div className="absolute inset-0 bg-unity-bg/95 backdrop-blur-xl" />

      <div className="relative min-h-screen flex flex-col">
        {/* Header */}
        <header className="sticky top-0 z-10 glass-strong border-b border-unity-border">
          <div className="mx-auto max-w-2xl px-5 h-14 flex items-center justify-between">
            <div className="text-xs tracking-[0.3em] text-unity-faint uppercase">Menu</div>
            <button onClick={onClose} className="btn-icon" aria-label="Close menu">
              <CloseIcon size={20} />
            </button>
          </div>
        </header>

        <div className="mx-auto max-w-2xl px-5 py-6 w-full flex-1">
          {/* Profile shortcut */}
          <button
            onClick={onOpenProfile}
            className="w-full card p-5 flex items-center gap-4 hover:bg-unity-surface-strong transition-all duration-200 active:scale-[0.98] mb-5 group"
          >
            <Avatar src={self?.avatar_url} name={self?.name ?? 'Citizen'} size={56} verified={self?.verified} ring />
            <div className="flex-1 min-w-0 text-left">
              <div className="flex items-center gap-2">
                <span className="font-semibold text-base truncate">{self?.name ?? 'Citizen'}</span>
                {self?.verified && <VerifiedBadge size={15} />}
              </div>
              <div className="text-sm text-unity-faint truncate">@{self?.handle ?? 'unknown'} · {self?.country}</div>
            </div>
            <ArrowRightIcon size={18} className="text-unity-faint group-hover:text-unity-muted group-hover:translate-x-0.5 transition-all shrink-0" />
          </button>

          {/* Quick actions */}
          <div className="space-y-2 mb-6">
            {QUICK_ACTIONS.map(({ label, desc, Icon, badge, onClick }) => (
              <button
                key={label}
                onClick={onClick}
                className="w-full card p-4 flex items-center gap-3 hover:bg-unity-surface-strong transition-all duration-200 active:scale-[0.98] group"
              >
                <div className="w-10 h-10 rounded-xl bg-unity-surface flex items-center justify-center text-unity-muted group-hover:text-unity-primary transition-colors shrink-0">
                  <Icon size={18} />
                </div>
                <div className="flex-1 text-left min-w-0">
                  <div className="font-medium text-sm">{label}</div>
                  <div className="text-xs text-unity-faint truncate">{desc}</div>
                </div>
                {badge !== undefined && badge > 0 && (
                  <span className="px-2 py-0.5 rounded-full bg-rose-500/20 text-rose-400 text-[10px] font-semibold shrink-0">
                    {badge > 99 ? '99+' : badge}
                  </span>
                )}
                <ArrowRightIcon size={16} className="text-unity-faint group-hover:text-unity-muted transition-all shrink-0" />
              </button>
            ))}
          </div>

          {/* Modules */}
          <div className="text-xs tracking-[0.2em] text-unity-faint uppercase mb-3 px-1">Modules</div>
          <div className="grid grid-cols-2 gap-3 mb-6">
            {MODULES.map(({ id, label, desc, Icon }) => (
              <button
                key={id}
                onClick={() => onNavigate(id)}
                className="group text-left p-4 rounded-2xl glass hover:bg-unity-surface-strong transition-all duration-200 active:scale-[0.98] border-gradient"
              >
                <div className="flex items-start justify-between mb-3">
                  <div className="w-10 h-10 rounded-xl bg-unity-surface flex items-center justify-center text-unity-muted group-hover:text-unity-primary transition-colors">
                    <Icon size={20} />
                  </div>
                  <ArrowRightIcon size={16} className="text-unity-faint group-hover:text-unity-muted group-hover:translate-x-0.5 transition-all" />
                </div>
                <div className="font-medium text-sm text-unity-primary">{label}</div>
                <div className="text-xs text-unity-faint mt-0.5">{desc}</div>
              </button>
            ))}
          </div>

          {/* Admin (conditional) */}
          {isAdmin && (
            <>
              <div className="text-xs tracking-[0.2em] text-unity-faint uppercase mb-3 px-1">Administration</div>
              <button
                onClick={() => onNavigate('admin')}
                className="w-full card p-4 flex items-center gap-3 hover:bg-unity-surface-strong transition-all duration-200 active:scale-[0.98] group mb-6"
              >
                <div className="w-10 h-10 rounded-xl bg-unity-surface flex items-center justify-center text-unity-primary shrink-0">
                  <ShieldIcon size={18} />
                </div>
                <div className="flex-1 text-left">
                  <div className="font-medium text-sm">Admin Panel</div>
                  <div className="text-xs text-unity-faint">Manage users, content, reports</div>
                </div>
                <ArrowRightIcon size={16} className="text-unity-faint group-hover:text-unity-muted transition-all shrink-0" />
              </button>
            </>
          )}

          {/* Footer items */}
          <div className="space-y-2 mb-6">
            {FOOTER_ITEMS.map(({ label, Icon, onClick }) => (
              <button
                key={label}
                onClick={onClick}
                className="w-full flex items-center gap-3 px-4 py-3 rounded-xl text-unity-muted hover:text-unity-primary hover:bg-unity-surface/50 transition-all text-sm"
              >
                <Icon size={18} className="text-unity-faint" />
                {label}
              </button>
            ))}
          </div>

          {/* Logout */}
          <button
            onClick={onLogout}
            className="w-full flex items-center justify-center gap-2 px-4 py-3 rounded-xl text-rose-400/80 hover:text-rose-400 hover:bg-rose-500/10 transition-all text-sm font-medium"
          >
            <LogOutIcon size={18} />
            Sign out
          </button>

          {/* Branding footer */}
          <div className="mt-8 pt-6 border-t border-unity-border flex items-center justify-between">
            <Wordmark size="sm" />
            <div className="text-[10px] tracking-[0.2em] text-unity-faint uppercase">v3.0 · Platform Edition</div>
          </div>
        </div>
      </div>
    </div>
  );
}
