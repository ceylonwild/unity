import { useRef, useState } from 'react';
import { useSelf } from '@/lib/self';
import { Avatar } from '@/components/Avatar';
import { Wordmark } from '@/components/Brand';
import {
  CitizenIcon,
  VerifiedIcon,
  QrIcon,
  PlusIcon,
  ArrowRightIcon,
  CameraIcon,
  SearchIcon,
  CloseIcon,
  GlobeIcon,
  ArrowLeftIcon,
} from '@/components/icons';
import { fileToAvatarDataUrl } from '@/lib/image';
import { showToast } from '@/lib/toast';
import type { Citizen } from '@/types';

const COUNTRIES: { name: string; code: string }[] = [
  { name: 'Global', code: 'WO' },
  { name: 'United States', code: 'US' },
  { name: 'United Kingdom', code: 'GB' },
  { name: 'Canada', code: 'CA' },
  { name: 'Australia', code: 'AU' },
  { name: 'Germany', code: 'DE' },
  { name: 'France', code: 'FR' },
  { name: 'Japan', code: 'JP' },
  { name: 'China', code: 'CN' },
  { name: 'India', code: 'IN' },
  { name: 'Brazil', code: 'BR' },
  { name: 'Mexico', code: 'MX' },
  { name: 'Spain', code: 'ES' },
  { name: 'Italy', code: 'IT' },
  { name: 'Netherlands', code: 'NL' },
  { name: 'Sweden', code: 'SE' },
  { name: 'Norway', code: 'NO' },
  { name: 'Switzerland', code: 'CH' },
  { name: 'South Korea', code: 'KR' },
  { name: 'Singapore', code: 'SG' },
  { name: 'United Arab Emirates', code: 'AE' },
  { name: 'Saudi Arabia', code: 'SA' },
  { name: 'South Africa', code: 'ZA' },
  { name: 'Nigeria', code: 'NG' },
  { name: 'Egypt', code: 'EG' },
  { name: 'Kenya', code: 'KE' },
  { name: 'Argentina', code: 'AR' },
  { name: 'Chile', code: 'CL' },
  { name: 'Colombia', code: 'CO' },
  { name: 'Russia', code: 'RU' },
  { name: 'Turkey', code: 'TR' },
  { name: 'Indonesia', code: 'ID' },
  { name: 'Thailand', code: 'TH' },
  { name: 'Malaysia', code: 'MY' },
  { name: 'Philippines', code: 'PH' },
  { name: 'Vietnam', code: 'VN' },
  { name: 'Pakistan', code: 'PK' },
  { name: 'Bangladesh', code: 'BD' },
  { name: 'Israel', code: 'IL' },
  { name: 'Greece', code: 'GR' },
  { name: 'Portugal', code: 'PT' },
  { name: 'Poland', code: 'PL' },
  { name: 'Ireland', code: 'IE' },
  { name: 'New Zealand', code: 'NZ' },
  { name: 'Austria', code: 'AT' },
  { name: 'Belgium', code: 'BE' },
  { name: 'Denmark', code: 'DK' },
  { name: 'Finland', code: 'FI' },
  { name: 'Czech Republic', code: 'CZ' },
  { name: 'Hungary', code: 'HU' },
  { name: 'Romania', code: 'RO' },
  { name: 'Ukraine', code: 'UA' },
  { name: 'Morocco', code: 'MA' },
  { name: 'Ghana', code: 'GH' },
  { name: 'Ethiopia', code: 'ET' },
  { name: 'Tanzania', code: 'TZ' },
  { name: 'Peru', code: 'PE' },
  { name: 'Venezuela', code: 'VE' },
  { name: 'Ecuador', code: 'EC' },
];

const LANGUAGES = [
  'English', 'Mandarin', 'Spanish', 'Hindi', 'Arabic', 'Portuguese',
  'Bengali', 'Russian', 'Japanese', 'French', 'German', 'Korean',
  'Turkish', 'Italian', 'Urdu', 'Indonesian', 'Swahili', 'Dutch',
  'Farsi', 'Vietnamese', 'Thai', 'Hebrew', 'Greek', 'Polish',
];

export function CitizenView() {
  const { self } = useSelf();
  const [showQR, setShowQR] = useState(false);
  const [showFull, setShowFull] = useState(false);
  const [editing, setEditing] = useState(false);

  if (!self) {
    return (
      <div className="flex items-center justify-center py-20">
        <div className="w-8 h-8 rounded-full border-2 border-white/10 border-t-white/60 animate-spin" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-2 mb-1">
        <CitizenIcon size={16} className="text-white/50" />
        <span className="text-xs tracking-[0.3em] text-white/40 uppercase">Citizen ID</span>
      </div>

      <div className="animate-fade-up">
        <IdentityCard citizen={self} onShowQR={() => setShowQR(true)} onEdit={() => setEditing(true)} />
      </div>

      <AvatarUploader citizen={self} />

      <div className="grid grid-cols-3 gap-3">
        <button onClick={() => setShowQR(true)} className="card p-4 text-center hover:bg-white/[0.06] transition-all group">
          <QrIcon size={20} className="mx-auto text-white/60 group-hover:text-white transition-colors" />
          <div className="text-xs mt-2 text-white/60">Citizen QR</div>
        </button>
        <button onClick={() => setEditing(true)} className="card p-4 text-center hover:bg-white/[0.06] transition-all group">
          <PlusIcon size={20} className="mx-auto text-white/60 group-hover:text-white transition-colors" />
          <div className="text-xs mt-2 text-white/60">Edit Profile</div>
        </button>
        <button onClick={() => setShowFull(!showFull)} className="card p-4 text-center hover:bg-white/[0.06] transition-all group">
          <ArrowRightIcon size={20} className={`mx-auto text-white/60 group-hover:text-white transition-all ${showFull ? 'rotate-90' : ''}`} />
          <div className="text-xs mt-2 text-white/60">{showFull ? 'Collapse' : 'Full Profile'}</div>
        </button>
      </div>

      {showFull && (
        <div className="grid md:grid-cols-2 gap-4 animate-fade-up">
          <InfoPanel title="Skills" items={self.skills.length ? self.skills : []} />
          <InfoPanel title="Achievements" items={self.achievements.length ? self.achievements : []} />
          <InfoPanel title="Interests" items={self.interests.length ? self.interests : []} />
          <InfoPanel title="Languages" items={self.languages.length ? self.languages : [self.language]} />
          <div className="card p-5">
            <div className="text-xs text-white/40 uppercase tracking-wide mb-3">Education</div>
            <p className="text-sm text-white/80">{self.education || 'Not specified'}</p>
          </div>
          <div className="card p-5">
            <div className="text-xs text-white/40 uppercase tracking-wide mb-3">Portfolio Links</div>
            {self.portfolio_links.length > 0 ? (
              <div className="space-y-2">
                {self.portfolio_links.map((link, i) => (
                  <a key={i} href={link} target="_blank" rel="noreferrer" className="block text-sm text-white/80 hover:text-white truncate underline-offset-4 hover:underline">
                    {link}
                  </a>
                ))}
              </div>
            ) : (
              <p className="text-sm text-white/40">No links added.</p>
            )}
          </div>
        </div>
      )}

      {showQR && <QRModal citizen={self} onClose={() => setShowQR(false)} />}
      {editing && <EditProfileModal citizen={self} onClose={() => setEditing(false)} />}
    </div>
  );
}

function IdentityCard({ citizen, onShowQR, onEdit }: { citizen: Citizen; onShowQR: () => void; onEdit: () => void }) {
  return (
    <div className="card p-0 overflow-hidden relative group">
      <div className="absolute inset-0 opacity-30 pointer-events-none" style={{ background: 'linear-gradient(135deg, rgba(255,255,255,0.08), transparent 40%, rgba(255,255,255,0.04))' }} />
      <div className="relative p-6">
        <div className="flex items-center justify-between mb-6">
          <Wordmark size="sm" />
          <div className="text-right">
            <div className="text-[9px] tracking-[0.3em] text-white/40 uppercase">Digital Citizen</div>
            <div className="text-[9px] text-white/30 mt-0.5 font-mono">ID · {citizen.id.slice(0, 8).toUpperCase()}</div>
          </div>
        </div>

        <div className="flex gap-5">
          <Avatar src={citizen.avatar_url} name={citizen.name} size={80} ring verified={citizen.verified} />
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2">
              <h2 className="text-xl font-semibold tracking-tightest truncate">{citizen.name}</h2>
              {citizen.verified && <VerifiedIcon size={16} className="text-white shrink-0" />}
            </div>
            <div className="text-sm text-white/40 mt-0.5">@{citizen.handle}</div>
            <div className="flex flex-wrap gap-2 mt-3">
              <span className="px-2.5 py-1 rounded-full bg-white/[0.06] border border-[#2a2a2a]/80 text-[11px] text-white/70">{citizen.country}</span>
              <span className="px-2.5 py-1 rounded-full bg-white/[0.06] border border-[#2a2a2a]/80 text-[11px] text-white/70">{citizen.language}</span>
            </div>
            {citizen.bio && <p className="text-sm text-white/60 mt-3 line-clamp-2">{citizen.bio}</p>}
          </div>
        </div>

        <div className="flex items-center justify-between mt-6 pt-5 border-t border-[#2a2a2a]/80">
          <div>
            <div className="text-[9px] tracking-[0.25em] text-white/30 uppercase">Issued</div>
            <div className="text-xs text-white/60 mt-0.5 font-mono">{new Date(citizen.created_at).toLocaleDateString('en', { year: 'numeric', month: 'short', day: 'numeric' })}</div>
          </div>
          <div className="flex gap-2">
            <button onClick={onEdit} className="btn-ghost py-2 text-xs">Edit</button>
            <button onClick={onShowQR} className="btn-ghost py-2 text-xs gap-2">
              <QrIcon size={14} />
              Show QR
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

function InfoPanel({ title, items }: { title: string; items: string[] }) {
  return (
    <div className="card p-5">
      <div className="text-xs text-white/40 uppercase tracking-wide mb-3">{title}</div>
      {items.length > 0 ? (
        <div className="flex flex-wrap gap-2">
          {items.map((i, idx) => (
            <span key={idx} className="px-3 py-1.5 rounded-full bg-white/[0.05] border border-[#2a2a2a]/80 text-sm text-white/75">
              {i}
            </span>
          ))}
        </div>
      ) : (
        <p className="text-sm text-white/40">Not specified</p>
      )}
    </div>
  );
}

function AvatarUploader({ citizen }: { citizen: Citizen }) {
  const { setAvatar } = useSelf();
  const fileRef = useRef<HTMLInputElement>(null);
  const [preview, setPreview] = useState<string | null>(citizen.avatar_url);
  const [saving, setSaving] = useState(false);

  const onPick = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (!file.type.startsWith('image/')) {
      showToast('Please choose an image file', 'error');
      return;
    }
    try {
      const dataUrl = await fileToAvatarDataUrl(file);
      setPreview(dataUrl);
    } catch {
      showToast('Could not process that image', 'error');
    }
  };

  const onSave = async () => {
    if (!preview || saving) return;
    setSaving(true);
    try {
      await setAvatar(preview);
      showToast('Profile photo updated', 'success');
    } catch {
      showToast('Could not save photo', 'error');
    } finally {
      setSaving(false);
    }
  };

  const hasChange = preview !== citizen.avatar_url;

  return (
    <div className="card p-6 animate-fade-up">
      <div className="flex items-center gap-2 mb-4">
        <CameraIcon size={16} className="text-white/50" />
        <h2 className="font-medium text-sm">Profile Photo</h2>
      </div>
      <div className="flex items-center gap-5">
        <div className="relative shrink-0">
          <Avatar src={preview} name={citizen.name} size={80} ring />
          <button
            onClick={() => fileRef.current?.click()}
            className="absolute -bottom-1 -right-1 w-8 h-8 rounded-full glass-strong flex items-center justify-center hover:bg-white/[0.12] transition-all active:scale-95"
            aria-label="Change photo"
          >
            <CameraIcon size={15} className="text-white" />
          </button>
        </div>
        <div className="flex-1">
          <p className="text-sm text-white/50">Pick a photo from your device. We'll crop it to a square and compress it automatically.</p>
          <div className="flex flex-wrap gap-2 mt-3">
            <button onClick={() => fileRef.current?.click()} className="btn-ghost py-2 text-xs">
              <CameraIcon size={14} />
              {preview ? 'Choose new' : 'Upload'}
            </button>
            {hasChange && (
              <button onClick={onSave} disabled={saving} className="btn-primary py-2 text-xs disabled:opacity-50">
                {saving ? 'Saving…' : 'Save photo'}
              </button>
            )}
            {hasChange && (
              <button onClick={() => setPreview(citizen.avatar_url)} className="btn-ghost py-2 text-xs">
                Cancel
              </button>
            )}
          </div>
        </div>
      </div>
      <input ref={fileRef} type="file" accept="image/*" onChange={onPick} className="hidden" />
    </div>
  );
}

function QRModal({ citizen, onClose }: { citizen: Citizen; onClose: () => void }) {
  const payload = `UNITY:CITIZEN:${citizen.handle}:${citizen.id.slice(0, 12)}`;
  return (
    <div className="fixed inset-0 z-[9000] flex items-center justify-center p-5 animate-fade-in" onClick={onClose}>
      <div className="absolute inset-0 bg-black/85 backdrop-blur-md" />
      <div className="relative glass-strong rounded-3xl p-8 max-w-sm w-full text-center animate-scale-in" onClick={(e) => e.stopPropagation()}>
        <div className="text-xs tracking-[0.3em] text-white/40 uppercase mb-1">Citizen QR</div>
        <h3 className="text-lg font-semibold tracking-tightest mb-5">{citizen.name}</h3>
        <div className="bg-white p-5 rounded-2xl mx-auto w-fit">
          <QRMatrix data={payload} size={180} />
        </div>
        <p className="text-xs text-white/40 mt-5 font-mono break-all">{payload}</p>
        <p className="text-xs text-white/30 mt-2">Scan to verify this citizen's digital identity</p>
        <button onClick={onClose} className="btn-ghost mt-6 w-full">Close</button>
      </div>
    </div>
  );
}

function EditProfileModal({ citizen, onClose }: { citizen: Citizen; onClose: () => void }) {
  const { updateSelf } = useSelf();
  const [name, setName] = useState(citizen.name);
  const [bio, setBio] = useState(citizen.bio);
  const [country, setCountry] = useState(citizen.country);
  const [countryCode, setCountryCode] = useState(citizen.country_code);
  const [language, setLanguage] = useState(citizen.language);
  const [languages, setLanguages] = useState<string[]>(citizen.languages);
  const [education, setEducation] = useState(citizen.education);
  const [skills, setSkills] = useState<string[]>(citizen.skills);
  const [achievements, setAchievements] = useState<string[]>(citizen.achievements);
  const [interests, setInterests] = useState<string[]>(citizen.interests);
  const [portfolioLinks, setPortfolioLinks] = useState<string[]>(citizen.portfolio_links);
  const [saving, setSaving] = useState(false);
  const [showCountryPicker, setShowCountryPicker] = useState(false);
  const [countryQuery, setCountryQuery] = useState('');

  const filtered = COUNTRIES.filter((c) =>
    c.name.toLowerCase().includes(countryQuery.toLowerCase())
  );

  const toggleArrayItem = (arr: string[], setArr: (v: string[]) => void, value: string) => {
    setArr(arr.includes(value) ? arr.filter((x) => x !== value) : [...arr, value]);
  };

  const save = async () => {
    if (saving) return;
    setSaving(true);
    try {
      await updateSelf({
        name: name.trim() || citizen.name,
        bio: bio.trim(),
        country,
        country_code: countryCode,
        language,
        languages,
        education: education.trim(),
        skills,
        achievements,
        interests,
        portfolio_links: portfolioLinks.filter((l) => l.trim()),
      });
      showToast('Citizen profile saved', 'success');
      onClose();
    } catch {
      showToast('Could not save profile', 'error');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="fixed inset-0 z-[9000] flex items-center justify-center p-4 animate-fade-in" onClick={onClose}>
      <div className="absolute inset-0 bg-black/85 backdrop-blur-md" />
      <div
        className="relative glass-strong rounded-3xl w-full max-w-lg max-h-[88vh] overflow-y-auto no-scrollbar animate-scale-in"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="sticky top-0 z-10 glass-strong border-b border-[#2a2a2a] p-4 flex items-center justify-between">
          <button onClick={onClose} className="btn-icon w-9 h-9"><ArrowLeftIcon size={18} /></button>
          <h2 className="font-medium text-sm">Edit Citizen ID</h2>
          <button onClick={save} disabled={saving} className="btn-primary py-2 text-xs disabled:opacity-50">
            {saving ? 'Saving…' : 'Save'}
          </button>
        </div>

        <div className="p-5 space-y-5">
          <TextField label="Full Name" value={name} onChange={setName} placeholder="Your full name" />
          <TextField label="Biography" value={bio} onChange={setBio} placeholder="A short bio about you" multiline />

          {/* Country dropdown with search */}
          <div>
            <label className="text-xs text-white/40 mb-1.5 block">Native Country</label>
            <button
              onClick={() => setShowCountryPicker(true)}
              className="input-field py-3 flex items-center justify-between text-left"
            >
              <span className="flex items-center gap-2"><GlobeIcon size={15} className="text-white/40" /> {country}</span>
              <span className="text-xs text-white/30">{countryCode}</span>
            </button>
          </div>

          {/* Primary language */}
          <div>
            <label className="text-xs text-white/40 mb-1.5 block">Primary Interface Language</label>
            <select
              value={language}
              onChange={(e) => setLanguage(e.target.value)}
              className="input-field py-3 appearance-none cursor-pointer"
            >
              {LANGUAGES.map((l) => <option key={l} value={l} className="bg-unity-surface-strong text-unity-primary">{l}</option>)}
            </select>
          </div>

          {/* Languages spoken */}
          <TagEditor
            label="Languages Spoken"
            options={LANGUAGES}
            selected={languages}
            onToggle={(v) => toggleArrayItem(languages, setLanguages, v)}
            onAdd={(v) => { if (!languages.includes(v)) setLanguages([...languages, v]); }}
          />

          <TextField label="Education" value={education} onChange={setEducation} placeholder="e.g. MSc Aerospace, MIT" />

          <ListEditor
            label="Skill Matrix"
            items={skills}
            onChange={setSkills}
            placeholder="e.g. Systems Engineering"
          />
          <ListEditor
            label="Achievements"
            items={achievements}
            onChange={setAchievements}
            placeholder="e.g. Led Mars habitat study"
          />
          <ListEditor
            label="Interests"
            items={interests}
            onChange={setInterests}
            placeholder="e.g. Climate restoration"
          />
          <ListEditor
            label="Portfolio Links"
            items={portfolioLinks}
            onChange={setPortfolioLinks}
            placeholder="https://…"
          />
        </div>
      </div>

      {showCountryPicker && (
        <CountryPicker
          query={countryQuery}
          onQuery={setCountryQuery}
          filtered={filtered}
          onPick={(c) => {
            setCountry(c.name);
            setCountryCode(c.code);
            setShowCountryPicker(false);
            setCountryQuery('');
          }}
          onClose={() => setShowCountryPicker(false)}
        />
      )}
    </div>
  );
}

function CountryPicker({
  query,
  onQuery,
  filtered,
  onPick,
  onClose,
}: {
  query: string;
  onQuery: (v: string) => void;
  filtered: { name: string; code: string }[];
  onPick: (c: { name: string; code: string }) => void;
  onClose: () => void;
}) {
  return (
    <div className="fixed inset-0 z-[9100] flex items-end sm:items-center justify-center p-4 animate-fade-in" onClick={onClose}>
      <div className="absolute inset-0 bg-black/90 backdrop-blur-lg" />
      <div
        className="relative glass-strong rounded-3xl w-full max-w-md max-h-[70vh] flex flex-col animate-scale-in"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="p-4 border-b border-[#2a2a2a]">
          <div className="flex items-center gap-2">
            <SearchIcon size={18} className="text-white/40 shrink-0" />
            <input
              autoFocus
              value={query}
              onChange={(e) => onQuery(e.target.value)}
              placeholder="Search countries…"
              className="flex-1 bg-transparent outline-none text-sm placeholder-white/30"
            />
            <button onClick={onClose} className="btn-icon w-8 h-8"><CloseIcon size={16} /></button>
          </div>
        </div>
        <div className="overflow-y-auto no-scrollbar flex-1 p-2">
          {filtered.length === 0 ? (
            <p className="text-sm text-white/30 text-center py-8">No matches</p>
          ) : (
            filtered.map((c) => (
              <button
                key={c.code}
                onClick={() => onPick(c)}
                className="w-full flex items-center justify-between p-3 rounded-xl hover:bg-white/[0.06] transition-all text-left"
              >
                <span className="text-sm text-white/80">{c.name}</span>
                <span className="text-xs text-white/30 font-mono">{c.code}</span>
              </button>
            ))
          )}
        </div>
      </div>
    </div>
  );
}

function TagEditor({
  label,
  options,
  selected,
  onToggle,
  onAdd,
}: {
  label: string;
  options: string[];
  selected: string[];
  onToggle: (v: string) => void;
  onAdd: (v: string) => void;
}) {
  const [custom, setCustom] = useState('');
  return (
    <div>
      <label className="text-xs text-white/40 mb-2 block">{label}</label>
      <div className="flex flex-wrap gap-2 mb-2">
        {options.map((o) => {
          const active = selected.includes(o);
          return (
            <button
              key={o}
              onClick={() => onToggle(o)}
              className={`px-3 py-1.5 rounded-full text-xs transition-all ${
                active
                  ? 'bg-white text-black font-medium'
                  : 'bg-white/[0.05] border border-[#2a2a2a]/80 text-white/60 hover:bg-white/[0.08]'
              }`}
            >
              {o}
            </button>
          );
        })}
      </div>
      {selected.filter((s) => !options.includes(s)).map((s) => (
        <span key={s} className="inline-flex items-center gap-1 px-3 py-1.5 rounded-full bg-white/[0.05] border border-[#2a2a2a]/80 text-xs text-white/60 mr-2 mb-2">
          {s}
          <button onClick={() => onToggle(s)} className="text-white/40 hover:text-white"><CloseIcon size={12} /></button>
        </span>
      ))}
      <div className="flex gap-2">
        <input
          value={custom}
          onChange={(e) => setCustom(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === 'Enter' && custom.trim()) { onAdd(custom.trim()); setCustom(''); }
          }}
          placeholder="Add custom…"
          className="input-field py-2 text-xs flex-1"
        />
        <button
          onClick={() => { if (custom.trim()) { onAdd(custom.trim()); setCustom(''); } }}
          className="btn-icon w-9 h-9"
        >
          <PlusIcon size={16} />
        </button>
      </div>
    </div>
  );
}

function ListEditor({
  label,
  items,
  onChange,
  placeholder,
}: {
  label: string;
  items: string[];
  onChange: (v: string[]) => void;
  placeholder: string;
}) {
  const [draft, setDraft] = useState('');
  const add = () => {
    if (!draft.trim()) return;
    onChange([...items, draft.trim()]);
    setDraft('');
  };
  return (
    <div>
      <label className="text-xs text-white/40 mb-2 block">{label}</label>
      <div className="space-y-2 mb-2">
        {items.map((item, i) => (
          <div key={i} className="flex items-center gap-2 glass-panel rounded-xl px-3 py-2">
            <span className="flex-1 text-sm text-white/80 truncate">{item}</span>
            <button onClick={() => onChange(items.filter((_, idx) => idx !== i))} className="text-white/30 hover:text-white">
              <CloseIcon size={14} />
            </button>
          </div>
        ))}
      </div>
      <div className="flex gap-2">
        <input
          value={draft}
          onChange={(e) => setDraft(e.target.value)}
          onKeyDown={(e) => e.key === 'Enter' && add()}
          placeholder={placeholder}
          className="input-field py-2 text-xs flex-1"
        />
        <button onClick={add} className="btn-icon w-9 h-9"><PlusIcon size={16} /></button>
      </div>
    </div>
  );
}

function TextField({
  label,
  value,
  onChange,
  placeholder,
  multiline,
}: {
  label: string;
  value: string;
  onChange: (v: string) => void;
  placeholder?: string;
  multiline?: boolean;
}) {
  return (
    <div>
      <label className="text-xs text-white/40 mb-1.5 block">{label}</label>
      {multiline ? (
        <textarea
          value={value}
          onChange={(e) => onChange(e.target.value)}
          placeholder={placeholder}
          rows={3}
          className="input-field py-2.5 resize-none"
        />
      ) : (
        <input
          value={value}
          onChange={(e) => onChange(e.target.value)}
          placeholder={placeholder}
          className="input-field py-2.5"
        />
      )}
    </div>
  );
}

function QRMatrix({ data, size }: { data: string; size: number }) {
  const cells = 21;
  const cell = size / cells;
  let hash = 0;
  for (let i = 0; i < data.length; i++) hash = (hash * 31 + data.charCodeAt(i)) >>> 0;
  const grid: boolean[] = [];
  let s = hash;
  for (let i = 0; i < cells * cells; i++) {
    s = (s * 1103515245 + 12345) & 0x7fffffff;
    grid.push((s >> 16) % 2 === 0);
  }
  const isFinder = (r: number, c: number) => {
    const inBox = (br: number, bc: number) => r >= br && r < br + 7 && c >= bc && c < bc + 7;
    return inBox(0, 0) || inBox(0, cells - 7) || inBox(cells - 7, 0);
  };
  const finderOn = (r: number, c: number) => {
    const local = (br: number, bc: number) => {
      const lr = r - br, lc = c - bc;
      if (lr === 0 || lr === 6 || lc === 0 || lc === 6) return true;
      if (lr >= 2 && lr <= 4 && lc >= 2 && lc <= 4) return true;
      return false;
    };
    if (r < 7 && c < 7) return local(0, 0);
    if (r < 7 && c >= cells - 7) return local(0, cells - 7);
    if (r >= cells - 7 && c < 7) return local(cells - 7, 0);
    return false;
  };
  return (
    <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`} className="block">
      <rect width={size} height={size} fill="white" />
      {Array.from({ length: cells * cells }).map((_, i) => {
        const r = Math.floor(i / cells);
        const c = i % cells;
        let on: boolean;
        if (isFinder(r, c)) on = finderOn(r, c);
        else on = grid[i];
        if (!on) return null;
        return <rect key={i} x={c * cell} y={r * cell} width={cell} height={cell} fill="#000" />;
      })}
    </svg>
  );
}
