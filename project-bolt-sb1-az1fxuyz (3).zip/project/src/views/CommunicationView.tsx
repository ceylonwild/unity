import { useCallback, useEffect, useState } from 'react';
import { CommunicationIcon, SearchIcon, SendIcon, PlusIcon } from '@/components/icons';
import { Avatar } from '@/components/Avatar';
import { supabase } from '@/lib/supabase';
import { useSelf } from '@/lib/self';
import { showToast } from '@/lib/toast';
import type { Citizen } from '@/types';

interface DmMessage { id: string; content: string; isMe: boolean; created_at: string; }

interface Community {
  id: string;
  name: string;
  description: string;
  member_count: number;
  joined: boolean;
}

export function CommunicationView() {
  const { self } = useSelf();
  const [tab, setTab] = useState<'messages' | 'communities'>('messages');
  const [citizens, setCitizens] = useState<Citizen[]>([]);
  const [searchQ, setSearchQ] = useState('');
  const [openChat, setOpenChat] = useState<string | null>(null);
  const [draft, setDraft] = useState('');
  const [messages, setMessages] = useState<DmMessage[]>([]);
  const [loadingMsgs, setLoadingMsgs] = useState(false);
  const [communities, setCommunities] = useState<Community[]>([]);
  const [loadingCommunities, setLoadingCommunities] = useState(true);

  const loadCitizens = useCallback(async () => {
    const { data, error } = await supabase
      .from('citizens')
      .select('id, name, handle, avatar_url, country, verified, user_id')
      .neq('id', self?.id ?? '')
      .order('created_at', { ascending: false })
      .limit(30);
    if (error) { showToast('Could not load citizens', 'error'); return; }
    setCitizens((data ?? []) as unknown as Citizen[]);
  }, [self?.id]);

  useEffect(() => { if (self) void loadCitizens(); }, [self, loadCitizens]);

  const loadMessages = useCallback(async (otherCitizenId: string) => {
    if (!self?.user_id) return;
    const other = citizens.find((c) => c.id === otherCitizenId);
    if (!other?.user_id) return;
    setLoadingMsgs(true);
    try {
      const { data, error } = await supabase
        .from('messages')
        .select('id, sender_id, content, created_at')
        .or(`and(sender_id.eq.${self.user_id},recipient_id.eq.${other.user_id}),and(sender_id.eq.${other.user_id},recipient_id.eq.${self.user_id})`)
        .order('created_at', { ascending: true })
        .limit(100);
      if (error) throw error;
      setMessages((data ?? []).map((m: { id: string; sender_id: string; content: string; created_at: string }) => ({
        id: m.id,
        content: m.content,
        isMe: m.sender_id === self.user_id,
        created_at: m.created_at,
      })));
    } catch {
      setMessages([]);
    } finally {
      setLoadingMsgs(false);
    }
  }, [self?.user_id, citizens]);

  const sendMessage = async () => {
    if (!draft.trim() || !openChat || !self?.user_id) return;
    const other = citizens.find((c) => c.id === openChat);
    if (!other?.user_id) return;
    const content = draft.trim();
    setDraft('');
    try {
      const { data, error } = await supabase
        .from('messages')
        .insert({ sender_id: self.user_id, recipient_id: other.user_id, content })
        .select('id, created_at')
        .single();
      if (error) throw error;
      setMessages((prev) => [...prev, { id: data.id, content, isMe: true, created_at: data.created_at }]);
    } catch {
      showToast('Could not send message', 'error');
      setDraft(content);
    }
  };

  const loadCommunities = useCallback(async () => {
    if (!self?.user_id) return;
    setLoadingCommunities(true);
    try {
      const { data: comms, error: commsErr } = await supabase
        .from('communities')
        .select('id, name, description')
        .order('name');
      if (commsErr) throw commsErr;
      const { data: memberships, error: memErr } = await supabase
        .from('community_members')
        .select('community_id')
        .eq('user_id', self.user_id);
      if (memErr) throw memErr;
      const joinedSet = new Set((memberships ?? []).map((m: { community_id: string }) => m.community_id));
      const result: Community[] = await Promise.all((comms ?? []).map(async (c: { id: string; name: string; description: string }) => {
        const { count } = await supabase
          .from('community_members')
          .select('*', { count: 'exact', head: true })
          .eq('community_id', c.id);
        return {
          id: c.id,
          name: c.name,
          description: c.description,
          member_count: count ?? 0,
          joined: joinedSet.has(c.id),
        };
      }));
      setCommunities(result);
    } catch {
      setCommunities([]);
    } finally {
      setLoadingCommunities(false);
    }
  }, [self?.user_id]);

  useEffect(() => { if (tab === 'communities' && self) void loadCommunities(); }, [tab, self, loadCommunities]);

  // Realtime: live-update messages when new ones arrive
  useEffect(() => {
    if (!self?.user_id || !openChat) return;
    const channel = supabase
      .channel(`messages-${openChat}`)
      .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'messages' }, () => {
        void loadMessages(openChat);
      })
      .subscribe();
    return () => { supabase.removeChannel(channel); };
  }, [self?.user_id, openChat, loadMessages]);

  const toggleJoin = async (communityId: string, currentlyJoined: boolean) => {
    if (!self?.user_id) return;
    try {
      if (currentlyJoined) {
        const { error } = await supabase.from('community_members').delete().eq('community_id', communityId).eq('user_id', self.user_id);
        if (error) throw error;
      } else {
        const { error } = await supabase.from('community_members').insert({ community_id: communityId, user_id: self.user_id });
        if (error) throw error;
      }
      setCommunities((prev) => prev.map((c) => c.id === communityId
        ? { ...c, joined: !currentlyJoined, member_count: c.member_count + (currentlyJoined ? -1 : 1) }
        : c));
    } catch {
      showToast('Could not update membership', 'error');
    }
  };

  const active = citizens.find((c) => c.id === openChat);
  const filtered = citizens.filter((c) =>
    c.name.toLowerCase().includes(searchQ.toLowerCase()) ||
    c.handle.toLowerCase().includes(searchQ.toLowerCase())
  );

  return (
    <div className="space-y-6">
      <div className="card p-6 animate-fade-up">
        <div className="flex items-center gap-2 mb-2">
          <CommunicationIcon size={18} className="text-unity-muted" />
          <span className="text-xs tracking-[0.3em] text-unity-faint uppercase">Communication</span>
        </div>
        <h1 className="text-3xl font-semibold tracking-tightest">Global Connection Layer</h1>
        <p className="text-unity-muted mt-2">Messages, communities, and discussions across civilization.</p>
      </div>

      <div className="flex gap-2">
        {(['messages', 'communities'] as const).map((t) => (
          <button key={t} onClick={() => setTab(t)} className={`px-4 py-2 rounded-full text-sm border transition-all capitalize ${tab === t ? 'bg-unity-btn-primary-bg text-unity-btn-primary-text border-transparent' : 'bg-unity-surface text-unity-muted border-unity-border hover:bg-unity-surface-strong'}`}>{t}</button>
        ))}
      </div>

      {tab === 'messages' ? (
        <div className="grid md:grid-cols-[280px_1fr] gap-4">
          <div className="card p-3">
            <div className="relative mb-3">
              <SearchIcon size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-unity-faint" />
              <input value={searchQ} onChange={(e) => setSearchQ(e.target.value)} placeholder="Search citizens…" className="w-full input-field rounded-full pl-9 py-2 text-sm" />
            </div>
            {filtered.length === 0 ? (
              <p className="text-xs text-unity-faint text-center py-6">No citizens found.</p>
            ) : filtered.map((c) => (
              <button key={c.id} onClick={() => { setOpenChat(c.id); void loadMessages(c.id); }} className={`w-full flex items-center gap-3 p-2.5 rounded-xl transition-all text-left ${openChat === c.id ? 'bg-unity-surface-strong' : 'hover:bg-unity-surface'}`}>
                <Avatar src={c.avatar_url} name={c.name} size={40} verified={c.verified} />
                <div className="flex-1 min-w-0">
                  <span className="text-sm font-medium truncate block">{c.name}</span>
                  <span className="text-xs text-unity-faint truncate block">@{c.handle}</span>
                </div>
              </button>
            ))}
          </div>

          <div className="card p-0 flex flex-col overflow-hidden" style={{ height: 'min(55vh, 480px)' }}>
            {active ? (
              <>
                <div className="flex items-center gap-3 p-4 border-b border-unity-border">
                  <Avatar src={active.avatar_url} name={active.name} size={36} verified={active.verified} />
                  <div>
                    <div className="font-medium text-sm">{active.name}</div>
                    <div className="text-xs text-unity-faint">@{active.handle} · {active.country}</div>
                  </div>
                </div>
                <div className="flex-1 overflow-y-auto p-4 space-y-3">
                  {loadingMsgs ? (
                    <div className="space-y-2">{[0, 1].map((i) => <div key={i} className="h-10 rounded-xl animate-shimmer" />)}</div>
                  ) : messages.length === 0 ? (
                    <div className="flex items-center justify-center h-full">
                      <p className="text-xs text-unity-faint text-center">No messages yet. Say hello.</p>
                    </div>
                  ) : messages.map((m) => (
                    <div key={m.id} className={`flex ${m.isMe ? 'justify-end' : ''}`}>
                      <div className={`rounded-2xl px-4 py-2.5 max-w-[80%] text-sm ${m.isMe ? 'bg-unity-surface-strong border border-unity-border rounded-tr-sm' : 'glass-panel rounded-tl-sm'}`}>{m.content}</div>
                    </div>
                  ))}
                </div>
                <div className="border-t border-unity-border p-3 flex items-center gap-2">
                  <input value={draft} onChange={(e) => setDraft(e.target.value)} onKeyDown={(e) => e.key === 'Enter' && sendMessage()} placeholder="Message…" className="flex-1 input-field rounded-full" />
                  <button onClick={sendMessage} disabled={!draft.trim()} className="w-9 h-9 rounded-full bg-unity-btn-primary-bg text-unity-btn-primary-text flex items-center justify-center disabled:opacity-30"><SendIcon size={15} /></button>
                </div>
              </>
            ) : (
              <div className="flex-1 flex flex-col items-center justify-center text-center px-6">
                <CommunicationIcon size={36} className="text-unity-faint mb-3" />
                <p className="text-unity-muted text-sm">Select a citizen to start messaging.</p>
              </div>
            )}
          </div>
        </div>
      ) : (
        <div className="grid sm:grid-cols-2 gap-4">
          {loadingCommunities ? (
            [0, 1, 2, 3].map((i) => <div key={i} className="card p-5 h-40 animate-shimmer" />)
          ) : communities.length === 0 ? (
            <div className="col-span-full card p-12 text-center">
              <CommunicationIcon size={32} className="text-unity-faint mx-auto mb-3" />
              <p className="text-unity-muted text-sm">No communities available yet.</p>
            </div>
          ) : communities.map((c, i) => (
            <div key={c.id} className="card p-5 animate-fade-up" style={{ animationDelay: `${i * 60}ms` }}>
              <div className="flex items-start justify-between mb-3">
                <div className="w-12 h-12 rounded-2xl bg-unity-surface flex items-center justify-center">
                  <CommunicationIcon size={22} className="text-unity-muted" />
                </div>
                <button onClick={() => void toggleJoin(c.id, c.joined)} className={`btn-ghost py-1.5 px-3 text-xs ${c.joined ? 'opacity-60' : ''}`}>
                  {c.joined ? 'Joined' : <><PlusIcon size={13} /> Join</>}
                </button>
              </div>
              <h3 className="font-medium">{c.name}</h3>
              <p className="text-sm text-unity-muted mt-1">{c.description}</p>
              <div className="text-xs text-unity-faint mt-3">{c.member_count.toLocaleString()} members</div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
