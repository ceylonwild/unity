import { useState } from 'react';
import { CloseIcon, ShieldIcon, FileIcon, UsersIcon, ImageIcon } from '@/components/icons';

interface LegalViewProps {
  onBack: () => void;
}

type LegalSection = 'privacy' | 'terms' | 'guidelines' | 'content';

const SECTIONS: { id: LegalSection; label: string; Icon: typeof ShieldIcon }[] = [
  { id: 'privacy', label: 'Privacy Policy', Icon: ShieldIcon },
  { id: 'terms', label: 'Terms of Service', Icon: FileIcon },
  { id: 'guidelines', label: 'Community Guidelines', Icon: UsersIcon },
  { id: 'content', label: 'Content Policy', Icon: ImageIcon },
];

export function LegalView({ onBack }: LegalViewProps) {
  const [section, setSection] = useState<LegalSection>('privacy');

  return (
    <div className="fixed inset-0 z-[9000] animate-fade-in overflow-y-auto no-scrollbar">
      <div className="absolute inset-0 bg-unity-bg/95 backdrop-blur-xl" />

      <div className="relative min-h-screen flex flex-col">
        <header className="sticky top-0 z-10 glass-strong border-b border-unity-border">
          <div className="mx-auto max-w-2xl px-5 h-14 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <button onClick={onBack} className="btn-icon" aria-label="Back">
                <CloseIcon size={20} />
              </button>
              <div className="text-xs tracking-[0.3em] text-unity-faint uppercase">Legal</div>
            </div>
          </div>
        </header>

        <div className="mx-auto max-w-2xl px-5 py-6 w-full flex-1">
          {/* Section tabs */}
          <div className="flex gap-2 mb-6 overflow-x-auto no-scrollbar">
            {SECTIONS.map(({ id, label, Icon }) => (
              <button
                key={id}
                onClick={() => setSection(id)}
                className={`flex items-center gap-2 px-4 py-2 rounded-full text-sm font-medium transition-all duration-200 shrink-0 ${
                  section === id ? 'btn-primary' : 'btn-ghost'
                }`}
              >
                <Icon size={16} />
                {label}
              </button>
            ))}
          </div>

          {section === 'privacy' && <PrivacyPolicy />}
          {section === 'terms' && <TermsOfService />}
          {section === 'guidelines' && <CommunityGuidelines />}
          {section === 'content' && <ContentPolicy />}
        </div>
      </div>
    </div>
  );
}

function Section({ title, lastUpdated, children }: { title: string; lastUpdated: string; children: React.ReactNode }) {
  return (
    <div className="card p-6">
      <h1 className="text-xl font-semibold text-unity-primary mb-1">{title}</h1>
      <p className="text-xs text-unity-faint mb-6">Last updated: {lastUpdated}</p>
      <div className="space-y-5 text-sm text-unity-muted leading-relaxed">
        {children}
      </div>
    </div>
  );
}

function H2({ children }: { children: React.ReactNode }) {
  return <h2 className="font-semibold text-unity-primary text-base pt-2">{children}</h2>;
}

function P({ children }: { children: React.ReactNode }) {
  return <p>{children}</p>;
}

function UL({ children }: { children: React.ReactNode }) {
  return <ul className="space-y-2 pl-4 list-disc marker:text-unity-faint">{children}</ul>;
}

function PrivacyPolicy() {
  return (
    <Section title="Privacy Policy" lastUpdated="July 28, 2026">
      <P>
        UNITY is committed to protecting your privacy. This policy explains what information we collect, how we use it, and the choices you have.
      </P>
      <H2>Information We Collect</H2>
      <UL>
        <li>Account information: your name, email address, and chosen handle.</li>
        <li>Profile information: bio, country, language, skills, education, and interests you choose to share.</li>
        <li>Content you create: posts, comments, votes, and uploaded media.</li>
        <li>Usage data: interactions with the platform, preferences, and device information.</li>
      </UL>
      <H2>How We Use Your Information</H2>
      <UL>
        <li>To provide and maintain the UNITY platform and its features.</li>
        <li>To display your profile and content to other citizens according to your privacy settings.</li>
        <li>To send notifications you have explicitly enabled.</li>
        <li>To improve platform performance, safety, and user experience.</li>
        <li>To enforce community guidelines and content policies.</li>
      </UL>
      <H2>Your Privacy Controls</H2>
      <P>
        You can control who sees your profile, online status, and whether others can tag you — all in Settings → Privacy. You can disable any or all notification types in Settings → Notifications.
      </P>
      <H2>Data Storage</H2>
      <P>
        Your data is stored securely using Supabase infrastructure with row-level security policies that ensure each citizen can only access their own private data. Public content (posts, profiles) is visible to other authenticated citizens based on your privacy settings.
      </P>
      <H2>Data Retention</H2>
      <P>
        Your content remains on the platform as long as your account is active. You can delete individual posts at any time. Account deletion requests can be sent to support@unity.app.
      </P>
      <H2>Third-Party Services</H2>
      <P>
        UNITY uses Supabase for database, authentication, and file storage. We do not sell or share your personal information with advertisers or third parties.
      </P>
      <H2>Contact</H2>
      <P>
        Questions about privacy? Email privacy@unity.app.
      </P>
    </Section>
  );
}

function TermsOfService() {
  return (
    <Section title="Terms of Service" lastUpdated="July 28, 2026">
      <P>
        By creating a UNITY account and using the platform, you agree to these terms. Please read them carefully.
      </P>
      <H2>Eligibility</H2>
      <P>
        You must be at least 13 years old to create a UNITY account. By registering, you confirm that you meet this requirement and are legally able to enter into this agreement.
      </P>
      <H2>Your Account</H2>
      <UL>
        <li>You are responsible for keeping your account credentials secure.</li>
        <li>You must provide accurate information during registration.</li>
        <li>You may not create multiple accounts to circumvent restrictions.</li>
        <li>You are responsible for all activity under your account.</li>
      </UL>
      <H2>Acceptable Use</H2>
      <UL>
        <li>Use UNITY in a lawful and respectful manner.</li>
        <li>Do not post content that violates our Content Policy or Community Guidelines.</li>
        <li>Do not harass, threaten, or impersonate other citizens.</li>
        <li>Do not attempt to disrupt, hack, or reverse-engineer the platform.</li>
        <li>Do not use automated scripts or bots without authorization.</li>
      </UL>
      <H2>UNITY Credits</H2>
      <P>
        UNITY Credits are a virtual platform currency with no real-world monetary value. They may not be sold, exchanged for real currency, or transferred outside the platform. Credits are non-refundable.
      </P>
      <H2>Content Ownership</H2>
      <P>
        You retain ownership of content you create on UNITY. By posting, you grant UNITY a license to display, reproduce, and distribute your content within the platform.
      </P>
      <H2>Termination</H2>
      <P>
        UNITY may suspend or terminate accounts that violate these terms. You may delete your account at any time by contacting support@unity.app.
      </P>
      <H2>Changes to Terms</H2>
      <P>
        We may update these terms periodically. Continued use after changes constitutes acceptance of the revised terms.
      </P>
      <H2>Contact</H2>
      <P>
        Questions about these terms? Email legal@unity.app.
      </P>
    </Section>
  );
}

function CommunityGuidelines() {
  return (
    <Section title="Community Guidelines" lastUpdated="July 28, 2026">
      <P>
        UNITY is a global community built on respect, collaboration, and shared progress. These guidelines help keep the platform safe and welcoming for everyone.
      </P>
      <H2>Be Respectful</H2>
      <UL>
        <li>Treat all citizens with dignity, regardless of background, nationality, or beliefs.</li>
        <li>Disagree without being disagreeable. Attack ideas, not people.</li>
        <li>No hate speech, slurs, or targeted harassment of any kind.</li>
      </UL>
      <H2>Be Authentic</H2>
      <UL>
        <li>Use your real identity or a genuine persona. No impersonation.</li>
        <li>Share original content or properly attributed work.</li>
        <li>Do not spread misinformation or disinformation.</li>
      </UL>
      <H2>Be Constructive</H2>
      <UL>
        <li>Contribute meaningfully to discussions, governance, and knowledge sharing.</li>
        <li>Help fellow citizens when you can.</li>
        <li>Report harmful content rather than engaging with it.</li>
      </UL>
      <H2>Be Safe</H2>
      <UL>
        <li>No sharing of personal information about others without consent.</li>
        <li>No content depicting violence, self-harm, or illegal activity.</li>
        <li>No spam, scams, or deceptive commercial activity.</li>
      </UL>
      <H2>Enforcement</H2>
      <P>
        Violations may result in content removal, account warnings, temporary suspension, or permanent ban. Severity and repeat offenses escalate consequences. Appeals can be sent to appeals@unity.app.
      </P>
    </Section>
  );
}

function ContentPolicy() {
  return (
    <Section title="Content Policy" lastUpdated="July 28, 2026">
      <P>
        This policy defines what content is allowed and prohibited on UNITY. It applies to all posts, comments, media, profiles, and proposals.
      </P>
      <H2>Allowed Content</H2>
      <UL>
        <li>Original text, images, and videos that comply with these guidelines.</li>
        <li>Educational, scientific, and cultural content.</li>
        <li>Civil political and governance discussions.</li>
        <li>Personal expression, art, and creative work.</li>
      </UL>
      <H2>Prohibited Content</H2>
      <UL>
        <li>Hate speech or content promoting discrimination based on race, ethnicity, religion, gender, sexual orientation, disability, or nationality.</li>
        <li>Graphic violence, gore, or content depicting harm to people or animals.</li>
        <li>Sexual content involving minors, or any content sexualizing minors.</li>
        <li>Non-consensual intimate images.</li>
        <li>Content promoting terrorism or violent extremism.</li>
        <li>Content facilitating illegal activities, including drug sales or weapons trafficking.</li>
        <li>Malware, phishing links, or other cybersecurity threats.</li>
        <li>Spam, repetitive posts, or unsolicited mass messaging.</li>
      </UL>
      <H2>Media Guidelines</H2>
      <UL>
        <li>Photos and videos must be your own or used with permission.</li>
        <li>No deepfakes or manipulated media presented as real.</li>
        <li>Media must not contain prohibited content as described above.</li>
      </UL>
      <H2>Reporting</H2>
      <P>
        Use the three-dot menu on any post to report content that violates this policy. Reports are reviewed by the moderation team. You can also email reports@unity.app with specific details.
      </P>
      <H2>Consequences</H2>
      <P>
        Prohibited content will be removed. The account responsible may receive a warning, temporary suspension, or permanent ban depending on severity and history.
      </P>
    </Section>
  );
}
