import { useEffect, useState } from 'react';
import { PlanetIcon, GlobeIcon, TrendingIcon } from '@/components/icons';
import { useCountUp, formatNumber } from '@/lib/utils';

const REGIONS = [
  { name: 'Asia-Pacific', citizens: 4820000, innovation: 92, color: 'from-emerald-500/20', code: 'AP' },
  { name: 'Europe', citizens: 3140000, innovation: 88, color: 'from-sky-500/20', code: 'EU' },
  { name: 'Americas', citizens: 3960000, innovation: 90, color: 'from-amber-500/20', code: 'AM' },
  { name: 'Africa', citizens: 2780000, innovation: 76, color: 'from-rose-500/20', code: 'AF' },
  { name: 'Middle East', citizens: 1120000, innovation: 81, color: 'from-teal-500/20', code: 'ME' },
  { name: 'Oceania', citizens: 640000, innovation: 85, color: 'from-indigo-500/20', code: 'OC' },
];

const LANGUAGES = [
  { name: 'English', share: 38 },
  { name: 'Mandarin', share: 21 },
  { name: 'Spanish', share: 12 },
  { name: 'Arabic', share: 8 },
  { name: 'French', share: 7 },
  { name: 'Other', share: 14 },
];

const STATS = [
  { label: 'Connected Citizens', value: 16460000, suffix: '' },
  { label: 'Active Countries', value: 193, suffix: '' },
  { label: 'Languages', value: 7100, suffix: '+' },
  { label: 'Knowledge Nodes', value: 12000000, suffix: '' },
];

export function PlanetView() {
  return (
    <div className="space-y-6">
      {/* Hero */}
      <div className="card p-7 relative overflow-hidden animate-fade-up">
        <div className="absolute inset-0 opacity-40" style={{ background: 'radial-gradient(ellipse at 70% 50%, rgba(80,120,160,0.15), transparent 60%)' }} />
        <div className="relative flex flex-col md:flex-row items-start md:items-center gap-6">
          <div className="relative w-28 h-28 shrink-0">
            <div className="absolute inset-0 rounded-full border border-white/10 animate-pulse-slow" />
            <div className="absolute inset-2 rounded-full border border-white/[0.06]" />
            <div className="absolute inset-0 flex items-center justify-center">
              <PlanetIcon size={64} className="text-white/80" />
            </div>
            <div className="absolute inset-0 rounded-full" style={{ animation: 'spin 24s linear infinite' }}>
              <span className="absolute top-0 left-1/2 -translate-x-1/2 w-1.5 h-1.5 rounded-full bg-white/40" />
            </div>
          </div>
          <div className="flex-1">
            <div className="text-xs tracking-[0.3em] text-white/40 uppercase mb-2">Planet Module</div>
            <h1 className="text-3xl font-semibold tracking-tightest">Civilization Dashboard</h1>
            <p className="text-white/50 mt-2 max-w-xl">
              A living view of humanity — population, culture, language, innovation, and environment, unified in one layer.
            </p>
          </div>
        </div>
      </div>

      {/* Global stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        {STATS.map((s, i) => (
          <StatCard key={s.label} {...s} delay={i * 80} />
        ))}
      </div>

      {/* Regions + Languages */}
      <div className="grid lg:grid-cols-[1.4fr_1fr] gap-4">
        <div className="card p-6 animate-fade-up">
          <div className="flex items-center gap-2 mb-5">
            <GlobeIcon size={16} className="text-white/50" />
            <h2 className="font-medium">Regions</h2>
          </div>
          <div className="space-y-4">
            {REGIONS.map((r) => (
              <div key={r.name}>
                <div className="flex items-center justify-between text-sm mb-1.5">
                  <span className="text-white/80">{r.name}</span>
                  <span className="text-white/40 text-xs">{formatNumber(r.citizens)} citizens · {r.innovation} innovation</span>
                </div>
                <div className="h-2 rounded-full bg-white/[0.05] overflow-hidden">
                  <div
                    className={`h-full rounded-full bg-gradient-to-r ${r.color} to-white/30 transition-all duration-1000`}
                    style={{ width: `${r.innovation}%` }}
                  />
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="card p-6 animate-fade-up">
          <div className="flex items-center gap-2 mb-5">
            <TrendingIcon size={16} className="text-white/50" />
            <h2 className="font-medium">Languages</h2>
          </div>
          <div className="space-y-3">
            {LANGUAGES.map((l) => (
              <div key={l.name} className="flex items-center gap-3">
                <span className="text-sm text-white/70 w-20 shrink-0">{l.name}</span>
                <div className="flex-1 h-1.5 rounded-full bg-white/[0.05] overflow-hidden">
                  <div className="h-full bg-white/30 rounded-full transition-all duration-1000" style={{ width: `${l.share}%` }} />
                </div>
                <span className="text-xs text-white/40 w-8 text-right">{l.share}%</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Cultural spotlight */}
      <div className="grid md:grid-cols-3 gap-3">
        {[
          { title: 'Innovation Index', value: '0.847', trend: '+4.2%', desc: 'Global R&D output growth' },
          { title: 'Environment', value: 'Stable', trend: '↗', desc: 'Atmospheric CO₂ stabilization' },
          { title: 'Cultural Exchange', value: '12.1M', trend: '+11%', desc: 'Cross-border collaborations' },
        ].map((c) => (
          <div key={c.title} className="card p-5 animate-fade-up">
            <div className="text-xs text-white/40 uppercase tracking-wide">{c.title}</div>
            <div className="flex items-baseline gap-2 mt-2">
              <span className="text-2xl font-semibold tracking-tightest">{c.value}</span>
              <span className="text-xs text-emerald-400/80">{c.trend}</span>
            </div>
            <div className="text-xs text-white/40 mt-1">{c.desc}</div>
          </div>
        ))}
      </div>
    </div>
  );
}

function StatCard({ label, value, suffix, delay }: { label: string; value: number; suffix: string; delay: number }) {
  const v = useCountUp(value, 1500);
  return (
    <div
      className="card p-5 animate-fade-up"
      style={{ animationDelay: `${delay}ms` }}
    >
      <div className="text-2xl font-semibold tracking-tightest">
        {formatNumber(v)}{suffix}
      </div>
      <div className="text-xs text-white/40 mt-1">{label}</div>
    </div>
  );
}
