import { useEffect, useState, useCallback } from 'react';
import { SettingsIcon, GlobeIcon, CheckIcon } from '@/components/icons';
import { useSelf } from '@/lib/self';
import { isSupabaseConfigured } from '@/lib/supabase';
import { notifySettingsChange } from '@/lib/settings';
import { showToast } from '@/lib/toast';
import { fetchNotificationPreferences, saveNotificationPreferences, type NotificationPreferences } from '@/lib/notifications';
import { supabase } from '@/lib/supabase';
import type { Citizen } from '@/types';

type ThemeMode = 'dark' | 'light';

interface SettingsState {
  theme: ThemeMode;
  highContrast: boolean;
  starfield: boolean;
  reduceMotion: boolean;
  interfaceLanguage: string;
  notifications: NotificationPreferences;
  privacy: {
    profileVisible: boolean;
    showOnlineStatus: boolean;
    allowTagging: boolean;
  };
}

const DEFAULT_NOTIF: NotificationPreferences = {
  followers: true,
  comments: true,
  likes: true,
  governance: false,
  orion: true,
  missions: false,
  announcements: true,
  push_enabled: true,
  email_enabled: false,
};

const DEFAULT_STATE: SettingsState = {
  theme: 'dark',
  highContrast: false,
  starfield: true,
  reduceMotion: false,
  interfaceLanguage: 'English',
  notifications: { ...DEFAULT_NOTIF },
  privacy: {
    profileVisible: true,
    showOnlineStatus: true,
    allowTagging: true,
  },
};

const STORAGE_KEY = 'unity-settings';

function loadState(): SettingsState {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) return { ...DEFAULT_STATE, ...JSON.parse(raw) };
  } catch { /* ignore */ }
  return DEFAULT_STATE;
}

const SECTIONS = [
  { id: 'account', label: 'Account', desc: 'Your citizen identity' },
  { id: 'appearance', label: 'Appearance', desc: 'Theme and display' },
  { id: 'language', label: 'Language', desc: 'Interface language' },
  { id: 'notifications', label: 'Notifications', desc: 'Alerts and signals' },
  { id: 'privacy', label: 'Privacy', desc: 'Visibility and control' },
  { id: 'system', label: 'System', desc: 'Data and storage' },
  { id: 'about', label: 'About UNITY', desc: 'Version and credits' },
  { id: 'legal', label: 'Privacy & Legal', desc: 'Policies and terms' },
] as const;

const LANGUAGES = ['English', 'Mandarin', 'Spanish', 'Arabic', 'French', 'Japanese', 'Portuguese'];

export function SettingsView({ onLogout }: { onLogout?: () => void }) {
  const { self, updateSelf, logout } = useSelf();
  const [section, setSection] = useState<string>('account');
  const [state, setState] = useState<SettingsState>(loadState);
  const [prefsLoaded, setPrefsLoaded] = useState(false);
  const [privacyLoaded, setPrivacyLoaded] = useState(false);
  const [citizenCount, setCitizenCount] = useState<number | null>(null);

  useEffect(() => {
    const root = document.documentElement;
    root.setAttribute('data-theme', state.highContrast ? 'contrast' : state.theme);
    root.classList.toggle('reduce-motion', state.reduceMotion);
    root.classList.toggle('high-contrast', state.highContrast);
  }, [state.theme, state.highContrast, state.reduceMotion]);

  useEffect(() => {
    try { localStorage.setItem(STORAGE_KEY, JSON.stringify(state)); } catch { /* ignore */ }
  }, [state]);

  const loadPrefs = useCallback(async () => {
    try {
      const prefs = await fetchNotificationPreferences();
      setState((s) => ({ ...s, notifications: prefs }));
    } catch { /* graceful — keep defaults */ }
    finally { setPrefsLoaded(true); }
  }, []);

  useEffect(() => { void loadPrefs(); }, [loadPrefs]);

  const loadPrivacy = useCallback(async () => {
    try {
      const { data, error } = await supabase.from('citizen_privacy').select('*').maybeSingle();
      if (error) return;
      if (data) {
        setState((s) => ({
          ...s,
          privacy: {
            profileVisible: data.profile_visible ?? true,
            showOnlineStatus: data.show_online_status ?? true,
            allowTagging: data.allow_tagging ?? true,
          },
        }));
      }
    } catch { /* graceful */ }
    finally { setPrivacyLoaded(true); }
  }, []);

  useEffect(() => { void loadPrivacy(); }, [loadPrivacy]);

  const loadCitizenCount = useCallback(async () => {
    try {
      const { count } = await supabase.from('citizens').select('*', { count: 'exact', head: true });
      if (count !== null) setCitizenCount(count);
    } catch { /* graceful */ }
  }, []);

  useEffect(() => { if (section === 'about') void loadCitizenCount(); }, [section, loadCitizenCount]);

  const patch = (p: Partial<SettingsState>) => {
    setState((s) => ({ ...s, ...p }));
    notifySettingsChange();
  };

  const patchNotif = useCallback(async (p: Partial<NotificationPreferences>) => {
    setState((s) => ({ ...s, notifications: { ...s.notifications, ...p } }));
    try {
      await saveNotificationPreferences(p);
      showToast('Notification preference saved', 'success');
    } catch {
      showToast('Could not save preference to server', 'error');
    }
  }, []);

  const patchPrivacy = useCallback(async (p: Partial<SettingsState['privacy']>) => {
    setState((s) => ({ ...s, privacy: { ...s.privacy, ...p } }));
    try {
      await supabase.from('citizen_privacy').upsert({
        ...p.profileVisible !== undefined && { profile_visible: p.profileVisible },
        ...p.showOnlineStatus !== undefined && { show_online_status: p.showOnlineStatus },
        ...p.allowTagging !== undefined && { allow_tagging: p.allowTagging },
        updated_at: new Date().toISOString(),
      });
      showToast('Privacy preference saved', 'success');
    } catch {
      showToast('Could not save privacy preference', 'error');
    }
  }, []);

  const clearCache = () => {
    let cleared = 0;
    try {
      const keys = ['unity:orion_history', 'unity:liked_posts', 'unity:saved_posts'];
      keys.forEach((k) => { if (localStorage.getItem(k)) { localStorage.removeItem(k); cleared++; } });
    } catch { /* ignore */ }
    showToast(`Local cache cleared (${cleared} items)`, 'success');
  };

  const getStorageSize = (): string => {
    try {
      let total = 0;
      for (let i = 0; i < localStorage.length; i++) {
        const key = localStorage.key(i);
        if (key) total += (localStorage.getItem(key)?.length ?? 0) + key.length;
      }
      return `${(total / 1024).toFixed(1)} KB`;
    } catch { return '0 KB'; }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-2 mb-1">
        <SettingsIcon size={16} className="text-white/50" />
        <span className="text-xs tracking-[0.3em] text-white/40 uppercase">Settings</span>
      </div>

      <div className="grid md:grid-cols-[240px_1fr] gap-4">
        <div className="card p-3 h-fit">
          {SECTIONS.map((s) => (
            <button key={s.id} onClick={() => setSection(s.id)} className={`w-full text-left p-3 rounded-xl transition-all ${section === s.id ? 'bg-white/[0.08]' : 'hover:bg-white/[0.04]'}`}>
              <div className={`text-sm font-medium ${section === s.id ? 'text-white' : 'text-white/70'}`}>{s.label}</div>
              <div className="text-xs text-white/30 mt-0.5">{s.desc}</div>
            </button>
          ))}
        </div>

        <div className="card p-6 animate-fade-up" key={section}>
          {section === 'account' && self && (
            <AccountSection self={self} updateSelf={updateSelf} onLogout={onLogout} />
          )}
          {section === 'account' && !self && (
            <p className="text-white/50">No citizen identity found. Complete registration from the Citizen tab.</p>
          )}
          {section === 'appearance' && (
            <div className="space-y-5">
              <h2 className="font-medium">Appearance</h2>
              <ThemeToggle
                label="Dark Mode"
                desc="Pure black UNITY visual theme"
                active={state.theme === 'dark' && !state.highContrast}
                onClick={() => { patch({ theme: 'dark', highContrast: false }); showToast('Switched to Dark Mode', 'success'); }}
              />
              <ThemeToggle
                label="Light Mode"
                desc="Bright, clean interface for daytime use"
                active={state.theme === 'light' && !state.highContrast}
                onClick={() => { patch({ theme: 'light', highContrast: false }); showToast('Switched to Light Mode', 'success'); }}
              />
              <ThemeToggle
                label="High-Contrast Mode"
                desc="Increase text and border contrast for readability"
                active={state.highContrast}
                onClick={() => {
                  const next = !state.highContrast;
                  patch({ highContrast: next, theme: next ? 'dark' : state.theme });
                  showToast(next ? 'High-contrast mode enabled' : 'High-contrast mode disabled', 'success');
                }}
              />
              <Toggle
                label="Starfield backdrop"
                desc="Animated cosmic background"
                on={state.starfield}
                onToggle={(v) => { patch({ starfield: v }); showToast(v ? 'Starfield enabled' : 'Starfield disabled', 'info'); }}
              />
              <Toggle
                label="Reduce motion"
                desc="Minimize animations"
                on={state.reduceMotion}
                onToggle={(v) => { patch({ reduceMotion: v }); showToast(v ? 'Motion reduced' : 'Motion restored', 'info'); }}
              />
            </div>
          )}
          {section === 'language' && (
            <div className="space-y-5">
              <h2 className="font-medium">Interface Language</h2>
              <p className="text-xs text-white/30">Select your preferred interface language. Full translations are coming soon — English is the default.</p>
              <div className="space-y-2">
                {LANGUAGES.map((l) => (
                  <button
                    key={l}
                    onClick={() => { patch({ interfaceLanguage: l }); showToast(`Language set to ${l}`, 'success'); }}
                    className="w-full flex items-center justify-between p-3 rounded-xl glass-panel hover:bg-white/[0.07] transition-all"
                  >
                    <span className="text-sm flex items-center gap-2"><GlobeIcon size={15} className="text-white/40" /> {l}</span>
                    {state.interfaceLanguage === l && <CheckIcon size={16} className="text-white" />}
                  </button>
                ))}
              </div>
            </div>
          )}
          {section === 'notifications' && (
            <div className="space-y-5">
              <h2 className="font-medium">Notifications</h2>
              {!prefsLoaded ? (
                <div className="flex justify-center py-4">
                  <div className="w-5 h-5 rounded-full border-2 border-white/20 border-t-white/60 animate-spin" />
                </div>
              ) : (
                <>
                  <Toggle label="Push notifications" desc="Enable all push notifications" on={state.notifications.push_enabled} onToggle={(v) => void patchNotif({ push_enabled: v })} />
                  <Toggle label="Email notifications" desc="Receive notifications via email" on={state.notifications.email_enabled} onToggle={(v) => void patchNotif({ email_enabled: v })} />
                  <div className="h-px bg-white/5 my-2" />
                  <Toggle label="New followers" desc="When someone follows you" on={state.notifications.followers} onToggle={(v) => void patchNotif({ followers: v })} />
                  <Toggle label="Likes on your posts" desc="When someone likes your post" on={state.notifications.likes} onToggle={(v) => void patchNotif({ likes: v })} />
                  <Toggle label="Comments on your posts" desc="Replies to your feed posts" on={state.notifications.comments} onToggle={(v) => void patchNotif({ comments: v })} />
                  <Toggle label="Governance proposals" desc="New proposals in your communities" on={state.notifications.governance} onToggle={(v) => void patchNotif({ governance: v })} />
                  <Toggle label="ORION updates" desc="Smart feed and AI suggestions" on={state.notifications.orion} onToggle={(v) => void patchNotif({ orion: v })} />
                  <Toggle label="Mission launches" desc="Space module activity" on={state.notifications.missions} onToggle={(v) => void patchNotif({ missions: v })} />
                  <Toggle label="Announcements" desc="Platform-wide announcements" on={state.notifications.announcements} onToggle={(v) => void patchNotif({ announcements: v })} />
                </>
              )}
            </div>
          )}
          {section === 'privacy' && (
            <div className="space-y-5">
              <h2 className="font-medium">Privacy</h2>
              <Toggle label="Public profile" desc="Your Citizen ID is visible to others" on={state.privacy.profileVisible} onToggle={(v) => { void patchPrivacy({ profileVisible: v }); }} />
              <Toggle label="Online status" desc="Show when you're active" on={state.privacy.showOnlineStatus} onToggle={(v) => { void patchPrivacy({ showOnlineStatus: v }); }} />
              <Toggle label="Allow tagging" desc="Others can tag you in posts" on={state.privacy.allowTagging} onToggle={(v) => { void patchPrivacy({ allowTagging: v }); }} />
            </div>
          )}
          {section === 'system' && (
            <div className="space-y-5">
              <h2 className="font-medium">System</h2>
              <Row label="Local data" value={getStorageSize()} />
              <Row label="Connection" value={isSupabaseConfigured ? 'Online · Supabase' : 'Local mode'} />
              <button onClick={clearCache} className="btn-ghost w-full mt-2">
                Clear local cache
              </button>
            </div>
          )}
          {section === 'about' && (
            <div className="space-y-5">
              <h2 className="font-medium">About UNITY</h2>
              <p className="text-sm text-white/60 leading-relaxed">A digital civilization layer connecting humanity — people, knowledge, technology, AI, culture, innovation, and global collaboration in a single intelligent ecosystem.</p>
              <div className="space-y-2">
                <Row label="Version" value="3.0 · Platform Edition" />
                <Row label="AI System" value="ORION" />
                <Row label="Citizens" value={citizenCount !== null ? `${citizenCount.toLocaleString()} connected` : 'Loading…'} />
                <Row label="License" value="Open Civilization" />
              </div>
            </div>
          )}
          {section === 'legal' && (
            <div className="space-y-4">
              <h2 className="font-medium">Privacy & Legal</h2>
              <p className="text-sm text-unity-muted leading-relaxed">Review the policies and terms that govern your use of UNITY. Full documents are available in the Legal section from the menu.</p>
              <div className="space-y-2">
                <div className="card p-4"><div className="font-medium text-sm mb-1">Privacy Policy</div><div className="text-xs text-unity-faint leading-relaxed">How UNITY collects, uses, and protects your personal information and data.</div></div>
                <div className="card p-4"><div className="font-medium text-sm mb-1">Terms of Service</div><div className="text-xs text-unity-faint leading-relaxed">The rules and conditions for using the UNITY platform.</div></div>
                <div className="card p-4"><div className="font-medium text-sm mb-1">Community Guidelines</div><div className="text-xs text-unity-faint leading-relaxed">Standards for respectful and constructive participation.</div></div>
                <div className="card p-4"><div className="font-medium text-sm mb-1">Content Policy</div><div className="text-xs text-unity-faint leading-relaxed">What content is allowed and prohibited on UNITY.</div></div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

function AccountSection({ self, updateSelf, onLogout }: { self: Citizen; updateSelf: (p: Partial<Citizen>) => Promise<void>; onLogout?: () => void }) {
  const { logout } = useSelf();
  const [name, setName] = useState(self.name);
  const [bio, setBio] = useState(self.bio);
  const [saving, setSaving] = useState(false);

  const save = async () => {
    setSaving(true);
    try {
      await updateSelf({ name: name.trim() || self.name, bio: bio.trim() });
      showToast('Account details saved', 'success');
    } catch {
      showToast('Could not save account details', 'error');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="space-y-5">
      <h2 className="font-medium">Citizen Identity</h2>
      <div className="flex items-center gap-4">
        <div className="w-16 h-16 rounded-full bg-white/[0.06] border border-[#2a2a2a]/80 flex items-center justify-center text-xl font-medium overflow-hidden">
          {self.avatar_url ? <img src={self.avatar_url} alt="" className="w-full h-full object-cover" /> : self.name.split(' ').map((w: string) => w[0]).slice(0, 2).join('')}
        </div>
        <div>
          <div className="font-medium">{self.name}</div>
          <div className="text-sm text-white/40">@{self.handle}</div>
        </div>
      </div>
      <div className="space-y-3">
        <div>
          <label className="text-xs text-white/40 mb-1.5 block">Name</label>
          <input value={name} onChange={(e) => setName(e.target.value)} className="input-field py-2.5" />
        </div>
        <div>
          <label className="text-xs text-white/40 mb-1.5 block">Biography</label>
          <textarea value={bio} onChange={(e) => setBio(e.target.value)} rows={3} className="input-field py-2.5 resize-none" />
        </div>
        <div className="text-xs text-white/40 space-y-2 pt-2">
          <div className="flex justify-between"><span>Handle</span><span className="text-white/60">@{self.handle}</span></div>
          <div className="flex justify-between"><span>Country</span><span className="text-white/60">{self.country}</span></div>
          <div className="flex justify-between"><span>Language</span><span className="text-white/60">{self.language}</span></div>
        </div>
      </div>
      <button onClick={save} disabled={saving} className="btn-primary disabled:opacity-50">
        {saving ? 'Saving…' : 'Save changes'}
      </button>
      <button
        onClick={() => { logout(); onLogout?.(); showToast('Signed out', 'info'); }}
        className="btn-ghost w-full mt-2 text-white/70 hover:text-white"
      >
        Sign out
      </button>
    </div>
  );
}

function ThemeToggle({ label, desc, active, onClick }: { label: string; desc: string; active: boolean; onClick: () => void }) {
  return (
    <button onClick={onClick} className="w-full flex items-center justify-between p-3 rounded-xl glass-panel hover:bg-white/[0.07] transition-all">
      <div className="text-left">
        <div className="text-sm">{label}</div>
        <div className="text-xs text-white/40 mt-0.5">{desc}</div>
      </div>
      <div className={`w-5 h-5 rounded-full border-2 flex items-center justify-center transition-all ${active ? 'border-white bg-white' : 'border-white/20'}`}>
        {active && <CheckIcon size={12} className="text-black" />}
      </div>
    </button>
  );
}

function Toggle({ label, desc, on, onToggle }: { label: string; desc: string; on: boolean; onToggle: (v: boolean) => void }) {
  return (
    <button onClick={() => onToggle(!on)} className="w-full flex items-center justify-between p-3 rounded-xl glass-panel hover:bg-white/[0.07] transition-all">
      <div className="text-left">
        <div className="text-sm">{label}</div>
        <div className="text-xs text-white/40 mt-0.5">{desc}</div>
      </div>
      <div className={`w-10 h-6 rounded-full transition-all relative ${on ? 'bg-white' : 'bg-white/[0.1]'}`}>
        <span className={`absolute top-0.5 w-5 h-5 rounded-full transition-all ${on ? 'left-[18px] bg-black' : 'left-0.5 bg-white/60'}`} />
      </div>
    </button>
  );
}

function Row({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex items-center justify-between py-3 border-b border-[#2a2a2a]/60 last:border-0">
      <span className="text-sm text-white/60">{label}</span>
      <span className="text-sm text-white/80">{value}</span>
    </div>
  );
}
