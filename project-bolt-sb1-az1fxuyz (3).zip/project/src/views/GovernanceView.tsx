import { useCallback, useEffect, useState } from 'react';
import { GovernanceIcon, CheckIcon, ArrowRightIcon, PlusIcon, CloseIcon } from '@/components/icons';
import { formatNumber, timeAgo } from '@/lib/utils';
import { useSelf } from '@/lib/self';
import { fetchProposals, createProposal, castVote, subscribeToGovernance, type ProposalRow } from '@/lib/modules';
import { showToast } from '@/lib/toast';

export function GovernanceView() {
  const { self } = useSelf();
  const [proposals, setProposals] = useState<ProposalRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [showNew, setShowNew] = useState(false);

  const load = useCallback(async () => {
    setLoading(true);
    try { setProposals(await fetchProposals()); } catch { showToast('Could not load proposals', 'error'); }
    finally { setLoading(false); }
  }, []);

  useEffect(() => { load(); }, [load]);
  useEffect(() => { const unsub = subscribeToGovernance(() => void load()); return unsub; }, [load]);

  const handleVote = async (p: ProposalRow, vote: 'for' | 'against') => {
    if (!self) return;
    try {
      await castVote(p.id, vote, p.my_vote ?? null);
      setProposals((prev) => prev.map((x) => {
        if (x.id !== p.id) return x;
        const prevVote = x.my_vote;
        let votesFor = x.votes_for;
        let votesAgainst = x.votes_against;
        if (prevVote === 'for') votesFor--;
        if (prevVote === 'against') votesAgainst--;
        if (vote === 'for') votesFor++;
        if (vote === 'against') votesAgainst++;
        return { ...x, votes_for: votesFor, votes_against: votesAgainst, my_vote: vote };
      }));
      showToast(vote === 'for' ? 'Voted for' : 'Voted against', 'success');
    } catch { showToast('Could not record vote', 'error'); }
  };

  return (
    <div className="space-y-6">
      <div className="card p-6 animate-fade-up flex flex-col sm:flex-row sm:items-end justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-2">
            <GovernanceIcon size={18} className="text-unity-muted" />
            <span className="text-xs tracking-[0.3em] text-unity-faint uppercase">Governance</span>
          </div>
          <h1 className="text-3xl font-semibold tracking-tightest">Community Decisions</h1>
          <p className="text-unity-muted mt-2">Proposals, voting, and discussions shaping the future of civilization.</p>
        </div>
        <button onClick={() => setShowNew(true)} className="btn-primary shrink-0"><PlusIcon size={16} /> New Proposal</button>
      </div>

      {loading ? (
        <div className="space-y-3">
          {[0, 1, 2].map((i) => <div key={i} className="card p-5 h-24 animate-shimmer" />)}
        </div>
      ) : proposals.length === 0 ? (
        <div className="card p-12 text-center">
          <GovernanceIcon size={32} className="text-unity-faint mx-auto mb-3" />
          <p className="text-unity-muted text-sm">No proposals yet. Create the first one.</p>
        </div>
      ) : (
        <div className="space-y-3">
          {proposals.map((p, i) => {
            const total = p.votes_for + p.votes_against;
            const forPct = total ? Math.round((p.votes_for / total) * 100) : 50;
            return (
              <div key={p.id} className="card p-5 animate-fade-up" style={{ animationDelay: `${i * 60}ms` }}>
                <div className="flex items-center gap-2 mb-2">
                  <span className={`px-2 py-0.5 rounded-full text-[10px] border capitalize ${p.status === 'active' ? 'bg-emerald-400/10 text-emerald-300 border-emerald-400/20' : p.status === 'passed' ? 'bg-sky-400/10 text-sky-300 border-sky-400/20' : 'bg-rose-400/10 text-rose-300 border-rose-400/20'}`}>{p.status}</span>
                  <span className="text-xs text-unity-faint">@{p.author_handle} · {timeAgo(p.created_at)}</span>
                </div>
                <h3 className="font-medium leading-snug">{p.title}</h3>
                <p className="text-sm text-unity-muted mt-1 line-clamp-2">{p.description}</p>
                <div className="mt-4 flex items-center gap-3">
                  <div className="flex-1 h-1.5 rounded-full bg-unity-surface overflow-hidden">
                    <div className="h-full bg-emerald-400/50 rounded-full" style={{ width: `${forPct}%` }} />
                  </div>
                  <span className="text-xs text-unity-faint shrink-0">{formatNumber(total)} votes</span>
                </div>
                {p.status === 'active' && self && (
                  <div className="flex gap-3 mt-4">
                    <button onClick={() => handleVote(p, 'for')} className={`flex-1 py-2.5 rounded-xl border transition-all flex items-center justify-center gap-2 text-sm ${p.my_vote === 'for' ? 'bg-emerald-400/20 border-emerald-400/40 text-emerald-300' : 'bg-unity-surface border-unity-border hover:bg-unity-surface-strong'}`}>
                      <CheckIcon size={15} /> For
                    </button>
                    <button onClick={() => handleVote(p, 'against')} className={`flex-1 py-2.5 rounded-xl border transition-all text-sm ${p.my_vote === 'against' ? 'bg-rose-400/20 border-rose-400/40 text-rose-300' : 'bg-unity-surface border-unity-border hover:bg-unity-surface-strong'}`}>
                      Against
                    </button>
                  </div>
                )}
                {p.my_vote && <p className="text-center text-xs text-unity-muted mt-3">Your vote: {p.my_vote}</p>}
              </div>
            );
          })}
        </div>
      )}

      {showNew && self && <NewProposalModal citizenId={self.id} onClose={() => setShowNew(false)} onCreated={() => { setShowNew(false); load(); }} />}
    </div>
  );
}

function NewProposalModal({ citizenId, onClose, onCreated }: { citizenId: string; onClose: () => void; onCreated: () => void }) {
  const [title, setTitle] = useState('');
  const [desc, setDesc] = useState('');
  const [busy, setBusy] = useState(false);

  const submit = async () => {
    if (!title.trim()) return;
    setBusy(true);
    try {
      await createProposal(citizenId, title.trim(), desc.trim());
      showToast('Proposal created', 'success');
      onCreated();
    } catch { showToast('Could not create proposal', 'error'); }
    finally { setBusy(false); }
  };

  return (
    <div className="fixed inset-0 z-[9000] flex items-center justify-center p-5 animate-fade-in" onClick={onClose}>
      <div className="absolute inset-0 bg-black/80 backdrop-blur-md" />
      <div className="relative glass-strong rounded-3xl p-7 max-w-md w-full animate-scale-in" onClick={(e) => e.stopPropagation()}>
        <div className="flex items-center justify-between mb-5">
          <h3 className="text-lg font-semibold">New Proposal</h3>
          <button onClick={onClose} className="btn-icon w-8 h-8"><CloseIcon size={18} /></button>
        </div>
        <div className="space-y-4">
          <div><label className="text-xs text-unity-faint mb-1.5 block">Title</label><input value={title} onChange={(e) => setTitle(e.target.value)} placeholder="What should civilization decide?" className="input-field" autoFocus /></div>
          <div><label className="text-xs text-unity-faint mb-1.5 block">Description</label><textarea value={desc} onChange={(e) => setDesc(e.target.value)} rows={3} placeholder="Explain the proposal…" className="input-field resize-none" /></div>
          <button onClick={submit} disabled={busy || !title.trim()} className="btn-primary w-full disabled:opacity-40">{busy ? 'Submitting…' : 'Submit Proposal'}</button>
        </div>
      </div>
    </div>
  );
}
