import { useCallback, useEffect, useState, useRef } from 'react';
import { useAuth } from '@/lib/auth';
import { useSelf } from '@/lib/self';
import { Avatar } from '@/components/Avatar';
import { VerifiedBadge } from '@/components/VerifiedBadge';
import { ConfirmDialog } from '@/components/ConfirmDialog';
import { CitizenProfileModal } from '@/components/CitizenProfileModal';
import {
  ShieldIcon, TrashIcon, ChartIcon, FlagIcon, BellIcon, UsersIcon,
  FileIcon, BanIcon, SettingsIcon, MoreIcon, EditIcon, PinIcon,
  VerifiedIcon, CheckCircleIcon, XCircleIcon, RestoreIcon, EyeIcon,
  ActivityIcon, ImageIcon2, CloseIcon,
} from '@/components/icons';
import { showToast } from '@/lib/toast';
import { supabase } from '@/lib/supabase';
import type { Citizen, Report, ReportStatus } from '@/types';
import {
  fetchAdminStats, fetchAdminUsers, searchAdminUsers, updateCitizenByAdmin,
  setCitizenVerified, toggleSuspendCitizen, deleteCitizen, fetchAdminPosts,
  adminEditPost, adminDeletePost, adminToggleFeatured, fetchAnnouncements,
  createAnnouncement, deleteAnnouncement, searchAdminPosts,
  adminDeleteComment, fetchAdminComments,
  fetchPlatformSettings, updatePlatformSettings,
  fetchWeeklyGrowth, setCitizenRole,
  deleteReport, dismissReport,
  type AdminStats, type AdminUser, type AdminPost, type AdminAnnouncement,
} from '@/lib/admin';
import { fetchReports, updateReportStatus, resolveReportAndDeleteContent } from '@/lib/reports';

type AdminTab = 'overview' | 'users' | 'posts' | 'announcements' | 'reports' | 'media' | 'settings';

export function AdminView() {
  const { isAdmin } = useAuth();
  const { self } = useSelf();
  const [tab, setTab] = useState<AdminTab>('overview');
  const [stats, setStats] = useState<AdminStats | null>(null);
  const [users, setUsers] = useState<AdminUser[]>([]);
  const [posts, setPosts] = useState<AdminPost[]>([]);
  const [reports, setReports] = useState<Report[]>([]);
  const [announcements, setAnnouncements] = useState<AdminAnnouncement[]>([]);
  const [weeklyGrowth, setWeeklyGrowth] = useState<number[]>([0, 0, 0, 0, 0, 0, 0]);

  const loadStats = useCallback(async () => {
    try { setStats(await fetchAdminStats()); } catch { /* graceful */ }
  }, []);

  const loadUsers = useCallback(async () => {
    try { setUsers(await fetchAdminUsers()); } catch { showToast('Could not load users', 'error'); }
  }, []);

  const loadPosts = useCallback(async () => {
    try { setPosts(await fetchAdminPosts()); } catch { showToast('Could not load posts', 'error'); }
  }, []);

  const loadReports = useCallback(async () => {
    try { setReports(await fetchReports()); } catch { /* graceful */ }
  }, []);

  const loadAnnouncements = useCallback(async () => {
    try { setAnnouncements(await fetchAnnouncements()); } catch { /* graceful */ }
  }, []);

  const loadWeeklyGrowth = useCallback(async () => {
    try { setWeeklyGrowth(await fetchWeeklyGrowth()); } catch { /* graceful */ }
  }, []);

  useEffect(() => {
    if (tab === 'overview') { void loadStats(); void loadWeeklyGrowth(); }
  }, [tab, loadStats, loadWeeklyGrowth]);

  if (!isAdmin) {
    return (
      <div className="flex items-center justify-center py-20">
        <div className="text-center">
          <ShieldIcon size={40} className="text-white/20 mx-auto mb-3" />
          <p className="text-white/40 text-sm">Access restricted to administrators.</p>
        </div>
      </div>
    );
  }

  const TABS: { id: AdminTab; label: string; Icon: typeof ShieldIcon }[] = [
    { id: 'overview', label: 'Overview', Icon: ChartIcon },
    { id: 'users', label: 'Users', Icon: UsersIcon },
    { id: 'posts', label: 'Content', Icon: FileIcon },
    { id: 'announcements', label: 'Announce', Icon: BellIcon },
    { id: 'reports', label: 'Reports', Icon: FlagIcon },
    { id: 'media', label: 'Media', Icon: ImageIcon2 },
    { id: 'settings', label: 'Settings', Icon: SettingsIcon },
  ];

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-2 mb-1">
        <ShieldIcon size={16} className="text-white/50" />
        <span className="text-xs tracking-[0.3em] text-white/40 uppercase">Administration</span>
      </div>

      <div className="flex gap-1 p-1 rounded-full glass-panel w-fit overflow-x-auto no-scrollbar max-w-full">
        {TABS.map(({ id, label, Icon }) => (
          <button
            key={id}
            onClick={() => {
              setTab(id);
              if (id === 'users') void loadUsers();
              if (id === 'posts') void loadPosts();
              if (id === 'reports') void loadReports();
              if (id === 'announcements') void loadAnnouncements();
            }}
            className={`shrink-0 flex items-center gap-1.5 px-3.5 py-2 rounded-full text-sm font-medium transition-all ${
              tab === id ? 'bg-white/10 text-white' : 'text-white/50 hover:text-white/80'
            }`}
          >
            <Icon size={15} /> {label}
            {id === 'reports' && stats && stats.openReports > 0 && (
              <span className="ml-0.5 px-1.5 py-0.5 rounded-full bg-rose-500/20 text-rose-400 text-[10px] font-semibold">
                {stats.openReports}
              </span>
            )}
          </button>
        ))}
      </div>

      {tab === 'overview' && stats && <OverviewTab stats={stats} weeklyGrowth={weeklyGrowth} />}
      {tab === 'users' && <UsersTab users={users} onLoad={loadUsers} selfId={self?.id} />}
      {tab === 'posts' && <PostsTab posts={posts} onLoad={loadPosts} />}
      {tab === 'announcements' && <AnnouncementsTab announcements={announcements} onLoad={loadAnnouncements} authorId={self?.id} />}
      {tab === 'reports' && <ReportsTab reports={reports} onLoad={loadReports} />}
      {tab === 'media' && <MediaTab />}
      {tab === 'settings' && <SettingsTab />}
    </div>
  );
}

/* ============================================================ Overview */

function OverviewTab({ stats, weeklyGrowth }: { stats: AdminStats; weeklyGrowth: number[] }) {
  const maxVal = Math.max(...weeklyGrowth, 1);

  return (
    <div className="space-y-4">
      <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-3">
        <StatCard label="Total Citizens" value={stats.totalCitizens} icon={<UsersIcon size={16} />} />
        <StatCard label="New This Week" value={stats.newThisWeek} icon={<ActivityIcon size={16} />} accent="emerald" />
        <StatCard label="Total Posts" value={stats.totalPosts} icon={<FileIcon size={16} />} />
        <StatCard label="Verified Citizens" value={stats.verifiedUsers} icon={<VerifiedIcon size={16} />} accent="sky" />
        <StatCard label="Active Proposals" value={stats.totalProposals} icon={<ChartIcon size={16} />} />
        <StatCard label="Total Votes" value={stats.totalVotes} icon={<CheckCircleIcon size={16} />} />
        <StatCard label="Open Reports" value={stats.openReports} icon={<FlagIcon size={16} />} accent={stats.openReports > 0 ? 'rose' : undefined} />
        <StatCard label="Suspended" value={stats.suspendedUsers} icon={<BanIcon size={16} />} accent="amber" />
      </div>

      <div className="card p-6">
        <div className="flex items-center justify-between mb-4">
          <h3 className="font-medium">Citizen Growth (7 days)</h3>
          <span className="text-xs text-white/40">+{stats.newToday} today</span>
        </div>
        <div className="flex items-end gap-2 h-32">
          {weeklyGrowth.map((v, i) => (
            <div key={i} className="flex-1 flex flex-col items-center gap-1.5">
              <div
                className="w-full rounded-t-lg bg-gradient-to-t from-white/10 to-white/30 transition-all hover:from-white/20 hover:to-white/50"
                style={{ height: `${Math.max((v / maxVal) * 100, 4)}%` }}
                title={`${v} new citizens`}
              />
              <span className="text-[10px] text-white/30">{['M', 'T', 'W', 'T', 'F', 'S', 'S'][i]}</span>
            </div>
          ))}
        </div>
      </div>

      <SystemStatus />
    </div>
  );
}

/* ================================================================ Users */

function UsersTab({ users, onLoad, selfId }: { users: AdminUser[]; onLoad: () => void; selfId?: string }) {
  const [search, setSearch] = useState('');
  const [editUser, setEditUser] = useState<AdminUser | null>(null);
  const [confirmDelete, setConfirmDelete] = useState<AdminUser | null>(null);
  const [openProfile, setOpenProfile] = useState<Citizen | null>(null);
  const [roleUser, setRoleUser] = useState<AdminUser | null>(null);

  const onSearch = async (q: string) => {
    setSearch(q);
    try {
      if (!q.trim()) { onLoad(); return; }
      setUsers(await searchAdminUsers(q));
    } catch { showToast('Search failed', 'error'); }
  };

  const onToggleVerify = async (u: AdminUser) => {
    try {
      await setCitizenVerified(u.id, !u.verified);
      setUsers((prev) => prev.map((x) => x.id === u.id ? { ...x, verified: !u.verified } : x));
    } catch { showToast('Could not update verification', 'error'); }
  };

  const onToggleSuspend = async (u: AdminUser) => {
    try {
      const next = await toggleSuspendCitizen(u.id, u.suspended);
      setUsers((prev) => prev.map((x) => x.id === u.id ? { ...x, suspended: next } : x));
    } catch { showToast('Could not update account', 'error'); }
  };

  const onConfirmDelete = async () => {
    if (!confirmDelete) return;
    try {
      await deleteCitizen(confirmDelete.id);
      setUsers((prev) => prev.filter((x) => x.id !== confirmDelete.id));
      setConfirmDelete(null);
      showToast('Account deleted', 'success');
    } catch { showToast('Could not delete account', 'error'); }
  };

  const onEditSave = async (patch: Partial<Citizen>) => {
    if (!editUser) return;
    try {
      await updateCitizenByAdmin(editUser.id, patch);
      setUsers((prev) => prev.map((x) => x.id === editUser.id ? { ...x, ...patch } as AdminUser : x));
      setEditUser(null);
      showToast('Profile updated', 'success');
    } catch { showToast('Could not update profile', 'error'); }
  };

  const onSetRole = async (role: 'admin' | 'moderator' | 'citizen') => {
    if (!roleUser) return;
    try {
      await setCitizenRole(roleUser.id, role);
      setUsers((prev) => prev.map((x) => x.id === roleUser.id ? { ...x, role } as AdminUser : x));
      setRoleUser(null);
      showToast('Role updated', 'success');
    } catch { showToast('Could not update role', 'error'); }
  };

  return (
    <div className="space-y-3">
      <div className="flex items-center gap-2">
        <input
          value={search}
          onChange={(e) => onSearch(e.target.value)}
          placeholder="Search citizens by name, username, or country…"
          className="input-field flex-1 py-2.5 text-sm"
        />
        <button onClick={onLoad} className="btn-ghost shrink-0">Refresh</button>
      </div>

      {users.length === 0 ? (
        <div className="card p-12 text-center">
          <UsersIcon size={32} className="text-white/20 mx-auto mb-3" />
          <p className="text-white/40 text-sm">No citizens found.</p>
        </div>
      ) : (
        users.map((u) => (
          <div key={u.id} className="card p-4">
            <div className="flex items-center gap-3">
              <button onClick={() => setOpenProfile(u)} className="shrink-0">
                <Avatar src={u.avatar_url} name={u.name} size={42} verified={u.verified} />
              </button>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-1.5 flex-wrap">
                  <span className="font-medium text-sm truncate">{u.name}</span>
                  {u.verified && <VerifiedBadge size={13} />}
                  {u.is_admin && <ShieldIcon size={13} className="text-sky-400" />}
                  {u.suspended && <span className="text-[10px] text-rose-400 px-1.5 py-0.5 rounded-full bg-rose-500/10">Suspended</span>}
                </div>
                <div className="text-xs text-white/40 truncate">@{u.handle} · {u.country}</div>
                <div className="text-[11px] text-white/30 mt-0.5">
                  {u.post_count ?? 0} posts · joined {new Date(u.created_at).toLocaleDateString('en', { month: 'short', day: 'numeric' })}
                </div>
              </div>
              <UserActions
                user={u}
                isSelf={u.id === selfId}
                onVerify={() => onToggleVerify(u)}
                onSuspend={() => onToggleSuspend(u)}
                onEdit={() => setEditUser(u)}
                onViewProfile={() => setOpenProfile(u)}
                onDelete={() => setConfirmDelete(u)}
                onSetRole={() => setRoleUser(u)}
              />
            </div>
          </div>
        ))
      )}

      {editUser && <EditUserModal user={editUser} onSave={onEditSave} onClose={() => setEditUser(null)} />}
      {confirmDelete && (
        <ConfirmDialog
          title="Delete account?"
          message={`This will permanently delete ${confirmDelete.name}'s account and all associated data. This cannot be undone.`}
          confirmLabel="Delete permanently"
          destructive
          onConfirm={onConfirmDelete}
          onCancel={() => setConfirmDelete(null)}
        />
      )}
      {openProfile && (
        <CitizenProfileModal
          citizenId={openProfile.id}
          fallback={{ name: openProfile.name, handle: openProfile.handle, avatar: openProfile.avatar_url, verified: openProfile.verified }}
          onClose={() => setOpenProfile(null)}
        />
      )}
      {roleUser && (
        <RoleModal
          user={roleUser}
          onSelect={onSetRole}
          onClose={() => setRoleUser(null)}
        />
      )}
    </div>
  );
}

function UserActions({
  user, isSelf, onVerify, onSuspend, onEdit, onViewProfile, onDelete, onSetRole,
}: {
  user: AdminUser;
  isSelf: boolean;
  onVerify: () => void;
  onSuspend: () => void;
  onEdit: () => void;
  onViewProfile: () => void;
  onDelete: () => void;
  onSetRole: () => void;
}) {
  const [open, setOpen] = useState(false);
  return (
    <div className="relative shrink-0">
      <button onClick={() => setOpen((v) => !v)} className="btn-icon w-8 h-8" aria-label="User actions">
        <MoreIcon size={18} />
      </button>
      {open && (
        <>
          <div className="fixed inset-0 z-20" onClick={() => setOpen(false)} />
          <div className="absolute right-0 top-full mt-1 w-52 glass-strong rounded-xl border border-white/10 py-1 z-30 animate-fade-in">
            <ActionItem icon={<EyeIcon size={15} />} label="View profile" onClick={() => { setOpen(false); onViewProfile(); }} />
            <ActionItem icon={<EditIcon size={15} />} label="Edit profile" onClick={() => { setOpen(false); onEdit(); }} />
            {!isSelf && (
              <>
                <ActionItem
                  icon={user.verified ? <XCircleIcon size={15} /> : <VerifiedIcon size={15} />}
                  label={user.verified ? 'Remove verification' : 'Verify citizen'}
                  onClick={() => { setOpen(false); onVerify(); }}
                  accent={user.verified ? 'rose' : 'sky'}
                />
                <ActionItem
                  icon={user.suspended ? <RestoreIcon size={15} /> : <BanIcon size={15} />}
                  label={user.suspended ? 'Restore account' : 'Suspend account'}
                  onClick={() => { setOpen(false); onSuspend(); }}
                  accent={user.suspended ? 'emerald' : 'amber'}
                />
                <ActionItem icon={<ShieldIcon size={15} />} label="Set role" onClick={() => { setOpen(false); onSetRole(); }} />
                <ActionItem icon={<TrashIcon size={15} />} label="Delete account" onClick={() => { setOpen(false); onDelete(); }} accent="rose" />
              </>
            )}
          </div>
        </>
      )}
    </div>
  );
}

function ActionItem({ icon, label, onClick, accent }: { icon: React.ReactNode; label: string; onClick: () => void; accent?: 'rose' | 'emerald' | 'amber' | 'sky' }) {
  const color = accent === 'rose' ? 'text-rose-400/80 hover:text-rose-400 hover:bg-rose-500/10'
    : accent === 'emerald' ? 'text-emerald-400/80 hover:text-emerald-400 hover:bg-emerald-500/10'
    : accent === 'amber' ? 'text-amber-400/80 hover:text-amber-400 hover:bg-amber-500/10'
    : accent === 'sky' ? 'text-sky-400/80 hover:text-sky-400 hover:bg-sky-500/10'
    : 'text-white/60 hover:text-white hover:bg-white/[0.05]';
  return (
    <button onClick={onClick} className={`w-full flex items-center gap-2.5 px-3.5 py-2.5 text-sm transition-all ${color}`}>
      {icon} {label}
    </button>
  );
}

function EditUserModal({ user, onSave, onClose }: { user: AdminUser; onSave: (patch: Partial<Citizen>) => Promise<void>; onClose: () => void }) {
  const [name, setName] = useState(user.name);
  const [handle, setHandle] = useState(user.handle);
  const [bio, setBio] = useState(user.bio);
  const [country, setCountry] = useState(user.country);
  const [busy, setBusy] = useState(false);

  const save = async () => {
    setBusy(true);
    try {
      await onSave({ name: name.trim(), handle: handle.trim().toLowerCase(), bio, country });
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="fixed inset-0 z-[9100] flex items-center justify-center p-4 animate-fade-in" onClick={onClose}>
      <div className="absolute inset-0 bg-black/90 backdrop-blur-xl" />
      <div className="relative glass-strong rounded-3xl w-full max-w-md p-6 animate-scale-in" onClick={(e) => e.stopPropagation()}>
        <div className="flex items-center justify-between mb-5">
          <div className="flex items-center gap-2.5">
            <Avatar src={user.avatar_url} name={user.name} size={36} verified={user.verified} />
            <h2 className="font-semibold text-lg">Edit Profile</h2>
          </div>
          <button onClick={onClose} className="btn-icon"><CloseIcon size={20} /></button>
        </div>

        <div className="space-y-4">
          <Field label="Display Name">
            <input value={name} onChange={(e) => setName(e.target.value)} className="input-field py-2.5" />
          </Field>
          <Field label="Username">
            <div className="flex items-center gap-2">
              <span className="text-white/30 text-sm">@</span>
              <input value={handle} onChange={(e) => setHandle(e.target.value.replace(/[^a-z0-9_]/gi, '').toLowerCase())} className="input-field flex-1 py-2.5" />
            </div>
          </Field>
          <Field label="Country">
            <input value={country} onChange={(e) => setCountry(e.target.value)} className="input-field py-2.5" />
          </Field>
          <Field label="Bio">
            <textarea value={bio} onChange={(e) => setBio(e.target.value)} rows={3} className="input-field resize-none py-2.5" />
          </Field>
        </div>

        <div className="flex gap-3 mt-6">
          <button onClick={onClose} className="btn-ghost flex-1">Cancel</button>
          <button onClick={save} disabled={busy || !name.trim() || !handle.trim()} className="btn-primary flex-1 disabled:opacity-40">
            {busy ? 'Saving…' : 'Save changes'}
          </button>
        </div>
      </div>
    </div>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div>
      <label className="text-xs text-white/40 uppercase tracking-wide mb-1.5 block">{label}</label>
      {children}
    </div>
  );
}

/* ================================================================ Posts */

function PostsTab({ posts, onLoad }: { posts: AdminPost[]; onLoad: () => void }) {
  const [search, setSearch] = useState('');
  const [editing, setEditing] = useState<AdminPost | null>(null);
  const [editText, setEditText] = useState('');
  const [confirmDelete, setConfirmDelete] = useState<AdminPost | null>(null);
  const [viewingComments, setViewingComments] = useState<AdminPost | null>(null);
  const [comments, setComments] = useState<{ id: string; content: string; created_at: string; author_id: string }[]>([]);
  const [confirmDeleteComment, setConfirmDeleteComment] = useState<string | null>(null);
  const [loadingComments, setLoadingComments] = useState(false);

  const onSearch = async (q: string) => {
    setSearch(q);
    try {
      if (!q.trim()) { onLoad(); return; }
      setPosts(await searchAdminPosts(q));
    } catch { showToast('Search failed', 'error'); }
  };

  const onSaveEdit = async () => {
    if (!editing) return;
    try {
      await adminEditPost(editing.id, editText.trim());
      setPosts((prev) => prev.map((p) => p.id === editing.id ? { ...p, content: editText.trim(), edited_at: new Date().toISOString() } : p));
      setEditing(null);
      showToast('Post updated', 'success');
    } catch { showToast('Could not update post', 'error'); }
  };

  const onConfirmDeletePost = async () => {
    if (!confirmDelete) return;
    try {
      await adminDeletePost(confirmDelete.id);
      setPosts((prev) => prev.filter((p) => p.id !== confirmDelete.id));
      setConfirmDelete(null);
      showToast('Post deleted', 'success');
    } catch { showToast('Could not delete post', 'error'); }
  };

  const onFeature = async (p: AdminPost) => {
    try {
      const next = await adminToggleFeatured(p.id, p.featured);
      setPosts((prev) => prev.map((x) => x.id === p.id ? { ...x, featured: next } : x));
    } catch { showToast('Could not update post', 'error'); }
  };

  const loadComments = async (postId: string) => {
    setLoadingComments(true);
    try {
      const data = await fetchAdminComments(postId);
      setComments(data);
    } catch { showToast('Could not load comments', 'error'); }
    finally { setLoadingComments(false); }
  };

  const onDeleteComment = async () => {
    if (!confirmDeleteComment || !viewingComments) return;
    try {
      await adminDeleteComment(confirmDeleteComment);
      setComments((prev) => prev.filter((c) => c.id !== confirmDeleteComment));
      setConfirmDeleteComment(null);
    } catch { showToast('Could not delete comment', 'error'); }
  };

  return (
    <div className="space-y-3">
      <div className="flex items-center gap-2">
        <input
          value={search}
          onChange={(e) => onSearch(e.target.value)}
          placeholder="Search posts by content…"
          className="input-field flex-1 py-2.5 text-sm"
        />
        <button onClick={onLoad} className="btn-ghost shrink-0">Refresh</button>
      </div>

      {posts.length === 0 ? (
        <div className="card p-12 text-center">
          <FileIcon size={32} className="text-white/20 mx-auto mb-3" />
          <p className="text-white/40 text-sm">No posts found.</p>
        </div>
      ) : posts.map((p) => (
        <div key={p.id} className="card p-4">
          <div className="flex items-start justify-between gap-3">
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-1.5 mb-1">
                <Avatar src={p.author?.avatar_url} name={p.author?.name ?? 'Unknown'} size={20} verified={p.author?.verified} />
                <span className="text-xs text-white/50">@{p.author?.handle ?? 'unknown'}</span>
                {p.featured && <span className="text-[10px] text-amber-400/80 flex items-center gap-0.5"><PinIcon size={10} /> Featured</span>}
                {p.edited_at && <span className="text-[10px] text-white/30 italic">edited</span>}
              </div>
              <p className="text-sm text-white/80 whitespace-pre-wrap line-clamp-3">{p.content}</p>
            </div>
            <div className="flex items-center gap-1 shrink-0">
              <button onClick={() => onFeature(p)} className={`btn-icon w-8 h-8 ${p.featured ? 'text-amber-400' : 'text-white/40 hover:text-amber-400'}`} title="Feature">
                <PinIcon size={15} />
              </button>
              <button onClick={() => { setViewingComments(p); void loadComments(p.id); }} className="btn-icon w-8 h-8 text-white/40 hover:text-white" title="Comments">
                <FileIcon size={15} />
              </button>
              <button onClick={() => { setEditing(p); setEditText(p.content); }} className="btn-icon w-8 h-8 text-white/50 hover:text-white" title="Edit">
                <EditIcon size={15} />
              </button>
              <button onClick={() => setConfirmDelete(p)} className="btn-icon w-8 h-8 text-rose-400/70 hover:text-rose-400 hover:bg-rose-500/10" title="Delete">
                <TrashIcon size={15} />
              </button>
            </div>
          </div>
        </div>
      ))}

      {editing && (
        <div className="fixed inset-0 z-[9100] flex items-center justify-center p-4 animate-fade-in" onClick={() => setEditing(null)}>
          <div className="absolute inset-0 bg-black/90 backdrop-blur-xl" />
          <div className="relative glass-strong rounded-3xl w-full max-w-md p-6 animate-scale-in" onClick={(e) => e.stopPropagation()}>
            <div className="flex items-center justify-between mb-4">
              <h2 className="font-semibold text-lg">Edit Post</h2>
              <button onClick={() => setEditing(null)} className="btn-icon"><CloseIcon size={20} /></button>
            </div>
            <textarea value={editText} onChange={(e) => setEditText(e.target.value)} rows={5} className="input-field resize-none" autoFocus />
            <div className="flex gap-3 mt-4">
              <button onClick={() => setEditing(null)} className="btn-ghost flex-1">Cancel</button>
              <button onClick={onSaveEdit} disabled={!editText.trim()} className="btn-primary flex-1 disabled:opacity-40">Save</button>
            </div>
          </div>
        </div>
      )}

      {viewingComments && (
        <div className="fixed inset-0 z-[9100] flex items-center justify-center p-4 animate-fade-in" onClick={() => setViewingComments(null)}>
          <div className="absolute inset-0 bg-black/90 backdrop-blur-xl" />
          <div className="relative glass-strong rounded-3xl w-full max-w-lg p-6 animate-scale-in max-h-[80vh] overflow-y-auto" onClick={(e) => e.stopPropagation()}>
            <div className="flex items-center justify-between mb-4">
              <h2 className="font-semibold text-lg">Comments</h2>
              <button onClick={() => setViewingComments(null)} className="btn-icon"><CloseIcon size={20} /></button>
            </div>
            <p className="text-xs text-white/40 mb-4 line-clamp-2">{viewingComments.content}</p>
            {loadingComments ? (
              <div className="flex justify-center py-8">
                <div className="w-6 h-6 rounded-full border-2 border-white/20 border-t-white/60 animate-spin" />
              </div>
            ) : comments.length === 0 ? (
              <p className="text-white/40 text-sm text-center py-8">No comments on this post.</p>
            ) : (
              <div className="space-y-2">
                {comments.map((c) => (
                  <div key={c.id} className="glass-panel rounded-xl p-3 flex items-start justify-between gap-2">
                    <div className="flex-1 min-w-0">
                      <p className="text-sm text-white/80 whitespace-pre-wrap">{c.content}</p>
                      <span className="text-[10px] text-white/30">{new Date(c.created_at).toLocaleString('en', { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' })}</span>
                    </div>
                    <button onClick={() => setConfirmDeleteComment(c.id)} className="btn-icon w-7 h-7 text-rose-400/70 hover:text-rose-400 hover:bg-rose-500/10 shrink-0" title="Delete comment">
                      <TrashIcon size={13} />
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}

      {confirmDelete && (
        <ConfirmDialog
          title="Delete post?"
          message="This post will be permanently removed from the platform."
          confirmLabel="Delete"
          destructive
          onConfirm={onConfirmDeletePost}
          onCancel={() => setConfirmDelete(null)}
        />
      )}

      {confirmDeleteComment && (
        <ConfirmDialog
          title="Delete comment?"
          message="This comment will be permanently removed."
          confirmLabel="Delete"
          destructive
          onConfirm={onDeleteComment}
          onCancel={() => setConfirmDeleteComment(null)}
        />
      )}
    </div>
  );
}

/* ========================================================= Announcements */

function AnnouncementsTab({ announcements, onLoad, authorId }: { announcements: AdminAnnouncement[]; onLoad: () => void; authorId?: string }) {
  const [content, setContent] = useState('');
  const [busy, setBusy] = useState(false);

  const publish = async () => {
    if (!content.trim() || !authorId) return;
    setBusy(true);
    try {
      await createAnnouncement(authorId, content.trim());
      setContent('');
      onLoad();
      showToast('Announcement published', 'success');
    } catch { showToast('Could not publish announcement', 'error'); }
    finally { setBusy(false); }
  };

  const remove = async (id: string) => {
    try { await deleteAnnouncement(id); onLoad(); showToast('Announcement deleted', 'success'); } catch { showToast('Could not delete', 'error'); }
  };

  return (
    <div className="space-y-4">
      <div className="card p-6 space-y-4">
        <h2 className="font-medium">Create Announcement</h2>
        <textarea
          value={content}
          onChange={(e) => setContent(e.target.value)}
          rows={4}
          placeholder="Write a civilization-wide announcement…"
          className="input-field resize-none"
        />
        <button onClick={publish} disabled={busy || !content.trim()} className="btn-primary disabled:opacity-40">
          {busy ? 'Publishing…' : 'Publish to Feed'}
        </button>
      </div>

      <div className="space-y-2">
        <div className="text-xs text-white/30 uppercase tracking-wide px-1">Published Announcements</div>
        {announcements.length === 0 ? (
          <div className="card p-8 text-center">
            <BellIcon size={28} className="text-white/20 mx-auto mb-2" />
            <p className="text-white/40 text-sm">No announcements yet.</p>
          </div>
        ) : announcements.map((a) => (
          <div key={a.id} className="card p-4">
            <div className="flex items-start justify-between gap-3">
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-1.5 mb-1">
                  <BellIcon size={13} className="text-sky-400" />
                  <span className="text-xs text-white/40">@{a.author?.handle ?? 'admin'}</span>
                  <span className="text-xs text-white/30">· {new Date(a.created_at).toLocaleString('en', { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' })}</span>
                </div>
                <p className="text-sm text-white/85 whitespace-pre-wrap">{a.content}</p>
              </div>
              <button onClick={() => remove(a.id)} className="btn-icon w-8 h-8 text-rose-400/70 hover:text-rose-400 hover:bg-rose-500/10 shrink-0">
                <TrashIcon size={15} />
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

/* ============================================================ Reports */

function ReportsTab({ reports, onLoad }: { reports: Report[]; onLoad: () => void }) {
  const [filter, setFilter] = useState<ReportStatus | 'all'>('all');
  const [confirmAction, setConfirmAction] = useState<{ report: Report; action: 'resolve' | 'delete_content' | 'dismiss' | 'delete_report' } | null>(null);

  const filtered = filter === 'all' ? reports : reports.filter((r) => r.status === filter);

  const takeAction = async () => {
    if (!confirmAction) return;
    const { report, action } = confirmAction;
    try {
      if (action === 'delete_content') {
        await resolveReportAndDeleteContent(report.id, report.target_type, report.target_id);
        showToast('Content removed and report resolved', 'success');
      } else if (action === 'resolve') {
        await updateReportStatus(report.id, 'resolved');
        showToast('Report resolved', 'success');
      } else if (action === 'dismiss') {
        await dismissReport(report.id);
      } else if (action === 'delete_report') {
        await deleteReport(report.id);
      }
      onLoad();
      setConfirmAction(null);
    } catch { showToast('Could not complete action', 'error'); }
  };

  const statusColor = (s: string) =>
    s === 'open' ? 'text-amber-400 bg-amber-500/10'
    : s === 'reviewed' ? 'text-sky-400 bg-sky-500/10'
    : s === 'resolved' ? 'text-emerald-400 bg-emerald-500/10'
    : 'text-white/40 bg-white/5';

  return (
    <div className="space-y-3">
      <div className="flex items-center gap-2">
        {(['all', 'open', 'reviewed', 'resolved', 'dismissed'] as const).map((s) => (
          <button
            key={s}
            onClick={() => setFilter(s)}
            className={`px-3 py-1.5 rounded-full text-xs font-medium capitalize transition-all ${
              filter === s ? 'bg-white/10 text-white' : 'glass-panel text-white/50 hover:text-white/80'
            }`}
          >
            {s}
          </button>
        ))}
        <button onClick={onLoad} className="btn-ghost ml-auto shrink-0">Refresh</button>
      </div>

      {filtered.length === 0 ? (
        <div className="card p-12 text-center">
          <FlagIcon size={32} className="text-white/20 mx-auto mb-3" />
          <p className="text-white/40 text-sm">No reports {filter !== 'all' ? `with status "${filter}"` : ''}.</p>
        </div>
      ) : filtered.map((r) => (
        <div key={r.id} className="card p-4">
          <div className="flex items-start gap-3">
            <div className="w-9 h-9 rounded-xl bg-amber-500/10 flex items-center justify-center text-amber-400 shrink-0">
              <FlagIcon size={16} />
            </div>
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2 flex-wrap">
                <span className="text-sm font-medium capitalize">{r.target_type} report</span>
                <span className={`text-[10px] px-2 py-0.5 rounded-full capitalize ${statusColor(r.status)}`}>{r.status}</span>
              </div>
              <p className="text-sm text-white/60 mt-1">{r.reason}</p>
              <div className="text-xs text-white/30 mt-1">
                Target: {r.target_id.slice(0, 8).toUpperCase()} · {new Date(r.created_at).toLocaleDateString('en', { month: 'short', day: 'numeric' })}
              </div>
            </div>
            {r.status !== 'resolved' && r.status !== 'dismissed' && (
              <div className="flex items-center gap-1 shrink-0">
                <button
                  onClick={() => setConfirmAction({ report: r, action: 'resolve' })}
                  className="btn-icon w-8 h-8 text-emerald-400/70 hover:text-emerald-400"
                  title="Resolve"
                >
                  <CheckCircleIcon size={16} />
                </button>
                <button
                  onClick={() => setConfirmAction({ report: r, action: 'delete_content' })}
                  className="btn-icon w-8 h-8 text-rose-400/70 hover:text-rose-400 hover:bg-rose-500/10"
                  title="Remove content & resolve"
                >
                  <TrashIcon size={15} />
                </button>
                <button
                  onClick={() => setConfirmAction({ report: r, action: 'dismiss' })}
                  className="btn-icon w-8 h-8 text-white/40 hover:text-white/70"
                  title="Dismiss"
                >
                  <XCircleIcon size={15} />
                </button>
              </div>
            )}
            <button
              onClick={() => setConfirmAction({ report: r, action: 'delete_report' })}
              className="btn-icon w-8 h-8 text-white/30 hover:text-rose-400 shrink-0"
              title="Delete report record"
            >
              <CloseIcon size={14} />
            </button>
          </div>
        </div>
      ))}

      {confirmAction && (
        <ConfirmDialog
          title={
            confirmAction.action === 'delete_content' ? 'Remove content?' :
            confirmAction.action === 'delete_report' ? 'Delete report?' :
            confirmAction.action === 'dismiss' ? 'Dismiss report?' : 'Resolve report?'
          }
          message={
            confirmAction.action === 'delete_content'
              ? 'The reported content will be permanently deleted and the report marked as resolved.'
              : confirmAction.action === 'delete_report'
              ? 'The report record will be permanently deleted from the database.'
              : confirmAction.action === 'dismiss'
              ? 'This report will be marked as dismissed. No action will be taken on the content.'
              : 'This report will be marked as resolved without removing the content.'
          }
          confirmLabel={
            confirmAction.action === 'delete_content' ? 'Delete & resolve' :
            confirmAction.action === 'delete_report' ? 'Delete report' :
            confirmAction.action === 'dismiss' ? 'Dismiss' : 'Resolve'
          }
          destructive={confirmAction.action === 'delete_content' || confirmAction.action === 'delete_report'}
          onConfirm={takeAction}
          onCancel={() => setConfirmAction(null)}
        />
      )}
    </div>
  );
}

/* ============================================================ Media */

function MediaTab() {
  const [uploading, setUploading] = useState<string | null>(null);
  const [mediaList, setMediaList] = useState<{ name: string; url: string }[]>([]);
  const [loading, setLoading] = useState(true);
  const fileRef = useRef<HTMLInputElement>(null);
  const [selectedSlot, setSelectedSlot] = useState<string>('');

  const loadMedia = useCallback(async () => {
    setLoading(true);
    try {
      const { data, error } = await supabase.storage.from('media').list('platform', { limit: 50, sortBy: { column: 'created_at', order: 'desc' } });
      if (error) throw error;
      const items = (data ?? []).filter((f) => f.metadata?.mimetype?.startsWith('image/')).map((f) => ({
        name: f.name,
        url: supabase.storage.from('media').getPublicUrl(`platform/${f.name}`).data.publicUrl,
      }));
      setMediaList(items);
    } catch { /* bucket may not exist yet */ }
    finally { setLoading(false); }
  }, []);

  useEffect(() => { void loadMedia(); }, [loadMedia]);

  const onUpload = async (file: File, slot: string) => {
    setUploading(slot);
    try {
      const ext = file.name.split('.').pop()?.toLowerCase() ?? 'png';
      const path = `platform/${slot}-${Date.now()}.${ext}`;
      const { error: upErr } = await supabase.storage.from('media').upload(path, file, { cacheControl: '3600', upsert: true });
      if (upErr) throw upErr;
      showToast(`${slot} uploaded successfully`, 'success');
      void loadMedia();
    } catch (err) {
      showToast(`Upload failed: ${(err as Error).message}`, 'error');
    } finally {
      setUploading(null);
      setSelectedSlot('');
      if (fileRef.current) fileRef.current.value = '';
    }
  };

  const onFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file && selectedSlot) void onUpload(file, selectedSlot);
  };

  const MEDIA_SLOTS = ['App Icon', 'Login Banner', 'Featured Content', 'OG Image', 'Splash Screen', 'Brand Logo'];

  const triggerUpload = (slot: string) => {
    setSelectedSlot(slot);
    fileRef.current?.click();
  };

  return (
    <div className="space-y-4">
      <input ref={fileRef} type="file" accept="image/*" className="hidden" onChange={onFileChange} />

      <div className="card p-6">
        <h2 className="font-medium mb-2">Platform Media</h2>
        <p className="text-sm text-white/40 mb-4">Upload platform-level images, banners, and branding assets. Files are stored in Supabase Storage.</p>
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
          {MEDIA_SLOTS.map((label) => (
            <div key={label} className="glass-panel rounded-xl p-4 text-center">
              <ImageIcon2 size={24} className="text-white/20 mx-auto mb-2" />
              <div className="text-xs text-white/50 mb-2">{label}</div>
              <button
                onClick={() => triggerUpload(label)}
                disabled={uploading === label}
                className="text-[11px] text-white/40 hover:text-white/70 disabled:opacity-40"
              >
                {uploading === label ? 'Uploading…' : 'Upload'}
              </button>
            </div>
          ))}
        </div>
      </div>

      <div className="card p-6">
        <div className="flex items-center justify-between mb-4">
          <h2 className="font-medium">Uploaded Assets</h2>
          <button onClick={loadMedia} className="btn-ghost text-xs">Refresh</button>
        </div>
        {loading ? (
          <div className="flex justify-center py-8">
            <div className="w-6 h-6 rounded-full border-2 border-white/20 border-t-white/60 animate-spin" />
          </div>
        ) : mediaList.length === 0 ? (
          <p className="text-white/40 text-sm text-center py-8">No media uploaded yet.</p>
        ) : (
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            {mediaList.map((m) => (
              <div key={m.name} className="glass-panel rounded-xl overflow-hidden group">
                <div className="aspect-square bg-white/5">
                  <img src={m.url} alt={m.name} className="w-full h-full object-cover" loading="lazy" />
                </div>
                <div className="p-2">
                  <div className="text-[10px] text-white/40 truncate">{m.name}</div>
                  <button
                    onClick={async () => {
                      try {
                        const path = m.name.includes('/') ? m.name : `platform/${m.name}`;
                        await supabase.storage.from('media').remove([path]);
                        showToast('Asset deleted', 'success');
                        void loadMedia();
                      } catch { showToast('Could not delete asset', 'error'); }
                    }}
                    className="text-[10px] text-rose-400/60 hover:text-rose-400 mt-1"
                  >
                    Delete
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

/* ============================================================ Settings */

interface PlatformSettings {
  site_name: string;
  site_description: string;
  maintenance_mode: boolean;
  registration_open: boolean;
  announcement_banner: string | null;
}

function SettingsTab() {
  const [settings, setSettings] = useState<PlatformSettings | null>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [editName, setEditName] = useState('');
  const [editDesc, setEditDesc] = useState('');
  const [editBanner, setEditBanner] = useState('');

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const s = await fetchPlatformSettings();
      if (s) {
        setSettings(s);
        setEditName(s.site_name);
        setEditDesc(s.site_description);
        setEditBanner(s.announcement_banner ?? '');
      }
    } catch { /* graceful */ }
    finally { setLoading(false); }
  }, []);

  useEffect(() => { void load(); }, [load]);

  const onSave = async () => {
    setSaving(true);
    try {
      await updatePlatformSettings({
        site_name: editName.trim() || 'UNITY',
        site_description: editDesc.trim(),
        announcement_banner: editBanner.trim() || null,
      });
      void load();
    } catch { showToast('Could not save settings', 'error'); }
    finally { setSaving(false); }
  };

  const onToggleMaintenance = async () => {
    if (!settings) return;
    try {
      await updatePlatformSettings({ maintenance_mode: !settings.maintenance_mode });
      void load();
    } catch { showToast('Could not update', 'error'); }
  };

  const onToggleRegistration = async () => {
    if (!settings) return;
    try {
      await updatePlatformSettings({ registration_open: !settings.registration_open });
      void load();
    } catch { showToast('Could not update', 'error'); }
  };

  if (loading) {
    return (
      <div className="flex justify-center py-12">
        <div className="w-6 h-6 rounded-full border-2 border-white/20 border-t-white/60 animate-spin" />
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <div className="card p-6 space-y-4">
        <h2 className="font-medium">Platform Settings</h2>
        <Field label="Site Name">
          <input value={editName} onChange={(e) => setEditName(e.target.value)} className="input-field py-2.5" />
        </Field>
        <Field label="Site Description">
          <textarea value={editDesc} onChange={(e) => setEditDesc(e.target.value)} rows={2} className="input-field resize-none py-2.5" />
        </Field>
        <Field label="Announcement Banner">
          <input value={editBanner} onChange={(e) => setEditBanner(e.target.value)} placeholder="Leave empty for no banner" className="input-field py-2.5" />
        </Field>
        <div className="flex items-center gap-2">
          <button onClick={onSave} disabled={saving} className="btn-primary disabled:opacity-40">
            {saving ? 'Saving…' : 'Save settings'}
          </button>
        </div>
      </div>

      <div className="card p-6 space-y-4">
        <h2 className="font-medium">Platform Controls</h2>
        <ToggleRow
          label="Maintenance Mode"
          desc="Show a maintenance banner to all citizens"
          on={settings?.maintenance_mode ?? false}
          onToggle={onToggleMaintenance}
        />
        <ToggleRow
          label="Registration Open"
          desc="Allow new citizens to sign up"
          on={settings?.registration_open ?? true}
          onToggle={onToggleRegistration}
        />
      </div>

      <div className="card p-6">
        <h2 className="font-medium mb-4">System Information</h2>
        <div className="space-y-2 text-sm">
          <InfoRow label="Version" value="3.0 · Platform Edition" />
          <InfoRow label="Database" value="Supabase (PostgreSQL + RLS)" />
          <InfoRow label="Realtime" value="Active" />
          <InfoRow label="Auth" value="Supabase Email/Password" />
        </div>
      </div>

      <div className="card p-6">
        <h2 className="font-medium mb-2">Admin Roles</h2>
        <p className="text-sm text-white/40 mb-4">Role hierarchy: admin &gt; moderator &gt; verified citizen &gt; citizen. Admins have full platform access. Moderators can moderate content. Verified citizens have a verification badge.</p>
        <div className="space-y-2">
          {[
            { role: 'Admin', desc: 'Full access — users, content, media, analytics, reports', color: 'text-sky-400' },
            { role: 'Moderator', desc: 'Content moderation — posts, comments, reports', color: 'text-emerald-400' },
            { role: 'Verified Citizen', desc: 'Verified badge on profile and posts', color: 'text-unity-primary' },
            { role: 'Citizen', desc: 'Standard member — posting, following, messaging', color: 'text-white/60' },
          ].map((r) => (
            <div key={r.role} className="flex items-center gap-3 py-2 border-b border-white/5 last:border-0">
              <ShieldIcon size={16} className={r.color} />
              <div>
                <div className="text-sm font-medium">{r.role}</div>
                <div className="text-xs text-white/40">{r.desc}</div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

function ToggleRow({ label, desc, on, onToggle }: { label: string; desc: string; on: boolean; onToggle: () => void }) {
  return (
    <button onClick={onToggle} className="w-full flex items-center justify-between p-3 rounded-xl glass-panel hover:bg-white/[0.07] transition-all">
      <div className="text-left">
        <div className="text-sm">{label}</div>
        <div className="text-xs text-white/40 mt-0.5">{desc}</div>
      </div>
      <div className={`w-10 h-6 rounded-full transition-all relative ${on ? 'bg-white' : 'bg-white/[0.1]'}`}>
        <span className={`absolute top-0.5 w-5 h-5 rounded-full transition-all ${on ? 'left-[18px] bg-black' : 'left-0.5 bg-white/60'}`} />
      </div>
    </button>
  );
}

/* ============================================================ Shared */

function StatCard({ label, value, icon, accent }: { label: string; value: number; icon: React.ReactNode; accent?: 'emerald' | 'rose' | 'amber' | 'sky' }) {
  const color = accent === 'emerald' ? 'text-emerald-400'
    : accent === 'rose' ? 'text-rose-400'
    : accent === 'amber' ? 'text-amber-400'
    : accent === 'sky' ? 'text-sky-400'
    : 'text-white/60';
  return (
    <div className="card p-5">
      <div className={`flex items-center gap-2 mb-2 ${color}`}>
        {icon}
        <span className="text-[10px] tracking-[0.2em] uppercase">{label}</span>
      </div>
      <div className="text-2xl font-semibold tabular-nums">{value.toLocaleString()}</div>
    </div>
  );
}

function InfoRow({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex items-center justify-between py-2 border-b border-white/5 last:border-0">
      <span className="text-white/40">{label}</span>
      <span className="text-white/80 font-medium">{value}</span>
    </div>
  );
}

function SystemStatus() {
  const [statuses, setStatuses] = useState<Record<string, boolean | null>>({});

  useEffect(() => {
    const checks: { name: string; fn: () => Promise<boolean> }[] = [
      { name: 'Database', fn: async () => { const { error } = await supabase.from('citizens').select('id', { count: 'exact', head: true }).limit(1); return !error; } },
      { name: 'Auth', fn: async () => { const { data } = await supabase.auth.getSession(); return !!data.session; } },
      { name: 'Storage', fn: async () => { const { data, error } = await supabase.storage.from('media').list('posts', { limit: 1 }); return !error && !!data; } },
      { name: 'Realtime', fn: async () => { const ch = supabase.channel('health-check'); const ok = await new Promise<boolean>((resolve) => { const t = setTimeout(() => resolve(false), 3000); ch.subscribe((s) => { clearTimeout(t); resolve(s === 'SUBSCRIBED'); }); }); supabase.removeChannel(ch); return ok; } },
      { name: 'Edge Functions', fn: async () => { try { const res = await fetch(`${import.meta.env.VITE_SUPABASE_URL}/functions/v1/delete-citizen`, { method: 'OPTIONS' }); return res.ok; } catch { return false; } } },
    ];
    void Promise.all(checks.map(async (c) => { const ok = await c.fn(); setStatuses((prev) => ({ ...prev, [c.name]: ok })); }));
  }, []);

  const label = (name: string) => {
    const s = statuses[name];
    if (s === null) return { text: 'Checking…', color: 'text-white/40', dot: 'bg-white/30' };
    if (s) return { text: 'Operational', color: 'text-emerald-400/80', dot: 'bg-emerald-400/80' };
    return { text: 'Degraded', color: 'text-rose-400/80', dot: 'bg-rose-400/80' };
  };

  return (
    <div className="card p-6">
      <h3 className="font-medium mb-4">System Status</h3>
      <div className="space-y-2">
        {['Database', 'Auth', 'Storage', 'Realtime', 'Edge Functions'].map((s) => {
          const st = label(s);
          return (
            <div key={s} className="flex items-center justify-between py-2 border-b border-white/5 last:border-0">
              <span className="text-sm text-white/60">{s}</span>
              <span className={`flex items-center gap-1.5 text-xs ${st.color}`}>
                <span className={`w-1.5 h-1.5 rounded-full ${st.dot} ${s !== 'Edge Functions' ? 'animate-pulse-slow' : ''}`} /> {st.text}
              </span>
            </div>
          );
        })}
      </div>
    </div>
  );
}

function RoleModal({ user, onSelect, onClose }: { user: AdminUser; onSelect: (role: 'admin' | 'moderator' | 'citizen') => void; onClose: () => void }) {
  const roles: { id: 'admin' | 'moderator' | 'citizen'; label: string; desc: string }[] = [
    { id: 'citizen', label: 'Citizen', desc: 'Standard member with posting and interaction access' },
    { id: 'moderator', label: 'Moderator', desc: 'Can moderate content and manage reports' },
    { id: 'admin', label: 'Administrator', desc: 'Full access to all platform management' },
  ];
  return (
    <div className="fixed inset-0 z-[9000] flex items-center justify-center p-4" onClick={onClose}>
      <div className="absolute inset-0 bg-black/80 backdrop-blur-xl" />
      <div className="relative glass-strong rounded-3xl w-full max-w-sm p-6 animate-scale-in" onClick={(e) => e.stopPropagation()}>
        <h3 className="font-semibold text-base mb-1">Set Role</h3>
        <p className="text-sm text-white/50 mb-4">Choose a role for {user.name}</p>
        <div className="space-y-2">
          {roles.map(({ id, label, desc }) => (
            <button
              key={id}
              onClick={() => onSelect(id)}
              className={`w-full text-left p-3 rounded-xl border transition-all ${
                user.role === id ? 'border-unity-primary bg-unity-primary/10' : 'border-white/10 hover:bg-white/5'
              }`}
            >
              <div className="flex items-center justify-between">
                <span className="font-medium text-sm">{label}</span>
                {user.role === id && <span className="text-xs text-unity-primary">Current</span>}
              </div>
              <p className="text-xs text-white/40 mt-0.5">{desc}</p>
            </button>
          ))}
        </div>
        <button onClick={onClose} className="btn-ghost w-full mt-4">Cancel</button>
      </div>
    </div>
  );
}
