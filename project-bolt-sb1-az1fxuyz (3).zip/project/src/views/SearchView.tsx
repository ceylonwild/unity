import { useState, useCallback, useEffect } from 'react';
import type { ModuleId, Citizen, Post } from '@/types';
import { searchCitizens, searchPosts, fetchSuggestedCitizens } from '@/lib/feed';
import { Avatar } from '@/components/Avatar';
import { VerifiedBadge } from '@/components/VerifiedBadge';
import { PostCard } from '@/components/PostCard';
import { SearchIcon, CloseIcon, ArrowRightIcon, GlobeIcon, VerifiedIcon } from '@/components/icons';

type SearchTab = 'citizens' | 'posts';

export function SearchView({ onNavigate, onOpenProfile }: { onNavigate: (id: ModuleId) => void; onOpenProfile: (citizen: Citizen) => void }) {
  const [query, setQuery] = useState('');
  const [tab, setTab] = useState<SearchTab>('citizens');
  const [citizens, setCitizens] = useState<Citizen[]>([]);
  const [posts, setPosts] = useState<Post[]>([]);
  const [suggested, setSuggested] = useState<Citizen[]>([]);
  const [loading, setLoading] = useState(false);
  const [touched, setTouched] = useState(false);
  const [verifiedOnly, setVerifiedOnly] = useState(false);

  useEffect(() => {
    fetchSuggestedCitizens(6).then(setSuggested).catch(() => { /* graceful */ });
  }, []);

  const run = useCallback(async (q: string, searchTab?: SearchTab) => {
    setQuery(q);
    const activeTab = searchTab ?? tab;
    if (!q.trim()) { setCitizens([]); setPosts([]); setTouched(false); return; }
    setTouched(true);
    setLoading(true);
    try {
      if (activeTab === 'citizens') {
        const results = await searchCitizens(q);
        setCitizens(results);
        setPosts([]);
      } else {
        const [postResults, citizenResults] = await Promise.all([
          searchPosts(q),
          searchCitizens(q),
        ]);
        setPosts(postResults);
        setCitizens(citizenResults);
      }
    } catch {
      setCitizens([]);
      setPosts([]);
    } finally {
      setLoading(false);
    }
  }, [tab]);

  const switchTab = (newTab: SearchTab) => {
    setTab(newTab);
    if (query.trim()) void run(query, newTab);
  };

  const handlePostChange = (updated: Post) => {
    setPosts((prev) => prev.map((p) => p.id === updated.id ? updated : p));
  };

  const handlePostDeleted = (id: string) => {
    setPosts((prev) => prev.filter((p) => p.id !== id));
  };

  const filteredCitizens = verifiedOnly ? citizens.filter((c) => c.verified) : citizens;

  return (
    <div className="space-y-6 max-w-2xl mx-auto">
      <div>
        <div className="flex items-center gap-2 mb-1">
          <SearchIcon size={16} className="text-white/50" />
          <span className="text-xs tracking-[0.3em] text-white/40 uppercase">Search</span>
        </div>
        <h1 className="text-2xl font-semibold tracking-tightest">Explore UNITY</h1>
        <p className="text-sm text-white/40 mt-1">Search citizens, posts, and verified voices across the civilization.</p>
      </div>

      {/* Search input */}
      <div className="relative">
        <SearchIcon size={18} className="absolute left-4 top-1/2 -translate-y-1/2 text-white/30" />
        <input
          value={query}
          onChange={(e) => run(e.target.value)}
          placeholder={tab === 'citizens' ? "Search citizens by name, username, or country…" : "Search posts and citizens…"}
          className="input-field pl-11 py-3.5 text-base"
          autoFocus
        />
        {query && (
          <button onClick={() => run('')} className="absolute right-3 top-1/2 -translate-y-1/2 btn-icon w-8 h-8">
            <CloseIcon size={16} />
          </button>
        )}
      </div>

      {/* Tabs */}
      <div className="flex items-center gap-2">
        <div className="flex gap-1 p-1 rounded-full glass-panel">
          <TabButton active={tab === 'citizens'} onClick={() => switchTab('citizens')}>Citizens</TabButton>
          <TabButton active={tab === 'posts'} onClick={() => switchTab('posts')}>Posts</TabButton>
        </div>
        {tab === 'citizens' && touched && citizens.length > 0 && (
          <button
            onClick={() => setVerifiedOnly((v) => !v)}
            className={`ml-auto flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-medium transition-all ${
              verifiedOnly
                ? 'bg-unity-surface-strong text-unity-primary border border-unity-primary/30'
                : 'glass-panel text-white/50 hover:text-white/80'
            }`}
          >
            <VerifiedIcon size={13} /> Verified only
          </button>
        )}
      </div>

      {/* Results */}
      {loading ? (
        <div className="space-y-3">
          {[0, 1, 2].map((i) => <div key={i} className="h-16 rounded-2xl animate-shimmer" />)}
        </div>
      ) : touched && tab === 'citizens' ? (
        filteredCitizens.length === 0 ? (
          <EmptyState query={query} />
        ) : (
          <div className="space-y-2">
            <div className="text-xs text-white/30 px-1">{filteredCitizens.length} result{filteredCitizens.length !== 1 ? 's' : ''}</div>
            {filteredCitizens.map((c) => (
              <button
                key={c.id}
                onClick={() => onOpenProfile(c)}
                className="w-full card p-4 flex items-center gap-3 hover:bg-white/[0.06] transition-all text-left group"
              >
                <Avatar src={c.avatar_url} name={c.name} size={44} verified={c.verified} />
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-1.5">
                    <span className="font-medium text-sm truncate">{c.name}</span>
                    {c.verified && <VerifiedBadge size={14} />}
                  </div>
                  <div className="text-xs text-white/40 truncate">@{c.handle}</div>
                  <div className="flex items-center gap-1.5 mt-1 text-[11px] text-white/30">
                    <GlobeIcon size={11} /> {c.country}
                    <span>·</span>
                    <span className="font-mono">{c.id.slice(0, 8).toUpperCase()}</span>
                  </div>
                </div>
                <ArrowRightIcon size={16} className="text-white/20 group-hover:text-white/60 group-hover:translate-x-0.5 transition-all shrink-0" />
              </button>
            ))}
          </div>
        )
      ) : touched && tab === 'posts' ? (
        <div className="space-y-4">
          {citizens.length > 0 && (
            <div className="space-y-2">
              <div className="text-xs text-white/30 px-1">Citizens matching "{query}"</div>
              {citizens.slice(0, 3).map((c) => (
                <button
                  key={c.id}
                  onClick={() => onOpenProfile(c)}
                  className="w-full card p-3 flex items-center gap-3 hover:bg-white/[0.06] transition-all text-left"
                >
                  <Avatar src={c.avatar_url} name={c.name} size={36} verified={c.verified} />
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-1.5">
                      <span className="font-medium text-sm truncate">{c.name}</span>
                      {c.verified && <VerifiedBadge size={12} />}
                    </div>
                    <div className="text-xs text-white/40 truncate">@{c.handle}</div>
                  </div>
                  <ArrowRightIcon size={14} className="text-white/20 shrink-0" />
                </button>
              ))}
            </div>
          )}
          {posts.length === 0 && citizens.length === 0 ? (
            <EmptyState query={query} />
          ) : posts.length > 0 ? (
            <div className="space-y-3">
              <div className="text-xs text-white/30 px-1">Posts matching "{query}"</div>
              {posts.map((p) => (
                <PostCard key={p.id} post={p} onChange={handlePostChange} onDeleted={handlePostDeleted} />
              ))}
            </div>
          ) : null}
        </div>
      ) : !touched && suggested.length > 0 ? (
        <div className="space-y-4">
          <div className="text-xs tracking-[0.2em] text-white/30 uppercase px-1">Suggested Citizens</div>
          {suggested.map((c) => (
            <button
              key={c.id}
              onClick={() => onOpenProfile(c)}
              className="w-full card p-4 flex items-center gap-3 hover:bg-white/[0.06] transition-all text-left group"
            >
              <Avatar src={c.avatar_url} name={c.name} size={44} verified={c.verified} />
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-1.5">
                  <span className="font-medium text-sm truncate">{c.name}</span>
                  {c.verified && <VerifiedBadge size={14} />}
                </div>
                <div className="text-xs text-white/40 truncate">@{c.handle} · {c.country}</div>
              </div>
              <ArrowRightIcon size={16} className="text-white/20 group-hover:text-white/60 group-hover:translate-x-0.5 transition-all shrink-0" />
            </button>
          ))}
        </div>
      ) : (
        <EmptyState query="" />
      )}

    </div>
  );
}

function TabButton({ active, onClick, children }: { active: boolean; onClick: () => void; children: React.ReactNode }) {
  return (
    <button
      onClick={onClick}
      className={`px-4 py-1.5 rounded-full text-sm font-medium transition-all ${
        active ? 'bg-white/10 text-white' : 'text-white/50 hover:text-white/80'
      }`}
    >
      {children}
    </button>
  );
}

function EmptyState({ query }: { query: string }) {
  return (
    <div className="card p-12 text-center">
      <SearchIcon size={32} className="text-white/20 mx-auto mb-3" />
      <p className="text-white/40 text-sm">
        {query ? <>No results for "{query}"</> : 'Start typing to explore the civilization.'}
      </p>
    </div>
  );
}
