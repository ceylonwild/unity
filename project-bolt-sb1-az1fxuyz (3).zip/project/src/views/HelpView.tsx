import { useState } from 'react';
import {
  CloseIcon, HelpIcon, InfoIcon, FlagIcon, SendIcon, ChevronDownIcon,
} from '@/components/icons';

interface HelpViewProps {
  onBack: () => void;
}

const FAQS = [
  {
    q: 'What is UNITY?',
    a: 'UNITY is a premium global civilization platform that connects humanity through knowledge, governance, communication, and shared resources. It brings together social interaction, learning, democratic participation, and digital economy tools in one unified experience.',
  },
  {
    q: 'How do I create a post?',
    a: 'Tap the composer at the top of the Home feed. You can write text, attach a photo or video, and publish to share with the UNITY community. Your posts appear in the global feed and on your profile.',
  },
  {
    q: 'How do I follow other citizens?',
    a: 'Open any citizen\'s profile by tapping their avatar or name. Tap the "Follow" button on their profile page. You\'ll see their posts in your feed and receive a notification when they post.',
  },
  {
    q: 'What are UNITY Credits?',
    a: 'UNITY Credits (UC) are the platform\'s digital currency. New citizens receive a welcome stipend. You can send credits to other citizens, earn them through platform activity, and use them for transactions within the ecosystem.',
  },
  {
    q: 'How does governance work?',
    a: 'The Governance module lets citizens create and vote on proposals that shape the platform. Each citizen can vote once per proposal. Proposals with strong community support may be implemented by the UNITY team.',
  },
  {
    q: 'How do I change my privacy settings?',
    a: 'Go to Settings → Privacy to control who can see your profile, your online status, and whether others can tag you in posts. You can also manage notification preferences in Settings.',
  },
  {
    q: 'How do I report inappropriate content?',
    a: 'Tap the three-dot menu on any post and select "Report." Choose a reason and optionally add details. Our moderation team reviews all reports and takes appropriate action.',
  },
  {
    q: 'Can I use UNITY in different languages?',
    a: 'UNITY supports multiple languages. You can set your preferred language during onboarding or in Settings. The platform currently supports English and several other major languages.',
  },
];

export function HelpView({ onBack }: HelpViewProps) {
  const [openFaq, setOpenFaq] = useState<number | null>(0);
  const [activeSection, setActiveSection] = useState<'faq' | 'contact' | 'bug' | 'feedback'>('faq');

  return (
    <div className="fixed inset-0 z-[9000] animate-fade-in overflow-y-auto no-scrollbar">
      <div className="absolute inset-0 bg-unity-bg/95 backdrop-blur-xl" />

      <div className="relative min-h-screen flex flex-col">
        <header className="sticky top-0 z-10 glass-strong border-b border-unity-border">
          <div className="mx-auto max-w-2xl px-5 h-14 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <button onClick={onBack} className="btn-icon" aria-label="Back">
                <CloseIcon size={20} />
              </button>
              <div className="text-xs tracking-[0.3em] text-unity-faint uppercase">Help & Support</div>
            </div>
          </div>
        </header>

        <div className="mx-auto max-w-2xl px-5 py-6 w-full flex-1">
          {/* Section tabs */}
          <div className="flex gap-2 mb-6 overflow-x-auto no-scrollbar">
            {([
              { id: 'faq', label: 'FAQ', Icon: HelpIcon },
              { id: 'contact', label: 'Contact Support', Icon: SendIcon },
              { id: 'bug', label: 'Report a Bug', Icon: FlagIcon },
              { id: 'feedback', label: 'Feedback', Icon: InfoIcon },
            ] as const).map(({ id, label, Icon }) => (
              <button
                key={id}
                onClick={() => setActiveSection(id)}
                className={`flex items-center gap-2 px-4 py-2 rounded-full text-sm font-medium transition-all duration-200 shrink-0 ${
                  activeSection === id
                    ? 'btn-primary'
                    : 'btn-ghost'
                }`}
              >
                <Icon size={16} />
                {label}
              </button>
            ))}
          </div>

          {activeSection === 'faq' && (
            <div className="space-y-2">
              {FAQS.map((faq, i) => (
                <div key={i} className="card overflow-hidden">
                  <button
                    onClick={() => setOpenFaq(openFaq === i ? null : i)}
                    className="w-full px-5 py-4 flex items-center justify-between gap-3 text-left"
                  >
                    <span className="font-medium text-sm text-unity-primary">{faq.q}</span>
                    <ChevronDownIcon
                      size={18}
                      className={`text-unity-faint shrink-0 transition-transform duration-200 ${openFaq === i ? 'rotate-180' : ''}`}
                    />
                  </button>
                  {openFaq === i && (
                    <div className="px-5 pb-4 text-sm text-unity-muted leading-relaxed">
                      {faq.a}
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}

          {activeSection === 'contact' && (
            <div className="card p-6">
              <h2 className="font-semibold text-base mb-2">Contact Support</h2>
              <p className="text-sm text-unity-muted mb-5 leading-relaxed">
                Need help with your account, a technical issue, or a question not covered in the FAQ? Our support team is here to help.
              </p>
              <div className="space-y-3">
                <a
                  href="mailto:support@unity.app"
                  className="flex items-center gap-3 px-4 py-3 rounded-xl glass hover:bg-unity-surface-strong transition-all"
                >
                  <div className="w-10 h-10 rounded-xl bg-unity-surface flex items-center justify-center text-unity-muted">
                    <SendIcon size={18} />
                  </div>
                  <div className="flex-1">
                    <div className="font-medium text-sm">Email Support</div>
                    <div className="text-xs text-unity-faint">support@unity.app</div>
                  </div>
                </a>
              </div>
              <p className="text-xs text-unity-faint mt-4">
                Typical response time: 24–48 hours. For urgent account issues, please include your citizen handle in the email.
              </p>
            </div>
          )}

          {activeSection === 'bug' && (
            <BugReportForm />
          )}

          {activeSection === 'feedback' && (
            <FeedbackForm />
          )}
        </div>
      </div>
    </div>
  );
}

function BugReportForm() {
  const [category, setCategory] = useState('');
  const [description, setDescription] = useState('');
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = () => {
    if (!description.trim()) return;
    const subject = encodeURIComponent(`Bug Report: ${category || 'General'}`);
    const body = encodeURIComponent(`${description}\n\n---\nSent from UNITY Help & Support`);
    window.location.href = `mailto:support@unity.app?subject=${subject}&body=${body}`;
    setSubmitted(true);
  };

  if (submitted) {
    return (
      <div className="card p-6 text-center">
        <div className="w-12 h-12 rounded-full bg-emerald-500/10 flex items-center justify-center mx-auto mb-3">
          <InfoIcon size={24} className="text-emerald-400" />
        </div>
        <h2 className="font-semibold text-base mb-1">Report Submitted</h2>
        <p className="text-sm text-unity-muted">Your bug report has been opened in your email client. Thank you for helping improve UNITY.</p>
        <button onClick={() => { setSubmitted(false); setDescription(''); setCategory(''); }} className="btn-ghost mt-4 text-sm">
          Submit another
        </button>
      </div>
    );
  }

  return (
    <div className="card p-6">
      <h2 className="font-semibold text-base mb-2">Report a Bug</h2>
      <p className="text-sm text-unity-muted mb-5 leading-relaxed">
        Found something that isn't working as expected? Tell us what happened and we'll investigate.
      </p>
      <div className="space-y-4">
        <div>
          <label className="text-xs text-unity-faint uppercase tracking-wide mb-1.5 block">Category</label>
          <select
            value={category}
            onChange={(e) => setCategory(e.target.value)}
            className="input-field"
          >
            <option value="">Select a category…</option>
            <option value="App Crash">App crash or freeze</option>
            <option value="Media Upload">Photo or video upload issue</option>
            <option value="Notifications">Notification not working</option>
            <option value="Navigation">Navigation or page loading</option>
            <option value="Display">Display or visual glitch</option>
            <option value="Other">Other</option>
          </select>
        </div>
        <div>
          <label className="text-xs text-unity-faint uppercase tracking-wide mb-1.5 block">What happened?</label>
          <textarea
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            rows={5}
            placeholder="Describe the bug in detail. What were you doing? What did you expect? What actually happened?"
            className="input-field resize-none"
          />
        </div>
        <button onClick={handleSubmit} disabled={!description.trim()} className="btn-primary w-full disabled:opacity-40 disabled:cursor-not-allowed">
          <SendIcon size={16} /> Submit Report
        </button>
      </div>
    </div>
  );
}

function FeedbackForm() {
  const [rating, setRating] = useState(0);
  const [message, setMessage] = useState('');
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = () => {
    if (!message.trim()) return;
    const subject = encodeURIComponent(`UNITY Feedback — Rating: ${rating}/5`);
    const body = encodeURIComponent(`${message}\n\n---\nSent from UNITY Help & Support`);
    window.location.href = `mailto:feedback@unity.app?subject=${subject}&body=${body}`;
    setSubmitted(true);
  };

  if (submitted) {
    return (
      <div className="card p-6 text-center">
        <div className="w-12 h-12 rounded-full bg-emerald-500/10 flex items-center justify-center mx-auto mb-3">
          <InfoIcon size={24} className="text-emerald-400" />
        </div>
        <h2 className="font-semibold text-base mb-1">Feedback Sent</h2>
        <p className="text-sm text-unity-muted">Thank you for sharing your thoughts. We read every piece of feedback.</p>
        <button onClick={() => { setSubmitted(false); setMessage(''); setRating(0); }} className="btn-ghost mt-4 text-sm">
          Send more feedback
        </button>
      </div>
    );
  }

  return (
    <div className="card p-6">
      <h2 className="font-semibold text-base mb-2">Share Feedback</h2>
      <p className="text-sm text-unity-muted mb-5 leading-relaxed">
        We'd love to hear what you think about UNITY. Your feedback directly shapes future updates.
      </p>
      <div className="space-y-4">
        <div>
          <label className="text-xs text-unity-faint uppercase tracking-wide mb-1.5 block">How would you rate UNITY?</label>
          <div className="flex gap-2">
            {[1, 2, 3, 4, 5].map((n) => (
              <button
                key={n}
                onClick={() => setRating(n)}
                className={`w-10 h-10 rounded-xl text-sm font-medium transition-all ${
                  rating >= n ? 'btn-primary' : 'btn-ghost'
                }`}
              >
                {n}
              </button>
            ))}
          </div>
        </div>
        <div>
          <label className="text-xs text-unity-faint uppercase tracking-wide mb-1.5 block">Your feedback</label>
          <textarea
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            rows={5}
            placeholder="What do you love? What could be better? Any features you'd like to see?"
            className="input-field resize-none"
          />
        </div>
        <button onClick={handleSubmit} disabled={!message.trim()} className="btn-primary w-full disabled:opacity-40 disabled:cursor-not-allowed">
          <SendIcon size={16} /> Send Feedback
        </button>
      </div>
    </div>
  );
}
