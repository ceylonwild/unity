import { useEffect, useState, useCallback } from 'react';
import type { Citizen, Post } from '@/types';
import {
  fetchCitizenById, fetchPostsByAuthor, isFollowingCitizen, toggleFollowCitizen,
} from '@/lib/feed';
import { Avatar } from '@/components/Avatar';
import { VerifiedBadge } from '@/components/VerifiedBadge';
import { PostCard } from '@/components/PostCard';
import { ReportModal } from '@/components/ReportModal';
import {
  CloseIcon, UserPlusIcon, UserCheckIcon, FlagIcon, PinIcon, GlobeIcon,
  ArrowRightIcon, FileIcon, ImageIcon2, UsersIcon, CalendarIcon,
  ShieldIcon, ChartIcon,
} from '@/components/icons';
import { supabase } from '@/lib/supabase';
import { useSelf } from '@/lib/self';
import { showToast } from '@/lib/toast';
import { timeAgo, formatNumber } from '@/lib/utils';

type ProfileTab = 'timeline' | 'media' | 'about' | 'stats' | 'followers' | 'following';

export function CitizenProfilePage({
  citizenId,
  onBack,
  onOpenProfile,
}: {
  citizenId: string;
  onBack: () => void;
  onOpenProfile?: (citizen: Citizen) => void;
}) {
  const { self } = useSelf();
  const [citizen, setCitizen] = useState<Citizen | null>(null);
  const [posts, setPosts] = useState<Post[]>([]);
  const [loading, setLoading] = useState(true);
  const [tab, setTab] = useState<ProfileTab>('timeline');
  const [following, setFollowing] = useState(false);
  const [followBusy, setFollowBusy] = useState(false);
  const [followers, setFollowers] = useState(0);
  const [followingCount, setFollowingCount] = useState(0);
  const [followerList, setFollowerList] = useState<Citizen[]>([]);
  const [followingList, setFollowingList] = useState<Citizen[]>([]);
  const [reporting, setReporting] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const [c, p] = await Promise.all([
        fetchCitizenById(citizenId),
        fetchPostsByAuthor(citizenId, 50),
      ]);
      setCitizen(c);
      setPosts(p);
      if (c) {
        const [isF, counts] = await Promise.all([
          isFollowingCitizen(c.id),
          fetchFollowCounts(c.id),
        ]);
        setFollowing(isF);
        setFollowers(counts.followers);
        setFollowingCount(counts.following);
      }
    } catch { /* graceful */ }
    finally { setLoading(false); }
  }, [citizenId]);

  useEffect(() => { void load(); }, [load]);

  // Load follower/following lists lazily when those tabs are opened.
  useEffect(() => {
    if (!citizen || tab !== 'followers' || followerList.length > 0) return;
    void (async () => {
      try {
        const { data: citizenRow } = await supabase
          .from('citizens').select('user_id').eq('id', citizen.id).maybeSingle();
        if (!citizenRow?.user_id) return;
        const { data: follows } = await supabase
          .from('follows').select('follower_id').eq('following_id', citizenRow.user_id);
        if (!follows?.length) return;
        const userIds = follows.map((f: { follower_id: string }) => f.follower_id);
        const { data: citizens } = await supabase
          .from('citizens').select('*').in('user_id', userIds).limit(100);
        if (citizens) setFollowerList(citizens as unknown as Citizen[]);
      } catch { /* graceful */ }
    })();
  }, [citizen, tab, followerList.length]);

  useEffect(() => {
    if (!citizen || tab !== 'following' || followingList.length > 0) return;
    void (async () => {
      try {
        const { data: citizenRow } = await supabase
          .from('citizens').select('user_id').eq('id', citizen.id).maybeSingle();
        if (!citizenRow?.user_id) return;
        const { data: follows } = await supabase
          .from('follows').select('following_id').eq('follower_id', citizenRow.user_id);
        if (!follows?.length) return;
        const userIds = follows.map((f: { following_id: string }) => f.following_id);
        const { data: citizens } = await supabase
          .from('citizens').select('*').in('user_id', userIds).limit(100);
        if (citizens) setFollowingList(citizens as unknown as Citizen[]);
      } catch { /* graceful */ }
    })();
  }, [citizen, tab, followingList.length]);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 120);
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  const isSelf = self?.id === citizen?.id;
  const mediaPosts = posts.filter((p) => p.image_url);

  const onFollowToggle = async () => {
    if (!citizen) return;
    setFollowBusy(true);
    try {
      const next = await toggleFollowCitizen(citizen.id, following);
      setFollowing(next);
      setFollowers((f) => f + (next ? 1 : -1));
      showToast(next ? `Following ${citizen.name}` : `Unfollowed ${citizen.name}`, 'success');
    } catch {
      showToast('Could not update follow status', 'error');
    } finally {
      setFollowBusy(false);
    }
  };

  const handlePostChange = (updated: Post) => {
    setPosts((prev) => prev.map((p) => p.id === updated.id ? updated : p));
  };

  const handlePostDeleted = (id: string) => {
    setPosts((prev) => prev.filter((p) => p.id !== id));
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="w-8 h-8 rounded-full border-2 border-unity-border border-t-unity-muted animate-spin" />
      </div>
    );
  }

  if (!citizen) {
    return (
      <div className="min-h-screen flex items-center justify-center p-6">
        <div className="text-center">
          <UsersIcon size={40} className="text-unity-faint mx-auto mb-3" />
          <p className="text-unity-muted text-sm mb-4">This citizen profile could not be found.</p>
          <button onClick={onBack} className="btn-primary">Go back</button>
        </div>
      </div>
    );
  }

  const TABS: { id: ProfileTab; label: string; Icon: typeof FileIcon }[] = [
    { id: 'timeline', label: 'Timeline', Icon: FileIcon },
    { id: 'media', label: 'Media', Icon: ImageIcon2 },
    { id: 'about', label: 'About', Icon: GlobeIcon },
    { id: 'followers', label: 'Followers', Icon: UsersIcon },
    { id: 'following', label: 'Following', Icon: UserCheckIcon },
    { id: 'stats', label: 'Stats', Icon: ChartIcon },
  ];

  return (
    <div className="min-h-screen pb-28">
      {/* Sticky header */}
      <header className={`sticky top-0 z-40 transition-all duration-300 ${scrolled ? 'glass-strong border-b border-unity-border' : ''}`}>
        <div className="mx-auto max-w-3xl px-5 h-14 flex items-center justify-between">
          <button onClick={onBack} className="btn-icon" aria-label="Back">
            <CloseIcon size={20} />
          </button>
          <div className={`transition-opacity duration-300 ${scrolled ? 'opacity-100' : 'opacity-0'}`}>
            <div className="flex items-center gap-2">
              <Avatar src={citizen.avatar_url} name={citizen.name} size={26} verified={citizen.verified} />
              <span className="font-medium text-sm truncate max-w-[140px]">{citizen.name}</span>
            </div>
          </div>
          {!isSelf && (
            <button onClick={() => setReporting(true)} className="btn-icon" aria-label="Report">
              <FlagIcon size={16} />
            </button>
          )}
          <div className="w-9" />
        </div>
      </header>

      {/* Banner */}
      <div className="relative h-48 sm:h-64 overflow-hidden">
        {citizen.banner_url ? (
          <img src={citizen.banner_url} alt="" className="w-full h-full object-cover" loading="lazy" />
        ) : (
          <div className="w-full h-full bg-gradient-to-br from-unity-surface via-unity-surface-strong to-unity-bg" />
        )}
        <div className="absolute inset-0 bg-gradient-to-b from-transparent via-transparent to-unity-bg" />
      </div>

      {/* Identity hero */}
      <div className="mx-auto max-w-3xl px-5 -mt-16 relative">
        <div className="flex flex-col sm:flex-row sm:items-end gap-4">
          <Avatar src={citizen.avatar_url} name={citizen.name} size={120} ring verified={citizen.verified} />
          <div className="flex-1 min-w-0 pb-2">
            <div className="flex items-center gap-2 flex-wrap">
              <h1 className="text-2xl font-semibold tracking-tightest">{citizen.name}</h1>
              {citizen.verified && <VerifiedBadge size={18} />}
              {citizen.is_admin && <ShieldIcon size={16} className="text-sky-400" />}
            </div>
            <div className="text-sm text-unity-muted mt-0.5">@{citizen.handle}</div>
            <div className="flex items-center gap-2 mt-2 text-xs text-unity-faint">
              <span className="flex items-center gap-1"><GlobeIcon size={12} /> {citizen.country}</span>
              <span>·</span>
              <span className="font-mono">ID: {citizen.id.slice(0, 8).toUpperCase()}</span>
            </div>
          </div>
          {!isSelf && (
            <button
              onClick={onFollowToggle}
              disabled={followBusy}
              className={`shrink-0 px-5 py-2.5 rounded-xl font-medium text-sm transition-all flex items-center gap-2 disabled:opacity-50 ${
                following
                  ? 'glass-panel text-unity-muted hover:text-rose-400 hover:border-rose-500/30'
                  : 'btn-primary'
              }`}
            >
              {following ? <><UserCheckIcon size={16} /> Following</> : <><UserPlusIcon size={16} /> Follow</>}
            </button>
          )}
        </div>

        {/* Bio */}
        {citizen.bio && (
          <p className="text-sm text-unity-muted mt-4 leading-relaxed">{citizen.bio}</p>
        )}

        {/* Stats row */}
        <div className="grid grid-cols-4 gap-2 mt-5">
          <StatBox label="Posts" value={posts.length} />
          <StatBox label="Followers" value={followers} />
          <StatBox label="Following" value={followingCount} />
          <StatBox label="Skills" value={citizen.skills.length} />
        </div>

        {/* Quick info pills */}
        <div className="flex flex-wrap gap-2 mt-4">
          <InfoPill icon={<CalendarIcon size={12} />} label={`Joined ${new Date(citizen.created_at).toLocaleDateString('en', { year: 'numeric', month: 'short' })}`} />
          <InfoPill icon={<GlobeIcon size={12} />} label={citizen.country} />
          <InfoPill icon={<FileIcon size={12} />} label={citizen.language} />
        </div>
      </div>

      {/* Tabs */}
      <div className="mx-auto max-w-3xl px-5 mt-6">
        <div className="flex gap-1 border-b border-unity-border overflow-x-auto no-scrollbar">
          {TABS.map(({ id, label, Icon }) => (
            <button
              key={id}
              onClick={() => setTab(id)}
              className={`shrink-0 flex items-center gap-1.5 px-4 py-3 text-sm font-medium transition-all border-b-2 ${
                tab === id ? 'text-unity-primary border-unity-primary' : 'text-unity-muted border-transparent hover:text-unity-primary/70'
              }`}
            >
              <Icon size={15} /> {label}
            </button>
          ))}
        </div>
      </div>

      {/* Tab content */}
      <div className="mx-auto max-w-3xl px-5 mt-6">
        {tab === 'timeline' && (
          posts.length === 0 ? (
            <EmptyState icon={<FileIcon size={32} />} text="No posts yet." />
          ) : (
            <div className="space-y-4">
              {posts.map((p) => (
                <PostCard key={p.id} post={p} onChange={handlePostChange} onDeleted={handlePostDeleted} videoPosts={posts} />
              ))}
            </div>
          )
        )}

        {tab === 'media' && (
          mediaPosts.length === 0 ? (
            <EmptyState icon={<ImageIcon2 size={32} />} text="No media published." />
          ) : (
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
              {mediaPosts.map((p) => (
                <div key={p.id} className="aspect-square rounded-xl overflow-hidden border border-unity-border group cursor-pointer">
                  <img src={p.image_url!} alt="" className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300" loading="lazy" />
                </div>
              ))}
            </div>
          )
        )}

        {tab === 'about' && (
          <div className="space-y-4">
            {citizen.bio && (
              <Section title="About">
                <p className="text-sm text-unity-muted leading-relaxed">{citizen.bio}</p>
              </Section>
            )}
            {citizen.skills.length > 0 && (
              <Section title="Skills">
                <TagList items={citizen.skills} />
              </Section>
            )}
            {citizen.education && (
              <Section title="Education">
                <p className="text-sm text-unity-muted">{citizen.education}</p>
              </Section>
            )}
            {citizen.achievements.length > 0 && (
              <Section title="Achievements">
                <TagList items={citizen.achievements} />
              </Section>
            )}
            {citizen.interests.length > 0 && (
              <Section title="Interests">
                <TagList items={citizen.interests} />
              </Section>
            )}
            {citizen.languages.length > 0 && (
              <Section title="Languages">
                <TagList items={citizen.languages} />
              </Section>
            )}
            {citizen.portfolio_links.length > 0 && (
              <Section title="Portfolio">
                <div className="space-y-2">
                  {citizen.portfolio_links.map((link, i) => (
                    <a key={i} href={link} target="_blank" rel="noreferrer" className="block text-sm text-unity-primary hover:underline truncate">
                      {link}
                    </a>
                  ))}
                </div>
              </Section>
            )}
          </div>
        )}

        {tab === 'followers' && (
          followerList.length === 0 ? (
            <EmptyState icon={<UsersIcon size={32} />} text="No followers yet." />
          ) : (
            <div className="space-y-2">
              {followerList.map((c) => (
                <button key={c.id} onClick={() => onOpenProfile?.(c)} className="w-full flex items-center gap-3 p-3 rounded-xl glass-panel hover:bg-unity-surface-strong transition-all text-left">
                  <Avatar src={c.avatar_url} name={c.name} size={40} verified={c.verified} />
                  <div className="flex-1 min-w-0">
                    <div className="font-medium text-sm truncate">{c.name}</div>
                    <div className="text-xs text-unity-faint truncate">@{c.handle}</div>
                  </div>
                  <ArrowRightIcon size={16} className="text-unity-faint shrink-0" />
                </button>
              ))}
            </div>
          )
        )}

        {tab === 'following' && (
          followingList.length === 0 ? (
            <EmptyState icon={<UserCheckIcon size={32} />} text="Not following anyone yet." />
          ) : (
            <div className="space-y-2">
              {followingList.map((c) => (
                <button key={c.id} onClick={() => onOpenProfile?.(c)} className="w-full flex items-center gap-3 p-3 rounded-xl glass-panel hover:bg-unity-surface-strong transition-all text-left">
                  <Avatar src={c.avatar_url} name={c.name} size={40} verified={c.verified} />
                  <div className="flex-1 min-w-0">
                    <div className="font-medium text-sm truncate">{c.name}</div>
                    <div className="text-xs text-unity-faint truncate">@{c.handle}</div>
                  </div>
                  <ArrowRightIcon size={16} className="text-unity-faint shrink-0" />
                </button>
              ))}
            </div>
          )
        )}

        {tab === 'stats' && (
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-3">
              <StatCard label="Total Posts" value={posts.length} icon={<FileIcon size={16} />} />
              <StatCard label="Media Posts" value={mediaPosts.length} icon={<ImageIcon2 size={16} />} />
              <StatCard label="Followers" value={followers} icon={<UsersIcon size={16} />} />
              <StatCard label="Following" value={followingCount} icon={<UserCheckIcon size={16} />} />
              <StatCard label="Skills" value={citizen.skills.length} icon={<GlobeIcon size={12} />} />
              <StatCard label="Achievements" value={citizen.achievements.length} icon={<ShieldIcon size={16} />} />
            </div>

            {/* QR Code */}
            <Section title="Citizen QR Code">
              <div className="flex flex-col items-center gap-3 py-4">
                <QRPattern citizenId={citizen.id} />
                <p className="text-xs text-unity-faint text-center max-w-xs">
                  Scan to view this citizen's profile. ID: {citizen.id.slice(0, 8).toUpperCase()}
                </p>
              </div>
            </Section>

            {/* Activity summary */}
            <Section title="Recent Activity">
              <div className="space-y-2">
                {posts.slice(0, 5).map((p) => (
                  <div key={p.id} className="glass-panel rounded-xl p-3">
                    <div className="flex items-center gap-2 text-xs text-unity-faint mb-1">
                      <FileIcon size={12} />
                      <span>{timeAgo(p.created_at)}</span>
                      {p.featured && <span className="text-amber-400/80 flex items-center gap-0.5"><PinIcon size={10} /> Featured</span>}
                      {p.edited_at && <span className="italic">edited</span>}
                    </div>
                    <p className="text-sm text-unity-muted line-clamp-2">{p.content}</p>
                    <div className="flex items-center gap-4 mt-2 text-xs text-unity-faint">
                      <span>{formatNumber(p.likes_count)} likes</span>
                      <span>{formatNumber(p.comments_count)} comments</span>
                    </div>
                  </div>
                ))}
                {posts.length === 0 && <p className="text-sm text-unity-faint text-center py-4">No recent activity.</p>}
              </div>
            </Section>
          </div>
        )}
      </div>

      {reporting && (
        <ReportModal targetType="profile" targetId={citizenId} onClose={() => setReporting(false)} />
      )}
    </div>
  );
}

async function fetchFollowCounts(citizenId: string): Promise<{ followers: number; following: number }> {
  const { data: citizen } = await supabase.from('citizens').select('user_id').eq('id', citizenId).maybeSingle();
  if (!citizen?.user_id) return { followers: 0, following: 0 };
  const [f, fo] = await Promise.all([
    supabase.from('follows').select('follower_id', { count: 'exact', head: true }).eq('following_id', citizen.user_id),
    supabase.from('follows').select('following_id', { count: 'exact', head: true }).eq('follower_id', citizen.user_id),
  ]);
  return { followers: f.count ?? 0, following: fo.count ?? 0 };
}

function StatBox({ label, value }: { label: string; value: number }) {
  return (
    <div className="glass-panel rounded-xl p-3 text-center">
      <div className="text-lg font-semibold tabular-nums">{formatNumber(value)}</div>
      <div className="text-[10px] text-unity-faint uppercase tracking-wide mt-0.5">{label}</div>
    </div>
  );
}

function InfoPill({ icon, label }: { icon: React.ReactNode; label: string }) {
  return (
    <span className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full glass-panel text-xs text-unity-muted">
      {icon} {label}
    </span>
  );
}

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div className="glass-panel rounded-2xl p-5">
      <h3 className="text-xs text-unity-faint uppercase tracking-wide mb-3">{title}</h3>
      {children}
    </div>
  );
}

function TagList({ items }: { items: string[] }) {
  return (
    <div className="flex flex-wrap gap-2">
      {items.map((i, idx) => (
        <span key={idx} className="px-3 py-1 rounded-full bg-unity-surface text-xs text-unity-muted border border-unity-border">{i}</span>
      ))}
    </div>
  );
}

function StatCard({ label, value, icon }: { label: string; value: number; icon: React.ReactNode }) {
  return (
    <div className="glass-panel rounded-xl p-4">
      <div className="flex items-center gap-2 text-unity-muted mb-2">
        {icon}
        <span className="text-[10px] tracking-wide uppercase">{label}</span>
      </div>
      <div className="text-xl font-semibold tabular-nums">{formatNumber(value)}</div>
    </div>
  );
}

function EmptyState({ icon, text }: { icon: React.ReactNode; text: string }) {
  return (
    <div className="glass-panel rounded-2xl p-12 text-center">
      <div className="text-unity-faint mx-auto mb-3 flex justify-center">{icon}</div>
      <p className="text-unity-muted text-sm">{text}</p>
    </div>
  );
}

function QRPattern({ citizenId }: { citizenId: string }) {
  const cells = 21;
  let hash = 0;
  for (let i = 0; i < citizenId.length; i++) {
    hash = ((hash << 5) - hash + citizenId.charCodeAt(i)) | 0;
  }
  const grid: boolean[] = [];
  for (let i = 0; i < cells * cells; i++) {
    hash = (hash * 1103515245 + 12345) & 0x7fffffff;
    grid.push((hash >> 16) % 2 === 0);
  }
  const isFinder = (r: number, c: number) => {
    const inBox = (br: number, bc: number) => r >= br && r < br + 7 && c >= bc && c < bc + 7;
    return inBox(0, 0) || inBox(0, cells - 7) || inBox(cells - 7, 0);
  };
  const isFinderDark = (r: number, c: number) => {
    const inRing = (br: number, bc: number) => {
      const lr = r - br, lc = c - bc;
      if (lr < 0 || lr > 6 || lc < 0 || lc > 6) return false;
      if (lr === 0 || lr === 6 || lc === 0 || lc === 6) return true;
      if (lr >= 2 && lr <= 4 && lc >= 2 && lc <= 4) return true;
      return false;
    };
    return inRing(0, 0) || inRing(0, cells - 7) || inRing(cells - 7, 0);
  };

  return (
    <div className="p-3 bg-white rounded-xl">
      <div
        className="grid gap-0"
        style={{ gridTemplateColumns: `repeat(${cells}, 1fr)`, width: 168, height: 168 }}
      >
        {Array.from({ length: cells * cells }, (_, i) => {
          const r = Math.floor(i / cells);
          const c = i % cells;
          const dark = isFinder(r, c) ? isFinderDark(r, c) : grid[i];
          return <div key={i} className={dark ? 'bg-black' : 'bg-white'} />;
        })}
      </div>
    </div>
  );
}
