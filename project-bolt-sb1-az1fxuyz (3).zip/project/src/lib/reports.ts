import { supabase } from '@/lib/supabase';
import type { Report, ReportTarget, ReportStatus } from '@/types';

export async function createReport(
  targetType: ReportTarget,
  targetId: string,
  reason: string
): Promise<void> {
  const { error } = await supabase.from('reports').insert({
    target_type: targetType,
    target_id: targetId,
    reason: reason.trim(),
  });
  if (error) throw error;
}

export async function fetchReports(limit = 50): Promise<Report[]> {
  const { data, error } = await supabase
    .from('reports')
    .select('id, reporter_id, target_type, target_id, reason, status, created_at')
    .order('created_at', { ascending: false })
    .limit(limit);
  if (error) throw error;
  return (data ?? []) as unknown as Report[];
}

export async function fetchReportsByStatus(status: ReportStatus): Promise<Report[]> {
  const { data, error } = await supabase
    .from('reports')
    .select('id, reporter_id, target_type, target_id, reason, status, created_at')
    .eq('status', status)
    .order('created_at', { ascending: false })
    .limit(50);
  if (error) throw error;
  return (data ?? []) as unknown as Report[];
}

export async function updateReportStatus(id: string, status: ReportStatus): Promise<void> {
  const { error } = await supabase.from('reports').update({ status }).eq('id', id);
  if (error) throw error;
}

export async function resolveReportAndDeleteContent(id: string, targetType: ReportTarget, targetId: string): Promise<void> {
  const table = targetType === 'post' ? 'posts' : targetType === 'comment' ? 'comments' : null;
  if (table) {
    const { error: delErr } = await supabase.from(table).delete().eq('id', targetId);
    if (delErr) throw delErr;
  }
  const { error } = await supabase.from('reports').update({ status: 'resolved' }).eq('id', id);
  if (error) throw error;
}

export function subscribeToReports(callback: () => void): () => void {
  const ch = supabase
    .channel('reports-changes')
    .on('postgres_changes', { event: '*', schema: 'public', table: 'reports' }, () => callback())
    .subscribe();
  return () => { supabase.removeChannel(ch); };
}
