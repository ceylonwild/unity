import { useEffect, useState } from 'react';

const STORAGE_KEY = 'unity-settings';
const EVENT = 'unity-settings-change';

type ThemeMode = 'dark' | 'light' | 'contrast';

interface Settings {
  theme: ThemeMode;
  starfield: boolean;
  reduceMotion: boolean;
  highContrast: boolean;
}

function read(): Settings {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) {
      const p = JSON.parse(raw);
      return {
        theme: p.theme ?? 'dark',
        starfield: p.starfield ?? true,
        reduceMotion: p.reduceMotion ?? false,
        highContrast: p.highContrast ?? false,
      };
    }
  } catch { /* ignore */ }
  return { theme: 'dark', starfield: true, reduceMotion: false, highContrast: false };
}

export function useSettings() {
  const [settings, setSettings] = useState<Settings>(read);
  useEffect(() => {
    const handler = () => setSettings(read());
    window.addEventListener(EVENT, handler);
    window.addEventListener('storage', handler);
    return () => {
      window.removeEventListener(EVENT, handler);
      window.removeEventListener('storage', handler);
    };
  }, []);
  return settings;
}

export function notifySettingsChange() {
  window.dispatchEvent(new Event(EVENT));
}

export function saveSettings(patch: Partial<Settings>) {
  try {
    const current = read();
    const next = { ...current, ...patch };
    localStorage.setItem(STORAGE_KEY, JSON.stringify(next));
    notifySettingsChange();
  } catch { /* ignore quota errors */ }
}

export type { ThemeMode };
