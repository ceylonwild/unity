import { supabase } from '@/lib/supabase';
import type { Post, Comment, Citizen, ReportTarget, ReportStatus, AppNotification, NotificationType } from '@/types';
import { createLikeNotification, createCommentNotification, createFollowNotification } from '@/lib/notifications';

/* ------------------------------------------------------------------ *
 * UNITY data layer — Supabase-backed global social network.
 * Authenticated multi-user. Realtime-capable.
 * ------------------------------------------------------------------ */

// ---- Citizens --------------------------------------------------------

interface RawCitizen extends Omit<Citizen, 'is_admin' | 'role' | 'last_announcement_seen'> {
  is_admin: boolean | null;
  role: string | null;
  last_announcement_seen: string | null;
}

function mapCitizen(c: RawCitizen): Citizen {
  const role = c.role ?? (c.is_admin ? 'admin' : 'citizen');
  return {
    ...c,
    is_admin: c.is_admin ?? false,
    role: role as Citizen['role'],
    last_announcement_seen: c.last_announcement_seen ?? null,
  };
}

export async function fetchCitizenById(id: string): Promise<Citizen | null> {
  const { data, error } = await supabase
    .from('citizens')
    .select('*')
    .eq('id', id)
    .maybeSingle();
  if (error) throw error;
  return data ? mapCitizen(data as RawCitizen) : null;
}

export async function fetchCitizenByUserId(userId: string): Promise<Citizen | null> {
  const { data, error } = await supabase
    .from('citizens')
    .select('*')
    .eq('user_id', userId)
    .maybeSingle();
  if (error) throw error;
  return data ? mapCitizen(data as RawCitizen) : null;
}

export async function fetchCitizenByHandle(handle: string): Promise<Citizen | null> {
  const { data, error } = await supabase
    .from('citizens')
    .select('*')
    .eq('handle', handle.toLowerCase())
    .maybeSingle();
  if (error) throw error;
  return data ? mapCitizen(data as RawCitizen) : null;
}

export async function isHandleTaken(handle: string): Promise<boolean> {
  const { data, error } = await supabase
    .from('citizens')
    .select('id')
    .eq('handle', handle.toLowerCase())
    .maybeSingle();
  if (error) return false;
  return Boolean(data);
}

interface CitizenInput {
  email: string;
  name: string;
  handle: string;
  country: string;
  country_code: string;
  language: string;
  bio: string;
  skills: string[];
  education: string;
  interests: string[];
}

export async function createCitizenForUser(
  userId: string,
  input: CitizenInput
): Promise<Citizen> {
  const row = {
    user_id: userId,
    name: input.name,
    handle: input.handle.toLowerCase().replace(/[^a-z0-9_]/g, ''),
    country: input.country,
    country_code: input.country_code,
    language: input.language,
    bio: input.bio,
    skills: input.skills,
    education: input.education,
    interests: input.interests,
    languages: [input.language],
    avatar_url: null,
    banner_url: null,
  };
  const { data, error } = await supabase
    .from('citizens')
    .insert(row)
    .select('*')
    .single();
  if (error) throw error;
  return mapCitizen(data as RawCitizen);
}

export async function updateCitizen(
  citizenId: string,
  patch: Partial<Citizen>
): Promise<void> {
  const { error } = await supabase.from('citizens').update(patch).eq('id', citizenId);
  if (error) throw error;
}

// ---- Posts -----------------------------------------------------------

interface RawPost {
  id: string;
  content: string;
  image_url: string | null;
  likes_count: number;
  comments_count: number;
  saves_count: number;
  featured: boolean | null;
  edited_at: string | null;
  created_at: string;
  author: {
    id: string;
    name: string;
    handle: string;
    avatar_url: string | null;
    verified: boolean;
    is_admin: boolean | null;
  } | null;
}

function mapPost(p: RawPost, likedIds: Set<string>, savedIds: Set<string>): Post {
  return {
    id: p.id,
    author_id: p.author?.id ?? '',
    author_name: p.author?.name ?? 'Unknown Citizen',
    author_handle: p.author?.handle ?? 'unknown',
    author_avatar: p.author?.avatar_url ?? null,
    author_verified: p.author?.verified ?? false,
    author_is_admin: p.author?.is_admin ?? false,
    content: p.content,
    image_url: p.image_url,
    likes_count: p.likes_count,
    comments_count: p.comments_count,
    saves_count: p.saves_count,
    liked_by_me: likedIds.has(p.id),
    saved_by_me: savedIds.has(p.id),
    featured: p.featured ?? false,
    edited_at: p.edited_at,
    created_at: p.created_at,
  };
}

async function loadLikeSaveSets(): Promise<{ liked: Set<string>; saved: Set<string> }> {
  const [likes, saves] = await Promise.all([
    supabase.from('post_likes').select('post_id'),
    supabase.from('post_saves').select('post_id'),
  ]);
  return {
    liked: new Set((likes.data ?? []).map((r: { post_id: string }) => r.post_id)),
    saved: new Set((saves.data ?? []).map((r: { post_id: string }) => r.post_id)),
  };
}

export async function fetchPosts(): Promise<Post[]> {
  const { data: posts, error } = await supabase
    .from('posts')
    .select(
      `id, content, image_url, likes_count, comments_count, saves_count, featured, edited_at, created_at,
       author:citizens!posts_author_id_fkey ( id, name, handle, avatar_url, verified, is_admin )`
    )
    .order('created_at', { ascending: false })
    .limit(50);
  if (error) throw error;
  if (!posts || posts.length === 0) return [];
  const { liked, saved } = await loadLikeSaveSets();
  return (posts as unknown as RawPost[]).map((p) => mapPost(p, liked, saved));
}

export async function fetchPostsByAuthor(authorId: string, limit = 30): Promise<Post[]> {
  const { data: posts, error } = await supabase
    .from('posts')
    .select(
      `id, content, image_url, likes_count, comments_count, saves_count, featured, edited_at, created_at,
       author:citizens!posts_author_id_fkey ( id, name, handle, avatar_url, verified, is_admin )`
    )
    .eq('author_id', authorId)
    .order('created_at', { ascending: false })
    .limit(limit);
  if (error) throw error;
  if (!posts || posts.length === 0) return [];
  const { liked, saved } = await loadLikeSaveSets();
  return (posts as unknown as RawPost[]).map((p) => mapPost(p, liked, saved));
}

export async function createPost(authorId: string, content: string, imageUrl: string | null): Promise<void> {
  const { error } = await supabase
    .from('posts')
    .insert({ author_id: authorId, content, image_url: imageUrl });
  if (error) throw error;
}

export async function uploadVideoToStorage(file: File): Promise<string> {
  const ext = file.name.split('.').pop()?.toLowerCase() ?? 'mp4';
  const path = `posts/${crypto.randomUUID()}.${ext}`;
  const { error } = await supabase.storage.from('media').upload(path, file, {
    cacheControl: '3600',
    contentType: file.type || 'video/mp4',
  });
  if (error) throw error;
  return supabase.storage.from('media').getPublicUrl(path).data.publicUrl;
}

export async function uploadImageToStorage(file: File): Promise<string> {
  const ext = file.name.split('.').pop()?.toLowerCase() ?? 'jpeg';
  const path = `posts/${crypto.randomUUID()}.${ext}`;
  const { error } = await supabase.storage.from('media').upload(path, file, {
    cacheControl: '3600',
    contentType: file.type || 'image/jpeg',
  });
  if (error) throw error;
  return supabase.storage.from('media').getPublicUrl(path).data.publicUrl;
}

export async function deletePost(postId: string): Promise<void> {
  const { error } = await supabase.from('posts').delete().eq('id', postId);
  if (error) throw error;
}

export async function updatePost(postId: string, content: string): Promise<void> {
  const { error } = await supabase.from('posts').update({ content, edited_at: new Date().toISOString() }).eq('id', postId);
  if (error) throw error;
}

export async function togglePostFeatured(postId: string, currentlyFeatured: boolean): Promise<boolean> {
  const next = !currentlyFeatured;
  const { error } = await supabase.from('posts').update({ featured: next }).eq('id', postId);
  if (error) throw error;
  return next;
}

export async function searchPosts(query: string): Promise<Post[]> {
  const q = query.trim();
  if (!q) return [];
  const { data: posts, error } = await supabase
    .from('posts')
    .select(
      `id, content, image_url, likes_count, comments_count, saves_count, featured, edited_at, created_at,
       author:citizens!posts_author_id_fkey ( id, name, handle, avatar_url, verified, is_admin )`
    )
    .ilike('content', `%${q}%`)
    .order('created_at', { ascending: false })
    .limit(20);
  if (error) throw error;
  if (!posts || posts.length === 0) return [];
  const { liked, saved } = await loadLikeSaveSets();
  return (posts as unknown as RawPost[]).map((p) => mapPost(p, liked, saved));
}

// ---- Likes & Saves (join tables) -------------------------------------

export async function togglePostLike(post: Post): Promise<{ liked: boolean; count: number }> {
  if (post.liked_by_me) {
    const { error } = await supabase
      .from('post_likes')
      .delete()
      .eq('post_id', post.id)
      .eq('user_id', (await currentUserId()) as string);
    if (error) throw error;
    return { liked: false, count: Math.max(0, post.likes_count - 1) };
  }
  const { error } = await supabase.from('post_likes').insert({ post_id: post.id });
  if (error) throw error;
  void notifyPostLiked(post);
  return { liked: true, count: post.likes_count + 1 };
}

async function notifyPostLiked(post: Post): Promise<void> {
  try {
    const { data: postData } = await supabase
      .from('posts')
      .select('author_id')
      .eq('id', post.id)
      .maybeSingle();
    if (!postData?.author_id) return;
    const { data: author } = await supabase
      .from('citizens')
      .select('user_id, name')
      .eq('id', postData.author_id)
      .maybeSingle();
    if (!author?.user_id) return;
    const actorName = (await fetchCitizenById((await currentUserId()) ?? ''))?.name ?? 'Someone';
    void createLikeNotification(author.user_id, actorName, post.id);
  } catch { /* graceful */ }
}

export async function togglePostSave(post: Post): Promise<{ saved: boolean; count: number }> {
  if (post.saved_by_me) {
    const { error } = await supabase
      .from('post_saves')
      .delete()
      .eq('post_id', post.id)
      .eq('user_id', (await currentUserId()) as string);
    if (error) throw error;
    return { saved: false, count: Math.max(0, post.saves_count - 1) };
  }
  const { error } = await supabase.from('post_saves').insert({ post_id: post.id });
  if (error) throw error;
  return { saved: true, count: post.saves_count + 1 };
}

// ---- Comments --------------------------------------------------------

interface RawComment {
  id: string;
  post_id: string;
  content: string;
  created_at: string;
  author: {
    id: string;
    name: string;
    handle: string;
    avatar_url: string | null;
    verified: boolean;
  } | null;
}

export async function fetchComments(postId: string): Promise<Comment[]> {
  const { data, error } = await supabase
    .from('comments')
    .select(
      `id, post_id, content, created_at,
       author:citizens!comments_author_id_fkey ( id, name, handle, avatar_url, verified )`
    )
    .eq('post_id', postId)
    .order('created_at', { ascending: true });
  if (error) throw error;
  if (!data) return [];
  return (data as unknown as RawComment[]).map((c) => ({
    id: c.id,
    post_id: c.post_id,
    author_id: c.author?.id ?? '',
    author_name: c.author?.name ?? 'Citizen',
    author_handle: c.author?.handle ?? 'unknown',
    author_avatar: c.author?.avatar_url ?? null,
    author_verified: c.author?.verified ?? false,
    content: c.content,
    created_at: c.created_at,
  }));
}

export async function addComment(postId: string, authorId: string, content: string): Promise<void> {
  const { error } = await supabase
    .from('comments')
    .insert({ post_id: postId, author_id: authorId, content });
  if (error) throw error;
  void notifyPostCommented(postId, authorId);
}

async function notifyPostCommented(postId: string, authorId: string): Promise<void> {
  try {
    const { data: postData } = await supabase
      .from('posts')
      .select('author_id')
      .eq('id', postId)
      .maybeSingle();
    if (!postData?.author_id || postData.author_id === authorId) return;
    const { data: author } = await supabase
      .from('citizens')
      .select('user_id, name')
      .eq('id', postData.author_id)
      .maybeSingle();
    if (!author?.user_id) return;
    const { data: commenter } = await supabase
      .from('citizens')
      .select('name')
      .eq('id', authorId)
      .maybeSingle();
    void createCommentNotification(author.user_id, commenter?.name ?? 'Someone', postId);
  } catch { /* graceful */ }
}

export async function deleteComment(commentId: string): Promise<void> {
  const { error } = await supabase.from('comments').delete().eq('id', commentId);
  if (error) throw error;
}

// ---- Follows ---------------------------------------------------------

export async function fetchFollowCounts(citizenId: string): Promise<{ followers: number; following: number }> {
  // citizenId is the citizens.id (profile id). follows use auth user ids,
  // so resolve the citizen's user_id first.
  const { data: citizen } = await supabase
    .from('citizens')
    .select('user_id')
    .eq('id', citizenId)
    .maybeSingle();
  if (!citizen?.user_id) return { followers: 0, following: 0 };
  const [f, g] = await Promise.all([
    supabase.from('follows').select('follower_id', { count: 'exact', head: true }).eq('following_id', citizen.user_id),
    supabase.from('follows').select('following_id', { count: 'exact', head: true }).eq('follower_id', citizen.user_id),
  ]);
  return {
    followers: f.count ?? 0,
    following: g.count ?? 0,
  };
}

export async function isFollowing(targetUserId: string): Promise<boolean> {
  const { data } = await supabase
    .from('follows')
    .select('follower_id')
    .eq('following_id', targetUserId)
    .maybeSingle();
  return Boolean(data);
}

export async function isFollowingCitizen(citizenId: string): Promise<boolean> {
  const { data: citizen } = await supabase
    .from('citizens')
    .select('user_id')
    .eq('id', citizenId)
    .maybeSingle();
  if (!citizen?.user_id) return false;
  return isFollowing(citizen.user_id);
}

export async function toggleFollowCitizen(citizenId: string, currentlyFollowing: boolean): Promise<boolean> {
  if (currentlyFollowing) {
    const { data: citizen } = await supabase
      .from('citizens')
      .select('user_id')
      .eq('id', citizenId)
      .maybeSingle();
    if (!citizen?.user_id) throw new Error('Cannot unfollow this citizen');
    const { error } = await supabase.from('follows').delete().eq('following_id', citizen.user_id);
    if (error) throw error;
    return false;
  }
  const { data: citizen } = await supabase
    .from('citizens')
    .select('user_id')
    .eq('id', citizenId)
    .maybeSingle();
  if (!citizen?.user_id) throw new Error('Cannot follow this citizen');
  const { error } = await supabase.from('follows').insert({ following_id: citizen.user_id });
  if (error) throw error;
  void notifyFollowed(citizen.user_id, citizenId);
  return true;
}

async function notifyFollowed(targetUserId: string, followerCitizenId: string): Promise<void> {
  try {
    const { data: follower } = await supabase
      .from('citizens')
      .select('name')
      .eq('id', followerCitizenId)
      .maybeSingle();
    void createFollowNotification(targetUserId, follower?.name ?? 'Someone');
  } catch { /* graceful */ }
}

export async function toggleFollow(targetUserId: string, currentlyFollowing: boolean): Promise<boolean> {
  if (currentlyFollowing) {
    const { error } = await supabase
      .from('follows')
      .delete()
      .eq('following_id', targetUserId);
    if (error) throw error;
    return false;
  }
  const { error } = await supabase.from('follows').insert({ following_id: targetUserId });
  if (error) throw error;
  return true;
}

// ---- Search ----------------------------------------------------------

export async function searchCitizens(query: string): Promise<Citizen[]> {
  const q = query.trim();
  if (!q) return [];

  const isUuid = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(q);
  const filters = isUuid
    ? `name.ilike.%${q}%,handle.ilike.%${q}%,country.ilike.%${q}%,id.eq.${q}`
    : `name.ilike.%${q}%,handle.ilike.%${q}%,country.ilike.%${q}%`;

  const { data, error } = await supabase
    .from('citizens')
    .select('*')
    .or(filters)
    .order('verified', { ascending: false })
    .order('created_at', { ascending: false })
    .limit(20);
  if (error) throw error;
  return (data ?? []).map((c) => mapCitizen(c as RawCitizen));
}

export async function fetchSuggestedCitizens(limit = 5): Promise<Citizen[]> {
  const { data: myFollows } = await supabase
    .from('follows')
    .select('following_id');
  const followingIds = (myFollows ?? []).map((r: { following_id: string }) => r.following_id);

  const myUserId = await currentUserId();
  const { data: myCitizen } = await supabase
    .from('citizens')
    .select('user_id')
    .eq('user_id', myUserId ?? '')
    .maybeSingle();

  let query = supabase
    .from('citizens')
    .select('*')
    .eq('suspended', false)
    .order('verified', { ascending: false })
    .order('created_at', { ascending: false })
    .limit(limit + followingIds.length + 1);

  if (myCitizen?.user_id) {
    query = query.neq('user_id', myCitizen.user_id);
  }

  const { data, error } = await query;
  if (error) return [];
  const filtered = (data ?? [])
    .filter((c: RawCitizen) => !followingIds.includes(c.user_id))
    .slice(0, limit);
  return filtered.map((c) => mapCitizen(c as RawCitizen));
}

// ---- Realtime --------------------------------------------------------

export function subscribeToPosts(callback: () => void): () => void {
  const channel = supabase
    .channel('posts-changes')
    .on('postgres_changes', { event: '*', schema: 'public', table: 'posts' }, () => callback())
    .on('postgres_changes', { event: '*', schema: 'public', table: 'post_likes' }, () => callback())
    .on('postgres_changes', { event: '*', schema: 'public', table: 'post_saves' }, () => callback())
    .on('postgres_changes', { event: '*', schema: 'public', table: 'comments' }, () => callback())
    .subscribe();
  return () => {
    supabase.removeChannel(channel);
  };
}

export function subscribeToComments(postId: string, callback: () => void): () => void {
  const channel = supabase
    .channel(`comments-${postId}`)
    .on(
      'postgres_changes',
      { event: '*', schema: 'public', table: 'comments', filter: `post_id=eq.${postId}` },
      () => callback()
    )
    .subscribe();
  return () => {
    supabase.removeChannel(channel);
  };
}

// ---- Helpers ---------------------------------------------------------

let cachedUserId: string | null = null;
async function currentUserId(): Promise<string | null> {
  if (cachedUserId) return cachedUserId;
  const { data } = await supabase.auth.getUser();
  cachedUserId = data.user?.id ?? null;
  return cachedUserId;
}

export function clearUserIdCache(): void {
  cachedUserId = null;
}
