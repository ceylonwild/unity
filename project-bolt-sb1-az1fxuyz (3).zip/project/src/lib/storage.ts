import { supabase } from '@/lib/supabase';

const BUCKET = 'citizen-media';

/** Upload an image File to the citizen-media bucket under the user's own path.
 *  Returns the public URL. Throws on error. */
export async function uploadCitizenMedia(
  file: File,
  userId: string,
  kind: 'avatar' | 'banner'
): Promise<string> {
  const ext = (file.name.split('.').pop() || 'jpg').toLowerCase();
  const path = `${userId}/${kind}-${Date.now()}.${ext}`;
  const { error } = await supabase.storage.from(BUCKET).upload(path, file, {
    cacheControl: '3600',
    upsert: true,
    contentType: file.type || 'image/jpeg',
  });
  if (error) throw error;
  const { data } = supabase.storage.from(BUCKET).getPublicUrl(path);
  return data.publicUrl;
}
