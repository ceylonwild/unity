import { supabase } from '@/lib/supabase';
import type { AppNotification, NotificationType } from '@/types';

export async function fetchNotifications(limit = 30): Promise<AppNotification[]> {
  const { data, error } = await supabase
    .from('notifications')
    .select('id, user_id, actor_id, type, entity_id, entity_type, message, read, created_at')
    .order('created_at', { ascending: false })
    .limit(limit);
  if (error) throw error;
  return (data ?? []) as unknown as AppNotification[];
}

export async function fetchUnreadCount(): Promise<number> {
  const { count, error } = await supabase
    .from('notifications')
    .select('id', { count: 'exact', head: true })
    .eq('read', false);
  if (error) return 0;
  return count ?? 0;
}

export async function markNotificationRead(id: string): Promise<void> {
  const { error } = await supabase.from('notifications').update({ read: true }).eq('id', id);
  if (error) throw error;
}

export async function markAllNotificationsRead(): Promise<void> {
  const { error } = await supabase.from('notifications').update({ read: true }).eq('read', false);
  if (error) throw error;
}

export async function deleteNotification(id: string): Promise<void> {
  const { error } = await supabase.from('notifications').delete().eq('id', id);
  if (error) throw error;
}

export async function createVerificationNotification(userId: string, verified: boolean): Promise<void> {
  const { error } = await supabase.from('notifications').insert({
    user_id: userId,
    type: 'verification' as NotificationType,
    entity_type: 'user',
    message: verified ? 'Your account has been verified.' : 'Your verification has been removed.',
  });
  if (error) throw error;
}

async function shouldNotify(userId: string, pref: keyof NotificationPreferences): Promise<boolean> {
  try {
    const prefs = await fetchNotificationPreferencesForUser(userId);
    if (!prefs.push_enabled) return false;
    return prefs[pref];
  } catch { return true; }
}

export async function createLikeNotification(postAuthorUserId: string, actorName: string, postId: string): Promise<void> {
  const actorId = await currentAuthUserId();
  if (postAuthorUserId === actorId) return;
  if (!(await shouldNotify(postAuthorUserId, 'likes'))) return;
  const { error } = await supabase.from('notifications').insert({
    user_id: postAuthorUserId,
    actor_id: actorId,
    type: 'like' as NotificationType,
    entity_id: postId,
    entity_type: 'post',
    message: `${actorName} liked your post.`,
  });
  if (error) throw error;
}

export async function createCommentNotification(postAuthorUserId: string, actorName: string, postId: string): Promise<void> {
  const actorId = await currentAuthUserId();
  if (postAuthorUserId === actorId) return;
  if (!(await shouldNotify(postAuthorUserId, 'comments'))) return;
  const { error } = await supabase.from('notifications').insert({
    user_id: postAuthorUserId,
    actor_id: actorId,
    type: 'comment' as NotificationType,
    entity_id: postId,
    entity_type: 'post',
    message: `${actorName} commented on your post.`,
  });
  if (error) throw error;
}

export async function createFollowNotification(targetUserId: string, actorName: string): Promise<void> {
  const actorId = await currentAuthUserId();
  if (!(await shouldNotify(targetUserId, 'followers'))) return;
  const { error } = await supabase.from('notifications').insert({
    user_id: targetUserId,
    actor_id: actorId,
    type: 'follow' as NotificationType,
    entity_type: 'user',
    message: `${actorName} started following you.`,
  });
  if (error) throw error;
}

export async function createAnnouncementNotifications(actorName: string): Promise<void> {
  const { data: citizens, error } = await supabase
    .from('citizens')
    .select('user_id')
    .eq('suspended', false);
  if (error || !citizens) return;
  const actorId = await currentAuthUserId();
  const recipients = citizens.filter((c: { user_id: string }) => c.user_id);
  const rows: Record<string, unknown>[] = [];
  for (const c of recipients) {
    const allow = await shouldNotify(c.user_id, 'announcements');
    if (!allow) continue;
    rows.push({
      user_id: c.user_id,
      actor_id: actorId,
      type: 'announcement' as NotificationType,
      entity_type: 'platform',
      message: `New announcement from ${actorName}.`,
    });
  }
  if (rows.length === 0) return;
  const { error: insErr } = await supabase.from('notifications').insert(rows);
  if (insErr) throw insErr;
}

async function currentAuthUserId(): Promise<string | null> {
  const { data } = await supabase.auth.getUser();
  return data.user?.id ?? null;
}

export interface NotificationPreferences {
  followers: boolean;
  comments: boolean;
  likes: boolean;
  governance: boolean;
  orion: boolean;
  missions: boolean;
  announcements: boolean;
  push_enabled: boolean;
  email_enabled: boolean;
}

const DEFAULT_PREFS: NotificationPreferences = {
  followers: true,
  comments: true,
  likes: true,
  governance: false,
  orion: true,
  missions: false,
  announcements: true,
  push_enabled: true,
  email_enabled: false,
};

export async function fetchNotificationPreferences(): Promise<NotificationPreferences> {
  const { data, error } = await supabase
    .from('notification_preferences')
    .select('*')
    .maybeSingle();
  if (error) return DEFAULT_PREFS;
  if (!data) return DEFAULT_PREFS;
  return normalizePrefs(data);
}

async function fetchNotificationPreferencesForUser(userId: string): Promise<NotificationPreferences> {
  const { data, error } = await supabase
    .from('notification_preferences')
    .select('*')
    .eq('user_id', userId)
    .maybeSingle();
  if (error || !data) return DEFAULT_PREFS;
  return normalizePrefs(data);
}

function normalizePrefs(data: Record<string, unknown>): NotificationPreferences {
  return {
    followers: data.followers ?? true,
    comments: data.comments ?? true,
    likes: data.likes ?? true,
    governance: data.governance ?? false,
    orion: data.orion ?? true,
    missions: data.missions ?? false,
    announcements: data.announcements ?? true,
    push_enabled: data.push_enabled ?? true,
    email_enabled: data.email_enabled ?? false,
  };
}

export async function saveNotificationPreferences(prefs: Partial<NotificationPreferences>): Promise<void> {
  const { data: userData } = await supabase.auth.getUser();
  const userId = userData.user?.id;
  if (!userId) throw new Error('Not authenticated');
  const { error } = await supabase
    .from('notification_preferences')
    .upsert({ ...prefs, user_id: userId, updated_at: new Date().toISOString() });
  if (error) throw error;
}

export function subscribeToNotifications(callback: () => void): () => void {
  const ch = supabase
    .channel('notifications-changes')
    .on('postgres_changes', { event: '*', schema: 'public', table: 'notifications' }, () => callback())
    .subscribe();
  return () => { supabase.removeChannel(ch); };
}
