import { supabase } from '@/lib/supabase';

/* ------------------------------------------------------------------ *
 * UNITY Governance & Wallet data layer
 * ------------------------------------------------------------------ */

// ---- Governance -----------------------------------------------------

export interface ProposalRow {
  id: string;
  author_id: string;
  title: string;
  description: string;
  status: string;
  votes_for: number;
  votes_against: number;
  created_at: string;
  author_name?: string;
  author_handle?: string;
  my_vote?: 'for' | 'against' | null;
}

export async function fetchProposals(): Promise<ProposalRow[]> {
  const { data, error } = await supabase
    .from('proposals')
    .select(`id, author_id, title, description, status, votes_for, votes_against, created_at,
             author:citizens!proposals_author_id_fkey(name, handle)`)
    .order('created_at', { ascending: false })
    .limit(50);
  if (error) throw error;
  if (!data) return [];

  const { data: myVotes } = await supabase.from('proposal_votes').select('proposal_id, vote');
  const voteMap = new Map((myVotes ?? []).map((v: { proposal_id: string; vote: 'for' | 'against' }) => [v.proposal_id, v.vote]));

  return (data as unknown as Array<Record<string, unknown>>).map((p) => {
    const author = p.author as { name: string; handle: string } | null;
    return {
      id: p.id as string,
      author_id: p.author_id as string,
      title: p.title as string,
      description: p.description as string,
      status: p.status as string,
      votes_for: p.votes_for as number,
      votes_against: p.votes_against as number,
      created_at: p.created_at as string,
      author_name: author?.name ?? 'Unknown',
      author_handle: author?.handle ?? 'unknown',
      my_vote: voteMap.get(p.id as string) ?? null,
    };
  });
}

export async function createProposal(authorId: string, title: string, description: string): Promise<void> {
  const { error } = await supabase.from('proposals').insert({ author_id: authorId, title, description });
  if (error) throw error;
}

export async function castVote(proposalId: string, vote: 'for' | 'against', _currentVote: 'for' | 'against' | null): Promise<void> {
  const { error } = await supabase.rpc('cast_vote', { p_proposal_id: proposalId, p_vote: vote });
  if (error) throw error;
}

// ---- Wallet ---------------------------------------------------------

export interface WalletTxnRow {
  id: string;
  type: 'credit' | 'debit';
  amount: number;
  counterparty: string;
  description: string;
  created_at: string;
}

export async function fetchWalletTransactions(citizenId: string): Promise<WalletTxnRow[]> {
  const { data, error } = await supabase
    .from('wallet_transactions')
    .select('id, type, amount, counterparty, description, created_at')
    .eq('citizen_id', citizenId)
    .order('created_at', { ascending: false })
    .limit(50);
  if (error) throw error;
  return (data ?? []) as WalletTxnRow[];
}

export async function getWalletBalance(citizenId: string): Promise<number> {
  const { data, error } = await supabase.rpc('get_wallet_balance', { p_citizen_id: citizenId });
  if (error) throw error;
  return (data as number) ?? 0;
}

export async function sendCredits(fromCitizenId: string, toHandle: string, amount: number, note: string): Promise<void> {
  const { data: recipient } = await supabase
    .from('citizens')
    .select('id')
    .eq('handle', toHandle.replace('@', '').toLowerCase())
    .maybeSingle();
  if (!recipient) throw new Error('Recipient not found');

  const { error } = await supabase.rpc('transfer_credits', {
    p_from_id: fromCitizenId,
    p_to_id: (recipient as { id: string }).id,
    p_amount: amount,
    p_note: note || 'Credit transfer',
  });
  if (error) throw error;
}

export async function seedStipend(citizenId: string): Promise<void> {
  const { data: existing } = await supabase
    .from('wallet_transactions')
    .select('id')
    .eq('citizen_id', citizenId)
    .eq('counterparty', 'UNITY Stipend')
    .maybeSingle();
  if (existing) return;
  const { error } = await supabase.from('wallet_transactions').insert({
    citizen_id: citizenId, type: 'credit', amount: 500, counterparty: 'UNITY Stipend', description: 'Welcome citizen stipend',
  });
  if (error) throw error;
}

// ---- Realtime -------------------------------------------------------

export function subscribeToGovernance(callback: () => void): () => void {
  const ch = supabase.channel('gov-changes')
    .on('postgres_changes', { event: '*', schema: 'public', table: 'proposals' }, () => callback())
    .on('postgres_changes', { event: '*', schema: 'public', table: 'proposal_votes' }, () => callback())
    .subscribe();
  return () => { supabase.removeChannel(ch); };
}

export function subscribeToWallet(callback: () => void): () => void {
  const ch = supabase.channel('wallet-changes')
    .on('postgres_changes', { event: '*', schema: 'public', table: 'wallet_transactions' }, () => callback())
    .subscribe();
  return () => { supabase.removeChannel(ch); };
}
