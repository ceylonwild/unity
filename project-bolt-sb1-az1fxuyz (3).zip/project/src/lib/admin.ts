import { supabase } from '@/lib/supabase';
import type { Citizen, UserRole } from '@/types';
import { showToast } from '@/lib/toast';
import { createVerificationNotification, createAnnouncementNotifications } from '@/lib/notifications';

export interface AdminStats {
  totalCitizens: number;
  totalPosts: number;
  totalProposals: number;
  totalVotes: number;
  suspendedUsers: number;
  newToday: number;
  verifiedUsers: number;
  totalReports: number;
  openReports: number;
  activeToday: number;
  newThisWeek: number;
}

export interface AdminUser extends Citizen {
  post_count?: number;
}

export interface AdminPost {
  id: string;
  content: string;
  image_url: string | null;
  featured: boolean;
  edited_at: string | null;
  created_at: string;
  author: { id: string; name: string; handle: string; avatar_url: string | null; verified: boolean } | null;
}

export interface AdminAnnouncement {
  id: string;
  content: string;
  created_at: string;
  author: { name: string; handle: string } | null;
}

export async function fetchAdminStats(): Promise<AdminStats> {
  const [citizens, posts, proposals, votes, reports] = await Promise.all([
    supabase.from('citizens').select('id, suspended, verified, created_at'),
    supabase.from('posts').select('id', { count: 'exact', head: true }),
    supabase.from('proposals').select('id', { count: 'exact', head: true }),
    supabase.from('proposal_votes').select('id', { count: 'exact', head: true }),
    supabase.from('reports').select('id, status'),
  ]);

  const citizenRows = citizens.data ?? [];
  const reportRows = reports.data ?? [];
  const now = new Date();
  const todayStart = new Date(now.getFullYear(), now.getMonth(), now.getDate()).toISOString();
  const weekAgo = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000).toISOString();

  return {
    totalCitizens: citizenRows.length,
    totalPosts: posts.count ?? 0,
    totalProposals: proposals.count ?? 0,
    totalVotes: votes.count ?? 0,
    suspendedUsers: citizenRows.filter((c: { suspended: boolean | null }) => c.suspended).length,
    verifiedUsers: citizenRows.filter((c: { verified: boolean | null }) => c.verified).length,
    newToday: citizenRows.filter((c: { created_at: string }) => c.created_at >= todayStart).length,
    totalReports: reportRows.length,
    openReports: reportRows.filter((r: { status: string }) => r.status === 'open').length,
    activeToday: citizenRows.filter((c: { created_at: string }) => c.created_at >= weekAgo).length,
    newThisWeek: citizenRows.filter((c: { created_at: string }) => c.created_at >= weekAgo).length,
  };
}

export async function fetchAdminUsers(limit = 100): Promise<AdminUser[]> {
  const { data, error } = await supabase
    .from('citizens')
    .select('*')
    .order('created_at', { ascending: false })
    .limit(limit);
  if (error) { showToast('Could not load users', 'error'); return []; }
  const citizens = (data ?? []) as unknown as Citizen[];
  const citizenIds = citizens.map((c) => c.id);
  if (citizenIds.length === 0) return citizens;
  const { data: postCountRows } = await supabase
    .from('posts')
    .select('author_id')
    .in('author_id', citizenIds);
  const countMap = new Map<string, number>();
  for (const row of (postCountRows ?? []) as { author_id: string }[]) {
    countMap.set(row.author_id, (countMap.get(row.author_id) ?? 0) + 1);
  }
  return citizens.map((c) => ({ ...c, post_count: countMap.get(c.id) ?? 0 }));
}

export async function searchAdminUsers(query: string): Promise<AdminUser[]> {
  const q = query.trim();
  if (!q) return fetchAdminUsers();
  const { data, error } = await supabase
    .from('citizens')
    .select('*')
    .or(`name.ilike.%${q}%,handle.ilike.%${q}%,country.ilike.%${q}%`)
    .order('created_at', { ascending: false })
    .limit(50);
  if (error) { showToast('Search failed', 'error'); return []; }
  const citizens = (data ?? []) as unknown as Citizen[];
  const citizenIds = citizens.map((c) => c.id);
  if (citizenIds.length === 0) return citizens;
  const { data: postCountRows } = await supabase
    .from('posts')
    .select('author_id')
    .in('author_id', citizenIds);
  const countMap = new Map<string, number>();
  for (const row of (postCountRows ?? []) as { author_id: string }[]) {
    countMap.set(row.author_id, (countMap.get(row.author_id) ?? 0) + 1);
  }
  return citizens.map((c) => ({ ...c, post_count: countMap.get(c.id) ?? 0 }));
}

export async function updateCitizenByAdmin(citizenId: string, patch: Partial<Citizen>): Promise<void> {
  const allowed: Record<string, unknown> = {};
  if (patch.name !== undefined) allowed.name = patch.name;
  if (patch.handle !== undefined) allowed.handle = patch.handle;
  if (patch.bio !== undefined) allowed.bio = patch.bio;
  if (patch.country !== undefined) allowed.country = patch.country;
  if (patch.avatar_url !== undefined) allowed.avatar_url = patch.avatar_url;
  if (patch.banner_url !== undefined) allowed.banner_url = patch.banner_url;
  if (patch.verified !== undefined) allowed.verified = patch.verified;
  if (patch.suspended !== undefined) allowed.suspended = patch.suspended;
  if (patch.role !== undefined) allowed.role = patch.role;

  const { error } = await supabase.from('citizens').update(allowed).eq('id', citizenId);
  if (error) throw error;

  if (patch.verified !== undefined) {
    const { data: citizen } = await supabase.from('citizens').select('user_id').eq('id', citizenId).maybeSingle();
    if (citizen?.user_id) {
      try { await createVerificationNotification(citizen.user_id, patch.verified); } catch { /* non-critical */ }
    }
  }
}

export async function setCitizenVerified(citizenId: string, verified: boolean): Promise<void> {
  await updateCitizenByAdmin(citizenId, { verified });
  showToast(verified ? 'Citizen verified' : 'Verification removed', 'success');
}

export async function toggleSuspendCitizen(citizenId: string, currentlySuspended: boolean): Promise<boolean> {
  const next = !currentlySuspended;
  await updateCitizenByAdmin(citizenId, { suspended: next });
  showToast(next ? 'Account suspended' : 'Account restored', 'success');
  return next;
}

export async function setCitizenRole(citizenId: string, role: UserRole): Promise<void> {
  await updateCitizenByAdmin(citizenId, { role, is_admin: role === 'admin' });
  showToast(`Role set to ${role}`, 'success');
}

export async function deleteCitizen(citizenId: string): Promise<void> {
  const { data: citizen } = await supabase.from('citizens').select('user_id').eq('id', citizenId).maybeSingle();
  if (citizen?.user_id) {
    const apiUrl = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/delete-citizen`;
    const res = await fetch(apiUrl, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${(await supabase.auth.getSession()).data.session?.access_token ?? ''}`,
        apikey: import.meta.env.VITE_SUPABASE_ANON_KEY,
      },
      body: JSON.stringify({ userId: citizen.user_id, citizenId }),
    });
    if (!res.ok) {
      const body = await res.json().catch(() => ({}));
      throw new Error(body.error || `Delete failed (${res.status})`);
    }
  } else {
    const { error } = await supabase.from('citizens').delete().eq('id', citizenId);
    if (error) throw error;
  }
  showToast('Account deleted', 'success');
}

export async function fetchAdminPosts(limit = 100): Promise<AdminPost[]> {
  const { data, error } = await supabase
    .from('posts')
    .select('id, content, image_url, featured, edited_at, created_at, author:citizens!posts_author_id_fkey(id, name, handle, avatar_url, verified)')
    .order('created_at', { ascending: false })
    .limit(limit);
  if (error) { showToast('Could not load posts', 'error'); return []; }
  return (data ?? []) as unknown as AdminPost[];
}

export async function searchAdminPosts(query: string): Promise<AdminPost[]> {
  const q = query.trim();
  if (!q) return fetchAdminPosts();
  const { data, error } = await supabase
    .from('posts')
    .select('id, content, image_url, featured, edited_at, created_at, author:citizens!posts_author_id_fkey(id, name, handle, avatar_url, verified)')
    .ilike('content', `%${q}%`)
    .order('created_at', { ascending: false })
    .limit(50);
  if (error) return [];
  return (data ?? []) as unknown as AdminPost[];
}

export async function adminEditPost(postId: string, content: string): Promise<void> {
  const { error } = await supabase.from('posts').update({ content, edited_at: new Date().toISOString() }).eq('id', postId);
  if (error) throw error;
}

export async function adminDeletePost(postId: string): Promise<void> {
  const { error } = await supabase.from('posts').delete().eq('id', postId);
  if (error) throw error;
  showToast('Post deleted', 'success');
}

export async function adminToggleFeatured(postId: string, currentlyFeatured: boolean): Promise<boolean> {
  const next = !currentlyFeatured;
  const { error } = await supabase.from('posts').update({ featured: next }).eq('id', postId);
  if (error) throw error;
  showToast(next ? 'Post featured' : 'Post unfeatured', 'success');
  return next;
}

export async function fetchAnnouncements(limit = 20): Promise<AdminAnnouncement[]> {
  const { data, error } = await supabase
    .from('announcements')
    .select('id, content, created_at, author:citizens!announcements_author_id_fkey(name, handle)')
    .order('created_at', { ascending: false })
    .limit(limit);
  if (error) return [];
  return (data ?? []) as unknown as AdminAnnouncement[];
}

export async function createAnnouncement(authorId: string, content: string): Promise<void> {
  const { error } = await supabase.from('announcements').insert({ author_id: authorId, content: content.trim() });
  if (error) throw error;
  showToast('Announcement published', 'success');
  try {
    const { data: author } = await supabase.from('citizens').select('name').eq('id', authorId).maybeSingle();
    void createAnnouncementNotifications(author?.name ?? 'Admin');
  } catch { /* graceful */ }
}

export async function deleteAnnouncement(id: string): Promise<void> {
  const { error } = await supabase.from('announcements').delete().eq('id', id);
  if (error) throw error;
  showToast('Announcement deleted', 'success');
}

export async function adminDeleteComment(commentId: string): Promise<void> {
  const { error } = await supabase.from('comments').delete().eq('id', commentId);
  if (error) throw error;
  showToast('Comment deleted', 'success');
}

export async function fetchAdminComments(postId?: string, limit = 100): Promise<{ id: string; content: string; created_at: string; author_id: string; post_id: string }[]> {
  let query = supabase.from('comments').select('id, content, created_at, author_id, post_id').order('created_at', { ascending: false }).limit(limit);
  if (postId) query = query.eq('post_id', postId);
  const { data, error } = await query;
  if (error) return [];
  return data ?? [];
}

export async function fetchPlatformSettings(): Promise<{ id: number; site_name: string; site_description: string; maintenance_mode: boolean; registration_open: boolean; announcement_banner: string | null } | null> {
  const { data, error } = await supabase.from('platform_settings').select('*').eq('id', 1).maybeSingle();
  if (error) return null;
  return data;
}

export async function updatePlatformSettings(patch: { site_name?: string; site_description?: string; maintenance_mode?: boolean; registration_open?: boolean; announcement_banner?: string | null }): Promise<void> {
  const { error } = await supabase.from('platform_settings').update({ ...patch, updated_at: new Date().toISOString() }).eq('id', 1);
  if (error) throw error;
  showToast('Platform settings updated', 'success');
}

export async function deleteReport(reportId: string): Promise<void> {
  const { error } = await supabase.from('reports').delete().eq('id', reportId);
  if (error) throw error;
  showToast('Report deleted', 'success');
}

export async function dismissReport(reportId: string): Promise<void> {
  const { error } = await supabase.from('reports').update({ status: 'dismissed' }).eq('id', reportId);
  if (error) throw error;
  showToast('Report dismissed', 'success');
}

export async function fetchWeeklyGrowth(): Promise<number[]> {
  const { data, error } = await supabase.from('citizens').select('created_at');
  if (error || !data) return [0, 0, 0, 0, 0, 0, 0];
  const now = new Date();
  const days: number[] = [];
  for (let i = 6; i >= 0; i--) {
    const dayStart = new Date(now.getFullYear(), now.getMonth(), now.getDate() - i);
    const dayEnd = new Date(dayStart.getTime() + 24 * 60 * 60 * 1000);
    days.push(data.filter((c: { created_at: string }) => {
      const d = new Date(c.created_at);
      return d >= dayStart && d < dayEnd;
    }).length);
  }
  return days;
}

export async function fetchAdminFollowStats(citizenId: string): Promise<{ followers: number; following: number }> {
  const { data: citizen } = await supabase.from('citizens').select('user_id').eq('id', citizenId).maybeSingle();
  if (!citizen?.user_id) return { followers: 0, following: 0 };
  const [f, fo] = await Promise.all([
    supabase.from('follows').select('follower_id', { count: 'exact', head: true }).eq('following_id', citizen.user_id),
    supabase.from('follows').select('following_id', { count: 'exact', head: true }).eq('follower_id', citizen.user_id),
  ]);
  return { followers: f.count ?? 0, following: fo.count ?? 0 };
}
