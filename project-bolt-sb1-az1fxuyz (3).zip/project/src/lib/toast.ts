/** Toast notification system — lightweight, global, no deps. */
type ToastKind = 'info' | 'success' | 'error';
interface Toast {
  id: number;
  message: string;
  kind: ToastKind;
}

let listeners: ((toasts: Toast[]) => void)[] = [];
let toasts: Toast[] = [];
let counter = 0;

function emit() {
  for (const l of listeners) l(toasts);
}

export function showToast(message: string, kind: ToastKind = 'info', duration = 2800) {
  const id = ++counter;
  toasts = [...toasts, { id, message, kind }];
  emit();
  setTimeout(() => {
    toasts = toasts.filter((t) => t.id !== id);
    emit();
  }, duration);
}

export function subscribeToToasts(listener: (toasts: Toast[]) => void) {
  listeners = [...listeners, listener];
  return () => {
    listeners = listeners.filter((l) => l !== listener);
  };
}

export function getToasts(): Toast[] {
  return toasts;
}
