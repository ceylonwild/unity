import { createContext, useContext, useEffect, useState, useCallback, useRef, type ReactNode } from 'react';
import type { Session, User } from '@supabase/supabase-js';
import { supabase, isSupabaseConfigured } from '@/lib/supabase';
import type { Citizen } from '@/types';
import { fetchCitizenByUserId, createCitizenForUser, fetchCitizenById, clearUserIdCache } from '@/lib/feed';
import { showToast } from '@/lib/toast';

interface AuthContextValue {
  user: User | null;
  session: Session | null;
  citizen: Citizen | null;
  loading: boolean;
  initializing: boolean;
  isAdmin: boolean;
  signUp: (email: string, password: string, metadata?: Record<string, unknown>) => Promise<{ error: string | null }>;
  signIn: (email: string, password: string) => Promise<{ error: string | null }>;
  signOut: () => Promise<void>;
  refreshCitizen: () => Promise<void>;
  updateCitizenState: (patch: Partial<Citizen>) => void;
}

const AuthContext = createContext<AuthContextValue | null>(null);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [session, setSession] = useState<Session | null>(null);
  const [citizen, setCitizen] = useState<Citizen | null>(null);
  const [loading, setLoading] = useState(true);
  const [initializing, setInitializing] = useState(true);

  // Guards against concurrent duplicate citizen creation (IIFE + onAuthStateChange
  // can both fire for the same user on mount, and StrictMode double-mounts in dev).
  const citizenLoadingRef = useRef<Set<string>>(new Set());

  const loadCitizen = useCallback(async (u: User | null): Promise<Citizen | null> => {
    if (!u) return null;
    // Dedupe: if another in-flight call is already creating/loading this user's
    // citizen, wait for it instead of creating a duplicate row.
    if (citizenLoadingRef.current.has(u.id)) {
      let waited = 0;
      while (citizenLoadingRef.current.has(u.id) && waited < 5000) {
        await new Promise((r) => setTimeout(r, 50));
        waited += 50;
      }
      return fetchCitizenByUserId(u.id);
    }
    citizenLoadingRef.current.add(u.id);
    try {
      let c = await fetchCitizenByUserId(u.id);
      if (!c) {
        // Auth account exists but no profile yet — create the citizen row now.
        const meta = u.user_metadata as Record<string, unknown> | undefined;
        c = await createCitizenForUser(u.id, {
          email: u.email ?? '',
          name: (meta?.name as string) || (u.email?.split('@')[0] ?? 'New Citizen'),
          handle: (meta?.handle as string) || generateHandle(u.email ?? ''),
          country: (meta?.country as string) || 'Global',
          country_code: (meta?.country_code as string) || 'WO',
          language: (meta?.language as string) || 'English',
          bio: (meta?.bio as string) || '',
          skills: (meta?.skills as string[]) || [],
          education: (meta?.education as string) || '',
          interests: (meta?.interests as string[]) || [],
        });
      }
      return c;
    } catch (e) {
      console.error('[UNITY] failed to load citizen', e);
      return null;
    } finally {
      citizenLoadingRef.current.delete(u.id);
    }
  }, []);

  useEffect(() => {
    let mounted = true;
    let sessionLoaded = false;

    // Initial session restore — the session persists across reloads via
    // localStorage, so returning users skip onboarding automatically.
    (async () => {
      if (!isSupabaseConfigured) {
        if (mounted) { setInitializing(false); setLoading(false); }
        return;
      }
      try {
        const { data } = await supabase.auth.getSession();
        if (!mounted) return;
        sessionLoaded = true;
        setSession(data.session ?? null);
        setUser(data.session?.user ?? null);
        if (data.session?.user) {
          const c = await loadCitizen(data.session.user);
          if (!mounted) return;
          setCitizen(c);
        }
      } catch (e) {
        console.error('[UNITY] getSession failed', e);
      } finally {
        if (mounted) { setInitializing(false); setLoading(false); }
      }
    })();

    // onAuthStateChange callback runs synchronously during event processing.
    // Wrap async work in an IIFE to avoid deadlocking the auth listener.
    const { data: sub } = supabase.auth.onAuthStateChange((_event, sess) => {
      (async () => {
        if (!mounted) return;
        setSession(sess);
        setUser(sess?.user ?? null);
        if (sess?.user) {
          const c = await loadCitizen(sess.user);
          if (!mounted) return;
          setCitizen(c);
        } else {
          setCitizen(null);
        }
        setInitializing(false);
        setLoading(false);
      })();
    });

    // Safety net: if neither getSession nor onAuthStateChange resolves within
    // 8 seconds, force the app out of the initializing screen so the user is
    // never stuck on a frozen splash with no recovery path.
    const timeout = setTimeout(() => {
      if (mounted && !sessionLoaded) {
        console.warn('[UNITY] startup timeout — forcing initialization complete');
        setInitializing(false);
        setLoading(false);
      }
    }, 8000);

    return () => {
      mounted = false;
      clearTimeout(timeout);
      sub.subscription.unsubscribe();
    };
  }, [loadCitizen]);

  const signUp = useCallback(
    async (email: string, password: string, metadata?: Record<string, unknown>): Promise<{ error: string | null }> => {
      if (!isSupabaseConfigured) return { error: 'Backend not configured.' };
      const { error } = await supabase.auth.signUp({
        email,
        password,
        options: { data: metadata },
      });
      if (error) return { error: friendlyAuthError(error.message) };
      return { error: null };
    },
    []
  );

  const signIn = useCallback(
    async (email: string, password: string): Promise<{ error: string | null }> => {
      if (!isSupabaseConfigured) return { error: 'Backend not configured.' };
      const { error } = await supabase.auth.signInWithPassword({ email, password });
      if (error) return { error: friendlyAuthError(error.message) };
      return { error: null };
    },
    []
  );

  const signOut = useCallback(async () => {
    try {
      await supabase.auth.signOut();
    } catch (e) {
      console.error('[UNITY] signOut error', e);
    } finally {
      clearUserIdCache();
      setCitizen(null);
      setUser(null);
      setSession(null);
    }
  }, []);

  const refreshCitizen = useCallback(async () => {
    if (!user) return;
    const c = await fetchCitizenByUserId(user.id);
    if (c) setCitizen(c);
  }, [user]);

  const updateCitizenState = useCallback((patch: Partial<Citizen>) => {
    setCitizen((prev) => (prev ? { ...prev, ...patch } : prev));
  }, []);

  const value: AuthContextValue = {
    user,
    session,
    citizen,
    loading,
    initializing,
    isAdmin: citizen?.is_admin ?? false,
    signUp,
    signIn,
    signOut,
    refreshCitizen,
    updateCitizenState,
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used within AuthProvider');
  return ctx;
}

function generateHandle(email: string): string {
  const base = email.split('@')[0]?.replace(/[^a-z0-9_]/gi, '').toLowerCase() || 'citizen';
  const suffix = Math.random().toString(36).slice(2, 6);
  return `${base}_${suffix}`;
}

function friendlyAuthError(msg: string): string {
  const m = msg.toLowerCase();
  if (m.includes('already registered') || m.includes('already been registered'))
    return 'An account with this email already exists.';
  if (m.includes('invalid login') || m.includes('invalid credentials'))
    return 'Incorrect email or password.';
  if (m.includes('email not confirmed')) return 'Email not confirmed yet.';
  if (m.includes('password')) return 'Password must be at least 6 characters.';
  if (m.includes('network') || m.includes('fetch')) return 'Network error. Check your connection.';
  return msg;
}

export { fetchCitizenById };
