import { createContext, useContext, type ReactNode } from 'react';
import { useAuth } from '@/lib/auth';
import type { Citizen } from '@/types';
import { updateCitizen } from '@/lib/feed';

// Backwards-compatible self context backed by the real Supabase auth session.
// Existing views consume useSelf() unchanged; the source of truth is AuthProvider.
interface SelfContextValue {
  self: Citizen | null;
  loading: boolean;
  ready: boolean;
  refresh: () => Promise<void>;
  setAvatar: (avatarUrl: string) => Promise<void>;
  updateSelf: (patch: Partial<Citizen>) => Promise<void>;
  logout: () => void;
}

const SelfContext = createContext<SelfContextValue | null>(null);

export function SelfProvider({ children }: { children: ReactNode }) {
  const { citizen, loading, initializing, refreshCitizen, updateCitizenState, signOut } = useAuth();

  const value: SelfContextValue = {
    self: citizen,
    loading: initializing,
    ready: !initializing && !loading,
    refresh: refreshCitizen,
    setAvatar: async (avatarUrl: string) => {
      if (!citizen) return;
      await updateCitizen(citizen.id, { avatar_url: avatarUrl });
      updateCitizenState({ avatar_url: avatarUrl });
    },
    updateSelf: async (patch: Partial<Citizen>) => {
      if (!citizen) return;
      await updateCitizen(citizen.id, patch);
      updateCitizenState(patch);
    },
    logout: () => { void signOut(); },
  };

  return <SelfContext.Provider value={value}>{children}</SelfContext.Provider>;
}

export function useSelf() {
  const ctx = useContext(SelfContext);
  if (!ctx) throw new Error('useSelf must be used within SelfProvider');
  return ctx;
}
