import { createClient } from 'npm:@supabase/supabase-js@2.57.4';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type, Authorization, X-Client-Info, Apikey',
};

const ADMIN_EMAIL = 'admin@unity.app';
const ADMIN_PASSWORD = 'admin@sansitha2006';

Deno.serve(async (req: Request) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const serviceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const admin = createClient(supabaseUrl, serviceKey, {
      auth: { autoRefreshToken: false, persistSession: false },
    });

    // Check if the admin auth user already exists
    const { data: existingUsers } = await admin.auth.admin.listUsers();
    const existing = existingUsers?.users?.find((u: { email: string }) => u.email === ADMIN_EMAIL);

    let userId: string;

    if (existing) {
      userId = existing.id;
    } else {
      // Create the permanent admin account
      const { data: created, error: createErr } = await admin.auth.admin.createUser({
        email: ADMIN_EMAIL,
        password: ADMIN_PASSWORD,
        email_confirm: true,
        user_metadata: {
          name: 'UNITY Administrator',
          handle: 'admin',
          country: 'Global',
          country_code: 'WO',
          language: 'English',
          is_admin: true,
        },
      });

      if (createErr) throw new Error(`Failed to create admin user: ${createErr.message}`);
      userId = created.user.id;
    }

    // Ensure the citizens row exists and has is_admin = true
    const { data: citizen } = await admin
      .from('citizens')
      .select('id, is_admin')
      .eq('user_id', userId)
      .maybeSingle();

    if (citizen) {
      if (!citizen.is_admin) {
        await admin.from('citizens').update({ is_admin: true }).eq('user_id', userId);
      }
    } else {
      await admin.from('citizens').insert({
        user_id: userId,
        name: 'UNITY Administrator',
        handle: 'admin',
        country: 'Global',
        country_code: 'WO',
        language: 'English',
        bio: 'System administrator for the UNITY civilization layer.',
        is_admin: true,
        verified: true,
      });
    }

    return new Response(
      JSON.stringify({ ok: true, message: 'Admin account provisioned', admin_email: ADMIN_EMAIL }),
      { status: 200, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  } catch (err) {
    return new Response(
      JSON.stringify({ ok: false, error: err instanceof Error ? err.message : 'Unknown error' }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});
