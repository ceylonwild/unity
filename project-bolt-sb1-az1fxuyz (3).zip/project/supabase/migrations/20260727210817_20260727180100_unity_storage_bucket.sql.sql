/*
# UNITY Storage bucket for avatars & banners

1. Purpose
   Creates a public Storage bucket `citizen-media` for profile avatars and
   banners, plus policies so any signed-in user can upload into a path scoped
   by their own user id, and anyone can read (avatars/banners render for all
   citizens in the directory/feed).

2. Storage Objects
   - bucket `citizen-media` (public)

3. Security
   - SELECT (read): public — anyone, including anon, can read media so avatars
     render across the app.
   - INSERT: authenticated users can create objects only under `<own_uid>/`.
   - UPDATE/DELETE: authenticated owners can modify only their own path.
*/

INSERT INTO storage.buckets (id, name, public)
VALUES ('citizen-media', 'citizen-media', true)
ON CONFLICT (id) DO NOTHING;

DROP POLICY IF EXISTS "read_citizen_media" ON storage.objects;
CREATE POLICY "read_citizen_media" ON storage.objects FOR SELECT
  TO anon, authenticated USING (bucket_id = 'citizen-media');

DROP POLICY IF EXISTS "insert_own_citizen_media" ON storage.objects;
CREATE POLICY "insert_own_citizen_media" ON storage.objects FOR INSERT
  TO authenticated WITH CHECK (
    bucket_id = 'citizen-media'
    AND (storage.foldername(name))[1] = auth.uid()::text
  );

DROP POLICY IF EXISTS "update_own_citizen_media" ON storage.objects;
CREATE POLICY "update_own_citizen_media" ON storage.objects FOR UPDATE
  TO authenticated USING (
    bucket_id = 'citizen-media'
    AND (storage.foldername(name))[1] = auth.uid()::text
  );

DROP POLICY IF EXISTS "delete_own_citizen_media" ON storage.objects;
CREATE POLICY "delete_own_citizen_media" ON storage.objects FOR DELETE
  TO authenticated USING (
    bucket_id = 'citizen-media'
    AND (storage.foldername(name))[1] = auth.uid()::text
  );
