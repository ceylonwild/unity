/*
# Communities + Community Members

## Summary
Creates tables for communities and community membership, replacing the hardcoded
community list in the Communication view with real database-backed data.

## 1. New Table: communities
- `id` (uuid, PK)
- `name` (text, NOT NULL, unique) — community name
- `description` (text) — what the community is about
- `icon` (text, nullable) — optional emoji or icon name
- `created_at` (timestamptz, default now())
- RLS: anyone authenticated can read; only admins can insert/update/delete.

## 2. New Table: community_members
- `id` (uuid, PK)
- `community_id` (uuid, NOT NULL, references communities ON DELETE CASCADE)
- `user_id` (uuid, NOT NULL, DEFAULT auth.uid(), references auth.users ON DELETE CASCADE)
- `joined_at` (timestamptz, default now())
- Unique constraint on (community_id, user_id) — one membership per pair.
- RLS: anyone authenticated can read; users can insert/delete their own membership.

## 3. Seed Data
Inserts 4 seed communities matching the previous hardcoded list, so the UI
continues to show communities without manual setup.

## Security
- communities: SELECT for all authenticated; INSERT/UPDATE/DELETE admin-only (via citizens.is_admin check).
- community_members: SELECT for all authenticated; INSERT/DELETE own membership.
*/

CREATE TABLE IF NOT EXISTS communities (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL UNIQUE,
  description text NOT NULL DEFAULT '',
  icon text,
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE communities ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "read_communities" ON communities;
CREATE POLICY "read_communities" ON communities FOR SELECT
  TO authenticated USING (true);

DROP POLICY IF EXISTS "insert_communities" ON communities;
CREATE POLICY "insert_communities" ON communities FOR INSERT
  TO authenticated WITH CHECK (
    EXISTS (SELECT 1 FROM citizens WHERE citizens.user_id = auth.uid() AND citizens.is_admin = true)
  );

DROP POLICY IF EXISTS "update_communities" ON communities;
CREATE POLICY "update_communities" ON communities FOR UPDATE
  TO authenticated USING (
    EXISTS (SELECT 1 FROM citizens WHERE citizens.user_id = auth.uid() AND citizens.is_admin = true)
  );

DROP POLICY IF EXISTS "delete_communities" ON communities;
CREATE POLICY "delete_communities" ON communities FOR DELETE
  TO authenticated USING (
    EXISTS (SELECT 1 FROM citizens WHERE citizens.user_id = auth.uid() AND citizens.is_admin = true)
  );

CREATE TABLE IF NOT EXISTS community_members (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  community_id uuid NOT NULL REFERENCES communities(id) ON DELETE CASCADE,
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  joined_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (community_id, user_id)
);

ALTER TABLE community_members ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "read_community_members" ON community_members;
CREATE POLICY "read_community_members" ON community_members FOR SELECT
  TO authenticated USING (true);

DROP POLICY IF EXISTS "insert_own_membership" ON community_members;
CREATE POLICY "insert_own_membership" ON community_members FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "delete_own_membership" ON community_members;
CREATE POLICY "delete_own_membership" ON community_members FOR DELETE
  TO authenticated USING (auth.uid() = user_id);

-- Seed communities (idempotent — ON CONFLICT DO NOTHING)
INSERT INTO communities (name, description) VALUES
  ('Future of Governance', 'Designing decision systems for planetary civilization'),
  ('Climate Restoration', 'Engineering a stable biosphere within a generation'),
  ('Orbital Economy', 'Building the infrastructure of space civilization'),
  ('Knowledge Commons', 'Open knowledge for every human')
ON CONFLICT (name) DO NOTHING;
