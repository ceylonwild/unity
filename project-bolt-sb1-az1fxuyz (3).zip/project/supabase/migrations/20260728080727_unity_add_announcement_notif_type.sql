/*
# Update notifications type constraint to include 'announcement'

## Summary
The notifications table has a CHECK constraint on the `type` column that restricts
it to: follow, like, comment, reply, verification, admin. This adds 'announcement'
to the allowed values so that announcement notifications can be created.

## Changes
- Drops the existing CHECK constraint on notifications.type
- Creates a new CHECK constraint that includes 'announcement'
- Safe to re-run (DROP IF EXISTS before CREATE)
*/

ALTER TABLE notifications DROP CONSTRAINT IF EXISTS notifications_type_check;

ALTER TABLE notifications ADD CONSTRAINT notifications_type_check
  CHECK (type = ANY (ARRAY['follow'::text, 'like'::text, 'comment'::text, 'reply'::text, 'verification'::text, 'admin'::text, 'announcement'::text]));
