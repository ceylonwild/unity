/*
# UNITY Platform Management Migration

1. Purpose
   Adds the complete admin ecosystem, verified citizen system, notification
   system, report system, and post editing support. This is an additive
   migration — no columns dropped, no tables renamed, no data deleted.

2. Modified Tables
   - `citizens`
     - `role` (text, default 'citizen', CHECK admin|moderator|citizen) —
       role-based access control alongside existing is_admin boolean.
     - `last_announcement_seen` (timestamptz, nullable) — tracks when the
       citizen last viewed announcements for the unread badge counter.
   - `posts`
     - `edited_at` (timestamptz, nullable) — set when a post's content is
       edited; null means the post has never been edited.
     - `featured` (boolean, default false) — admin-curated featured posts.
   - `posts` UPDATE policy — extended to allow admins to edit any post.

3. New Tables
   - `notifications` — per-user notifications (follows, likes, comments,
     replies, verification). Created by SECURITY DEFINER triggers, never
     by client inserts directly.
   - `reports` — user-submitted content reports for posts, profiles, and
     comments. Admin-reviewable with status workflow.
   - `announcements` — platform-wide announcements published by admins.
     Separate from posts; displayed in the notification badge and feed.

4. Triggers
   - `notify_on_follow` — creates a 'follow' notification when a follow edge
     is created (SECURITY DEFINER, deduped).
   - `notify_on_like` — creates a 'like' notification when a post is liked
     (SECURITY DEFINER, deduped, skips self-likes).
   - `notify_on_comment` — creates a 'comment' notification when a comment
     is added to a post (SECURITY DEFINER, skips self-comments).
   - `recount_post_comments` — maintains denormalized comments_count on
     posts from the comments table (race-safe, same pattern as likes/saves).

5. Security (RLS)
   - `notifications`: SELECT/UPDATE/DELETE own only. No INSERT policy —
     only SECURITY DEFINER trigger functions insert rows.
   - `reports`: SELECT own + admin; INSERT own; UPDATE/DELETE admin only.
   - `announcements`: SELECT all authenticated; INSERT/UPDATE/DELETE admin.
   - `posts` UPDATE: extended to allow admin override for moderation.

6. Realtime
   - notifications, announcements added to supabase_realtime publication.

7. Notes
   - Additive only; safe to re-run (idempotent column additions, drop-then-
     create policies, IF NOT EXISTS tables).
   - Existing admins (is_admin = true) are upgraded to role = 'admin'.
   - is_admin boolean is retained for backwards compatibility with existing
     RLS policies; role column is used for finer-grained permissions.
*/

-- ---------------------------------------------------------------------------
-- 1. Column additions: citizens
-- ---------------------------------------------------------------------------
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'citizens' AND column_name = 'role'
  ) THEN
    ALTER TABLE citizens ADD COLUMN role text NOT NULL DEFAULT 'citizen'
      CHECK (role IN ('admin', 'moderator', 'citizen'));
  END IF;
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'citizens' AND column_name = 'last_announcement_seen'
  ) THEN
    ALTER TABLE citizens ADD COLUMN last_announcement_seen timestamptz;
  END IF;
END $$;

-- Promote existing admins to role = 'admin'
UPDATE citizens SET role = 'admin' WHERE is_admin = true AND role = 'citizen';

-- ---------------------------------------------------------------------------
-- 2. Column additions: posts
-- ---------------------------------------------------------------------------
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'posts' AND column_name = 'edited_at'
  ) THEN
    ALTER TABLE posts ADD COLUMN edited_at timestamptz;
  END IF;
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'posts' AND column_name = 'featured'
  ) THEN
    ALTER TABLE posts ADD COLUMN featured boolean NOT NULL DEFAULT false;
  END IF;
END $$;

CREATE INDEX IF NOT EXISTS idx_posts_featured ON posts (featured, created_at DESC);

-- ---------------------------------------------------------------------------
-- 3. Extend posts UPDATE policy to allow admin override
-- ---------------------------------------------------------------------------
DROP POLICY IF EXISTS "update_own_posts" ON posts;
CREATE POLICY "update_own_posts" ON posts FOR UPDATE
  TO authenticated
  USING (
    EXISTS (SELECT 1 FROM citizens c WHERE c.id = author_id AND c.user_id = auth.uid())
    OR EXISTS (SELECT 1 FROM citizens c WHERE c.user_id = auth.uid() AND c.is_admin = true)
  )
  WITH CHECK (
    EXISTS (SELECT 1 FROM citizens c WHERE c.id = author_id AND c.user_id = auth.uid())
    OR EXISTS (SELECT 1 FROM citizens c WHERE c.user_id = auth.uid() AND c.is_admin = true)
  );

-- Also allow admin to insert comments for moderation context (no change needed,
-- but allow comment UPDATE for admin editing — not required by spec, skip).

-- ---------------------------------------------------------------------------
-- 4. New table: notifications
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS notifications (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  actor_id uuid REFERENCES auth.users(id) ON DELETE CASCADE,
  type text NOT NULL CHECK (type IN ('follow', 'like', 'comment', 'reply', 'verification', 'admin')),
  entity_id uuid,
  entity_type text,
  message text NOT NULL DEFAULT '',
  read boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_notifications_user ON notifications (user_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_notifications_unread ON notifications (user_id, read) WHERE read = false;

-- ---------------------------------------------------------------------------
-- 5. New table: reports
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS reports (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  reporter_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  target_type text NOT NULL CHECK (target_type IN ('post', 'profile', 'comment')),
  target_id uuid NOT NULL,
  reason text NOT NULL DEFAULT '',
  status text NOT NULL DEFAULT 'open' CHECK (status IN ('open', 'reviewed', 'resolved', 'dismissed')),
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_reports_status ON reports (status, created_at DESC);

-- ---------------------------------------------------------------------------
-- 6. New table: announcements
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS announcements (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  author_id uuid NOT NULL REFERENCES citizens(id) ON DELETE CASCADE,
  content text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_announcements_created ON announcements (created_at DESC);

-- ---------------------------------------------------------------------------
-- 7. Enable RLS on new tables
-- ---------------------------------------------------------------------------
ALTER TABLE notifications ENABLE ROW LEVEL SECURITY;
ALTER TABLE reports ENABLE ROW LEVEL SECURITY;
ALTER TABLE announcements ENABLE ROW LEVEL SECURITY;

-- ---------------------------------------------------------------------------
-- 8. RLS: notifications (own only — no client INSERT, triggers handle it)
-- ---------------------------------------------------------------------------
DROP POLICY IF EXISTS "select_own_notifications" ON notifications;
CREATE POLICY "select_own_notifications" ON notifications FOR SELECT
  TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "update_own_notifications" ON notifications;
CREATE POLICY "update_own_notifications" ON notifications FOR UPDATE
  TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "delete_own_notifications" ON notifications;
CREATE POLICY "delete_own_notifications" ON notifications FOR DELETE
  TO authenticated USING (auth.uid() = user_id);

-- ---------------------------------------------------------------------------
-- 9. RLS: reports (own + admin)
-- ---------------------------------------------------------------------------
DROP POLICY IF EXISTS "select_reports" ON reports;
CREATE POLICY "select_reports" ON reports FOR SELECT
  TO authenticated USING (
    auth.uid() = reporter_id
    OR EXISTS (SELECT 1 FROM citizens c WHERE c.user_id = auth.uid() AND c.is_admin = true)
  );

DROP POLICY IF EXISTS "insert_own_report" ON reports;
CREATE POLICY "insert_own_report" ON reports FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = reporter_id);

DROP POLICY IF EXISTS "update_reports_admin" ON reports;
CREATE POLICY "update_reports_admin" ON reports FOR UPDATE
  TO authenticated
  USING (EXISTS (SELECT 1 FROM citizens c WHERE c.user_id = auth.uid() AND c.is_admin = true))
  WITH CHECK (EXISTS (SELECT 1 FROM citizens c WHERE c.user_id = auth.uid() AND c.is_admin = true));

DROP POLICY IF EXISTS "delete_reports_admin" ON reports;
CREATE POLICY "delete_reports_admin" ON reports FOR DELETE
  TO authenticated USING (EXISTS (SELECT 1 FROM citizens c WHERE c.user_id = auth.uid() AND c.is_admin = true));

-- ---------------------------------------------------------------------------
-- 10. RLS: announcements (all read, admin write)
-- ---------------------------------------------------------------------------
DROP POLICY IF EXISTS "select_announcements" ON announcements;
CREATE POLICY "select_announcements" ON announcements FOR SELECT
  TO authenticated USING (true);

DROP POLICY IF EXISTS "insert_announcements_admin" ON announcements;
CREATE POLICY "insert_announcements_admin" ON announcements FOR INSERT
  TO authenticated WITH CHECK (EXISTS (SELECT 1 FROM citizens c WHERE c.user_id = auth.uid() AND c.is_admin = true));

DROP POLICY IF EXISTS "update_announcements_admin" ON announcements;
CREATE POLICY "update_announcements_admin" ON announcements FOR UPDATE
  TO authenticated
  USING (EXISTS (SELECT 1 FROM citizens c WHERE c.user_id = auth.uid() AND c.is_admin = true))
  WITH CHECK (EXISTS (SELECT 1 FROM citizens c WHERE c.user_id = auth.uid() AND c.is_admin = true));

DROP POLICY IF EXISTS "delete_announcements_admin" ON announcements;
CREATE POLICY "delete_announcements_admin" ON announcements FOR DELETE
  TO authenticated USING (EXISTS (SELECT 1 FROM citizens c WHERE c.user_id = auth.uid() AND c.is_admin = true));

-- ---------------------------------------------------------------------------
-- 11. Notification trigger functions (SECURITY DEFINER — bypass RLS)
-- ---------------------------------------------------------------------------

-- Follow notification
CREATE OR REPLACE FUNCTION notify_on_follow()
RETURNS trigger AS $$
BEGIN
  INSERT INTO notifications (user_id, actor_id, type, entity_id, entity_type, message)
  SELECT NEW.following_id, NEW.follower_id, 'follow', NEW.follower_id, 'user', ''
  WHERE NOT EXISTS (
    SELECT 1 FROM notifications
    WHERE user_id = NEW.following_id AND actor_id = NEW.follower_id AND type = 'follow'
  );
  RETURN NULL;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

DROP TRIGGER IF EXISTS follows_notify ON follows;
CREATE TRIGGER follows_notify
  AFTER INSERT ON follows
  FOR EACH ROW EXECUTE FUNCTION notify_on_follow();

-- Like notification
CREATE OR REPLACE FUNCTION notify_on_like()
RETURNS trigger AS $$
DECLARE
  post_author_uid uuid;
BEGIN
  SELECT c.user_id INTO post_author_uid
  FROM posts p JOIN citizens c ON c.id = p.author_id
  WHERE p.id = NEW.post_id;

  IF post_author_uid IS NOT NULL AND post_author_uid != NEW.user_id THEN
    INSERT INTO notifications (user_id, actor_id, type, entity_id, entity_type, message)
    SELECT post_author_uid, NEW.user_id, 'like', NEW.post_id, 'post', ''
    WHERE NOT EXISTS (
      SELECT 1 FROM notifications
      WHERE user_id = post_author_uid AND actor_id = NEW.user_id AND type = 'like' AND entity_id = NEW.post_id
    );
  END IF;
  RETURN NULL;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

DROP TRIGGER IF EXISTS post_likes_notify ON post_likes;
CREATE TRIGGER post_likes_notify
  AFTER INSERT ON post_likes
  FOR EACH ROW EXECUTE FUNCTION notify_on_like();

-- Comment notification
CREATE OR REPLACE FUNCTION notify_on_comment()
RETURNS trigger AS $$
DECLARE
  post_author_uid uuid;
  commenter_uid uuid;
BEGIN
  SELECT c.user_id INTO post_author_uid
  FROM posts p JOIN citizens c ON c.id = p.author_id
  WHERE p.id = NEW.post_id;

  SELECT user_id INTO commenter_uid FROM citizens WHERE id = NEW.author_id;

  IF post_author_uid IS NOT NULL AND commenter_uid IS NOT NULL
     AND post_author_uid != commenter_uid THEN
    INSERT INTO notifications (user_id, actor_id, type, entity_id, entity_type, message)
    VALUES (post_author_uid, commenter_uid, 'comment', NEW.post_id, 'post', NEW.content);
  END IF;
  RETURN NULL;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

DROP TRIGGER IF EXISTS comments_notify ON comments;
CREATE TRIGGER comments_notify
  AFTER INSERT ON comments
  FOR EACH ROW EXECUTE FUNCTION notify_on_comment();

-- ---------------------------------------------------------------------------
-- 12. Comments count trigger (maintains denormalized comments_count)
-- ---------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION recount_post_comments()
RETURNS trigger AS $$
BEGIN
  UPDATE posts
  SET comments_count = (SELECT COUNT(*) FROM comments WHERE post_id = COALESCE(NEW.post_id, OLD.post_id))
  WHERE id = COALESCE(NEW.post_id, OLD.post_id);
  RETURN NULL;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS comments_recount ON comments;
CREATE TRIGGER comments_recount
  AFTER INSERT OR DELETE ON comments
  FOR EACH ROW EXECUTE FUNCTION recount_post_comments();

-- One-time recount to fix any drifted counts
UPDATE posts p SET comments_count = (
  SELECT COUNT(*) FROM comments c WHERE c.post_id = p.id
);

-- ---------------------------------------------------------------------------
-- 13. Realtime publication for new tables
-- ---------------------------------------------------------------------------
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_publication_tables
    WHERE pubname = 'supabase_realtime' AND tablename = 'notifications'
  ) THEN
    ALTER PUBLICATION supabase_realtime ADD TABLE notifications;
  END IF;
  IF NOT EXISTS (
    SELECT 1 FROM pg_publication_tables
    WHERE pubname = 'supabase_realtime' AND tablename = 'announcements'
  ) THEN
    ALTER PUBLICATION supabase_realtime ADD TABLE announcements;
  END IF;
  IF NOT EXISTS (
    SELECT 1 FROM pg_publication_tables
    WHERE pubname = 'supabase_realtime' AND tablename = 'reports'
  ) THEN
    ALTER PUBLICATION supabase_realtime ADD TABLE reports;
  END IF;
END $$;
