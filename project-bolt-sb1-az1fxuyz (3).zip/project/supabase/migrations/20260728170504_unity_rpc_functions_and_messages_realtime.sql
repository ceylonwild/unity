/*
# Create RPC functions for wallet transfers, voting, and balance; add messages to realtime

## 1. New RPC Functions
- `transfer_credits(p_from_id, p_to_id, p_amount, p_note)`: Atomically transfers credits
  between two citizens. Checks sender balance >= amount before transferring. Raises errors
  for insufficient balance, self-transfer, or non-positive amounts.
- `cast_vote(p_proposal_id, p_vote)`: Atomically upserts a vote (delete old + insert new)
  and updates proposal vote counts (votes_for / votes_against) in the same transaction.
- `get_wallet_balance(p_citizen_id)`: Returns the sum of all credits minus debits for a
  citizen — replaces the unbounded client-side fetch.

## 2. Realtime
- Adds `messages` table to the `supabase_realtime` publication so direct messages
  can live-update in the Communication module.

## 3. Security
- All three RPCs use `SECURITY DEFINER` so they can operate across rows with a single
  authenticated call. `transfer_credits` and `cast_vote` verify the caller's identity
  via `auth.uid()` before proceeding.
- `get_wallet_balance` is read-only and safe to expose to any authenticated user.
*/

-- =============================================================
-- transfer_credits: atomic debit + credit with balance guard
-- =============================================================
CREATE OR REPLACE FUNCTION transfer_credits(
  p_from_id uuid,
  p_to_id uuid,
  p_amount integer,
  p_note text DEFAULT 'Credit transfer'
)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  v_balance integer;
BEGIN
  IF p_amount <= 0 THEN
    RAISE EXCEPTION 'Amount must be positive';
  END IF;
  IF p_from_id = p_to_id THEN
    RAISE EXCEPTION 'Cannot send credits to yourself';
  END IF;

  SELECT COALESCE(SUM(CASE WHEN type = 'credit' THEN amount ELSE -amount END), 0)
    INTO v_balance
    FROM wallet_transactions
    WHERE citizen_id = p_from_id;

  IF v_balance < p_amount THEN
    RAISE EXCEPTION 'Insufficient balance: you have % credits, tried to send %', v_balance, p_amount;
  END IF;

  INSERT INTO wallet_transactions (citizen_id, type, amount, counterparty, description)
    VALUES (p_from_id, 'debit', p_amount, 'Transfer', p_note);

  INSERT INTO wallet_transactions (citizen_id, type, amount, counterparty, description)
    VALUES (p_to_id, 'credit', p_amount, 'Transfer', p_note);
END;
$$;

-- =============================================================
-- cast_vote: atomic upsert + count maintenance
-- =============================================================
CREATE OR REPLACE FUNCTION cast_vote(
  p_proposal_id uuid,
  p_vote text
)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  v_user_id uuid;
  v_old_vote text;
BEGIN
  v_user_id := auth.uid();
  IF v_user_id IS NULL THEN
    RAISE EXCEPTION 'Not authenticated';
  END IF;
  IF p_vote NOT IN ('for', 'against') THEN
    RAISE EXCEPTION 'Invalid vote value';
  END IF;

  SELECT vote INTO v_old_vote
    FROM proposal_votes
    WHERE proposal_id = p_proposal_id AND user_id = v_user_id;

  IF v_old_vote = p_vote THEN
    RETURN; -- no change needed
  END IF;

  DELETE FROM proposal_votes
    WHERE proposal_id = p_proposal_id AND user_id = v_user_id;

  INSERT INTO proposal_votes (proposal_id, user_id, vote)
    VALUES (p_proposal_id, v_user_id, p_vote);

  -- Update denormalized counts on proposals
  UPDATE proposals SET
    votes_for = (SELECT count(*) FROM proposal_votes WHERE proposal_id = p_proposal_id AND vote = 'for'),
    votes_against = (SELECT count(*) FROM proposal_votes WHERE proposal_id = p_proposal_id AND vote = 'against')
  WHERE id = p_proposal_id;
END;
$$;

-- =============================================================
-- get_wallet_balance: server-side aggregate
-- =============================================================
CREATE OR REPLACE FUNCTION get_wallet_balance(p_citizen_id uuid)
RETURNS integer
LANGUAGE sql
SECURITY DEFINER
AS $$
  SELECT COALESCE(SUM(CASE WHEN type = 'credit' THEN amount ELSE -amount END), 0)::integer
  FROM wallet_transactions
  WHERE citizen_id = p_citizen_id;
$$;

-- =============================================================
-- Add messages to realtime publication
-- =============================================================
ALTER PUBLICATION supabase_realtime ADD TABLE messages;
