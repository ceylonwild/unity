/*
# Media storage bucket for post videos and platform media

## Summary
Creates a public `media` storage bucket for:
- Post video uploads (from Composer)
- Platform media uploads (from Admin Media tab)

## Security
- SELECT (read): public — anyone can read media
- INSERT: authenticated users can upload to their own paths
- UPDATE/DELETE: owners can manage their own uploads; admins can manage all
*/

INSERT INTO storage.buckets (id, name, public)
VALUES ('media', 'media', true)
ON CONFLICT (id) DO NOTHING;

DROP POLICY IF EXISTS "read_media" ON storage.objects;
CREATE POLICY "read_media" ON storage.objects FOR SELECT
  TO anon, authenticated USING (bucket_id = 'media');

DROP POLICY IF EXISTS "insert_own_media" ON storage.objects;
CREATE POLICY "insert_own_media" ON storage.objects FOR INSERT
  TO authenticated WITH CHECK (
    bucket_id = 'media'
    AND auth.uid() = owner
  );

DROP POLICY IF EXISTS "update_own_media" ON storage.objects;
CREATE POLICY "update_own_media" ON storage.objects FOR UPDATE
  TO authenticated USING (
    bucket_id = 'media'
    AND (auth.uid() = owner OR EXISTS (SELECT 1 FROM citizens WHERE citizens.user_id = auth.uid() AND citizens.is_admin = true))
  );

DROP POLICY IF EXISTS "delete_own_media" ON storage.objects;
CREATE POLICY "delete_own_media" ON storage.objects FOR DELETE
  TO authenticated USING (
    bucket_id = 'media'
    AND (auth.uid() = owner OR EXISTS (SELECT 1 FROM citizens WHERE citizens.user_id = auth.uid() AND citizens.is_admin = true))
  );
