/*
# Notification Likes Preference + Messages + Privacy Settings

## Summary
1. Adds `likes` column to `notification_preferences` table.
2. Creates `messages` table for cross-device direct messages.
3. Creates `citizen_privacy` table for per-user privacy settings.

## 1. notification_preferences — new column
- `likes` (bool, default true) — notifications when someone likes the user's post.

## 2. New Table: messages
- `id` (uuid, PK)
- `sender_id` (uuid, NOT NULL, references auth.users) — who sent
- `recipient_id` (uuid, NOT NULL, references auth.users) — who receives
- `content` (text, NOT NULL) — message body
- `read` (bool, default false) — read status
- `created_at` (timestamptz, default now())
- Index on recipient_id for inbox queries.
- RLS: authenticated users can SELECT/INSERT/UPDATE(read flag)/DELETE their own messages
  (where they are sender OR recipient).

## 3. New Table: citizen_privacy
- `user_id` (uuid, PK, references auth.users) — owner
- `profile_visible` (bool, default true) — public profile
- `show_online_status` (bool, default true) — activity indicator
- `allow_tagging` (bool, default true) — can others tag them
- `updated_at` (timestamptz, default now())
- RLS: owner-scoped CRUD (authenticated only).

## Security
- messages: RLS enabled — users can only access messages where they are sender or recipient.
- citizen_privacy: RLS enabled — owner-scoped CRUD.
- All safe to re-run.
*/

-- 1. Add likes column to notification_preferences
DO $$ BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'notification_preferences' AND column_name = 'likes'
  ) THEN
    ALTER TABLE notification_preferences ADD COLUMN likes boolean NOT NULL DEFAULT true;
  END IF;
END $$;

-- 2. messages table
CREATE TABLE IF NOT EXISTS messages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  sender_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  recipient_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  content text NOT NULL,
  read boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE messages ENABLE ROW LEVEL SECURITY;

CREATE INDEX IF NOT EXISTS idx_messages_recipient ON messages(recipient_id);
CREATE INDEX IF NOT EXISTS idx_messages_sender ON messages(sender_id);

DROP POLICY IF EXISTS "select_own_messages" ON messages;
CREATE POLICY "select_own_messages" ON messages FOR SELECT
  TO authenticated USING (auth.uid() = sender_id OR auth.uid() = recipient_id);

DROP POLICY IF EXISTS "insert_own_messages" ON messages;
CREATE POLICY "insert_own_messages" ON messages FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = sender_id);

DROP POLICY IF EXISTS "update_own_messages" ON messages;
CREATE POLICY "update_own_messages" ON messages FOR UPDATE
  TO authenticated USING (auth.uid() = recipient_id) WITH CHECK (auth.uid() = recipient_id);

DROP POLICY IF EXISTS "delete_own_messages" ON messages;
CREATE POLICY "delete_own_messages" ON messages FOR DELETE
  TO authenticated USING (auth.uid() = sender_id OR auth.uid() = recipient_id);

-- 3. citizen_privacy table
CREATE TABLE IF NOT EXISTS citizen_privacy (
  user_id uuid PRIMARY KEY DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  profile_visible boolean NOT NULL DEFAULT true,
  show_online_status boolean NOT NULL DEFAULT true,
  allow_tagging boolean NOT NULL DEFAULT true,
  updated_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE citizen_privacy ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_own_privacy" ON citizen_privacy;
CREATE POLICY "select_own_privacy" ON citizen_privacy FOR SELECT
  TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "insert_own_privacy" ON citizen_privacy;
CREATE POLICY "insert_own_privacy" ON citizen_privacy FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "update_own_privacy" ON citizen_privacy;
CREATE POLICY "update_own_privacy" ON citizen_privacy FOR UPDATE
  TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "delete_own_privacy" ON citizen_privacy;
CREATE POLICY "delete_own_privacy" ON citizen_privacy FOR DELETE
  TO authenticated USING (auth.uid() = user_id);
