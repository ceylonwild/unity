/*
# UNITY Auth & Social Graph Migration

1. Purpose
   Converts UNITY from a single-tenant no-auth demo into a real authenticated
   multi-user global social network. Links citizen profiles to Supabase auth
   accounts, adds an admin role, profile banners, and a real social graph
   (likes, saves, follows) with ownership-scoped Row Level Security.
   Also enables Postgres realtime on the core social tables so the Home feed
   and comment threads update live.

2. Modified Tables
   - `citizens`
     - `user_id` (uuid, nullable, REFERENCES auth.users ON DELETE CASCADE, UNIQUE)
       — links a citizen profile to its Supabase auth account. Legacy demo rows
       keep NULL (read-only). New signups populate it from the session.
     - `is_admin` (boolean, default false) — gates the hidden admin panel.
     - `banner_url` (text, nullable) — profile banner image.
   - `posts` (RLS tightened from public to authenticated + ownership)
   - `comments` (RLS tightened from public to authenticated + ownership)

3. New Tables
   - `post_likes` (post_id, user_id) — many-to-many likes. PK on both columns.
   - `post_saves` (post_id, user_id) — many-to-many saves/bookmarks.
   - `follows` (follower_id, following_id) — social graph edges.

4. Triggers
   - `set_first_admin` — the first citizen created after this migration whose
     is_admin is not explicitly set becomes the sole administrator. Guarantees
     exactly one admin account exists ("only one administrator account").
   - `recount_post_likes` / `recount_post_saves` — maintain denormalized
     likes_count / saves_count on posts from the join tables, race-safe.

5. Security (RLS)
   This app now has a sign-in screen, so policies are scoped TO authenticated.
   SELECT is intentionally broad on social tables (global feed / directory):
   every signed-in citizen sees every post, profile, comment, like, and follow.
   Writes are ownership-scoped:
   - citizens: INSERT only owner; UPDATE only owner (admin can update any).
   - posts: INSERT/UPDATE/DELETE only the author (admin can delete any).
   - comments: INSERT/DELETE only the author (admin can delete any).
   - post_likes / post_saves: INSERT/DELETE only the acting user.
   - follows: INSERT/DELETE only the follower.
   Admin override uses a subquery against citizens.is_admin.

6. Realtime
   Adds posts, comments, post_likes, post_saves to the supabase_realtime
   publication so the frontend can subscribe to live feed updates.

7. Notes
   - Additive only; no columns dropped or renamed, no data deleted.
   - Legacy citizen rows (pre-auth demo data) remain with user_id NULL and
     appear in the directory as read-only legacy profiles.
   - Safe to re-run (idempotent column additions, drop-then-create policies).
*/

-- ---------------------------------------------------------------------------
-- Column additions on citizens
-- ---------------------------------------------------------------------------
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'citizens' AND column_name = 'user_id'
  ) THEN
    ALTER TABLE citizens ADD COLUMN user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE;
  END IF;
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'citizens' AND column_name = 'is_admin'
  ) THEN
    ALTER TABLE citizens ADD COLUMN is_admin boolean NOT NULL DEFAULT false;
  END IF;
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'citizens' AND column_name = 'banner_url'
  ) THEN
    ALTER TABLE citizens ADD COLUMN banner_url text;
  END IF;
END $$;

CREATE UNIQUE INDEX IF NOT EXISTS idx_citizens_user_id ON citizens (user_id) WHERE user_id IS NOT NULL;

-- ---------------------------------------------------------------------------
-- New tables: likes, saves, follows
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS post_likes (
  post_id uuid NOT NULL REFERENCES posts(id) ON DELETE CASCADE,
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  created_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (post_id, user_id)
);

CREATE TABLE IF NOT EXISTS post_saves (
  post_id uuid NOT NULL REFERENCES posts(id) ON DELETE CASCADE,
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  created_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (post_id, user_id)
);

CREATE TABLE IF NOT EXISTS follows (
  follower_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  following_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  created_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (follower_id, following_id),
  CHECK (follower_id <> following_id)
);

CREATE INDEX IF NOT EXISTS idx_post_likes_post ON post_likes (post_id);
CREATE INDEX IF NOT EXISTS idx_post_likes_user ON post_likes (user_id);
CREATE INDEX IF NOT EXISTS idx_post_saves_post ON post_saves (post_id);
CREATE INDEX IF NOT EXISTS idx_post_saves_user ON post_saves (user_id);
CREATE INDEX IF NOT EXISTS idx_follows_follower ON follows (follower_id);
CREATE INDEX IF NOT EXISTS idx_follows_following ON follows (following_id);

-- ---------------------------------------------------------------------------
-- Admin: first citizen created post-migration becomes the sole admin
-- ---------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION set_first_admin()
RETURNS trigger AS $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM citizens WHERE is_admin = true) THEN
    NEW.is_admin := true;
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS citizens_first_admin ON citizens;
CREATE TRIGGER citizens_first_admin
  BEFORE INSERT ON citizens
  FOR EACH ROW
  WHEN (NEW.is_admin = false)
  EXECUTE FUNCTION set_first_admin();

-- ---------------------------------------------------------------------------
-- Counter triggers: keep likes_count / saves_count in sync with join tables
-- ---------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION recount_post_likes()
RETURNS trigger AS $$
BEGIN
  UPDATE posts
  SET likes_count = (SELECT COUNT(*) FROM post_likes WHERE post_id = COALESCE(NEW.post_id, OLD.post_id))
  WHERE id = COALESCE(NEW.post_id, OLD.post_id);
  RETURN NULL;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS post_likes_recount ON post_likes;
CREATE TRIGGER post_likes_recount
  AFTER INSERT OR DELETE ON post_likes
  FOR EACH ROW EXECUTE FUNCTION recount_post_likes();

CREATE OR REPLACE FUNCTION recount_post_saves()
RETURNS trigger AS $$
BEGIN
  UPDATE posts
  SET saves_count = (SELECT COUNT(*) FROM post_saves WHERE post_id = COALESCE(NEW.post_id, OLD.post_id))
  WHERE id = COALESCE(NEW.post_id, OLD.post_id);
  RETURN NULL;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS post_saves_recount ON post_saves;
CREATE TRIGGER post_saves_recount
  AFTER INSERT OR DELETE ON post_saves
  FOR EACH ROW EXECUTE FUNCTION recount_post_saves();

-- ---------------------------------------------------------------------------
-- Realtime publication
-- ---------------------------------------------------------------------------
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_publication_tables
    WHERE pubname = 'supabase_realtime' AND tablename = 'posts'
  ) THEN
    ALTER PUBLICATION supabase_realtime ADD TABLE posts;
  END IF;
  IF NOT EXISTS (
    SELECT 1 FROM pg_publication_tables
    WHERE pubname = 'supabase_realtime' AND tablename = 'comments'
  ) THEN
    ALTER PUBLICATION supabase_realtime ADD TABLE comments;
  END IF;
  IF NOT EXISTS (
    SELECT 1 FROM pg_publication_tables
    WHERE pubname = 'supabase_realtime' AND tablename = 'post_likes'
  ) THEN
    ALTER PUBLICATION supabase_realtime ADD TABLE post_likes;
  END IF;
  IF NOT EXISTS (
    SELECT 1 FROM pg_publication_tables
    WHERE pubname = 'supabase_realtime' AND tablename = 'post_saves'
  ) THEN
    ALTER PUBLICATION supabase_realtime ADD TABLE post_saves;
  END IF;
END $$;

-- ---------------------------------------------------------------------------
-- RLS: tighten everything to authenticated + ownership
-- ---------------------------------------------------------------------------

-- citizens: public directory read for all signed-in users; self-writes + admin
DROP POLICY IF EXISTS "anon_select_citizens" ON citizens;
DROP POLICY IF EXISTS "anon_insert_citizens" ON citizens;
DROP POLICY IF EXISTS "anon_update_citizens" ON citizens;
DROP POLICY IF EXISTS "select_citizens" ON citizens;
DROP POLICY IF EXISTS "insert_own_citizen" ON citizens;
DROP POLICY IF EXISTS "update_own_citizen" ON citizens;

CREATE POLICY "select_citizens" ON citizens FOR SELECT
  TO authenticated USING (true);

CREATE POLICY "insert_own_citizen" ON citizens FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = user_id);

CREATE POLICY "update_own_citizen" ON citizens FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id OR EXISTS (SELECT 1 FROM citizens c WHERE c.user_id = auth.uid() AND c.is_admin = true))
  WITH CHECK (auth.uid() = user_id OR EXISTS (SELECT 1 FROM citizens c WHERE c.user_id = auth.uid() AND c.is_admin = true));

-- posts: global feed read for all signed-in users; author + admin writes
DROP POLICY IF EXISTS "anon_select_posts" ON posts;
DROP POLICY IF EXISTS "anon_insert_posts" ON posts;
DROP POLICY IF EXISTS "anon_update_posts" ON posts;
DROP POLICY IF EXISTS "anon_delete_posts" ON posts;
DROP POLICY IF EXISTS "select_posts" ON posts;
DROP POLICY IF EXISTS "insert_own_posts" ON posts;
DROP POLICY IF EXISTS "update_own_posts" ON posts;
DROP POLICY IF EXISTS "delete_own_posts" ON posts;

CREATE POLICY "select_posts" ON posts FOR SELECT
  TO authenticated USING (true);

CREATE POLICY "insert_own_posts" ON posts FOR INSERT
  TO authenticated WITH CHECK (
    EXISTS (SELECT 1 FROM citizens c WHERE c.id = author_id AND c.user_id = auth.uid())
  );

CREATE POLICY "update_own_posts" ON posts FOR UPDATE
  TO authenticated
  USING (EXISTS (SELECT 1 FROM citizens c WHERE c.id = author_id AND c.user_id = auth.uid()))
  WITH CHECK (EXISTS (SELECT 1 FROM citizens c WHERE c.id = author_id AND c.user_id = auth.uid()));

CREATE POLICY "delete_own_posts" ON posts FOR DELETE
  TO authenticated USING (
    EXISTS (SELECT 1 FROM citizens c WHERE c.id = author_id AND c.user_id = auth.uid())
    OR EXISTS (SELECT 1 FROM citizens c WHERE c.user_id = auth.uid() AND c.is_admin = true)
  );

-- comments: global read; author + admin deletes
DROP POLICY IF EXISTS "anon_select_comments" ON comments;
DROP POLICY IF EXISTS "anon_insert_comments" ON comments;
DROP POLICY IF EXISTS "anon_delete_comments" ON comments;
DROP POLICY IF EXISTS "select_comments" ON comments;
DROP POLICY IF EXISTS "insert_own_comments" ON comments;
DROP POLICY IF EXISTS "delete_own_comments" ON comments;

CREATE POLICY "select_comments" ON comments FOR SELECT
  TO authenticated USING (true);

CREATE POLICY "insert_own_comments" ON comments FOR INSERT
  TO authenticated WITH CHECK (
    EXISTS (SELECT 1 FROM citizens c WHERE c.id = author_id AND c.user_id = auth.uid())
  );

CREATE POLICY "delete_own_comments" ON comments FOR DELETE
  TO authenticated USING (
    EXISTS (SELECT 1 FROM citizens c WHERE c.id = author_id AND c.user_id = auth.uid())
    OR EXISTS (SELECT 1 FROM citizens c WHERE c.user_id = auth.uid() AND c.is_admin = true)
  );

-- post_likes: global read; only the liker can add/remove their own like
ALTER TABLE post_likes ENABLE ROW LEVEL SECURITY;
ALTER TABLE post_saves ENABLE ROW LEVEL SECURITY;
ALTER TABLE follows ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_post_likes" ON post_likes;
DROP POLICY IF EXISTS "insert_own_like" ON post_likes;
DROP POLICY IF EXISTS "delete_own_like" ON post_likes;

CREATE POLICY "select_post_likes" ON post_likes FOR SELECT
  TO authenticated USING (true);
CREATE POLICY "insert_own_like" ON post_likes FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = user_id);
CREATE POLICY "delete_own_like" ON post_likes FOR DELETE
  TO authenticated USING (auth.uid() = user_id);

-- post_saves: global read; only the saver can add/remove their own save
DROP POLICY IF EXISTS "select_post_saves" ON post_saves;
DROP POLICY IF EXISTS "insert_own_save" ON post_saves;
DROP POLICY IF EXISTS "delete_own_save" ON post_saves;

CREATE POLICY "select_post_saves" ON post_saves FOR SELECT
  TO authenticated USING (true);
CREATE POLICY "insert_own_save" ON post_saves FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = user_id);
CREATE POLICY "delete_own_save" ON post_saves FOR DELETE
  TO authenticated USING (auth.uid() = user_id);

-- follows: global read; only the follower can add/remove their own follow
DROP POLICY IF EXISTS "select_follows" ON follows;
DROP POLICY IF EXISTS "insert_own_follow" ON follows;
DROP POLICY IF EXISTS "delete_own_follow" ON follows;

CREATE POLICY "select_follows" ON follows FOR SELECT
  TO authenticated USING (true);
CREATE POLICY "insert_own_follow" ON follows FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = follower_id);
CREATE POLICY "delete_own_follow" ON follows FOR DELETE
  TO authenticated USING (auth.uid() = follower_id);
