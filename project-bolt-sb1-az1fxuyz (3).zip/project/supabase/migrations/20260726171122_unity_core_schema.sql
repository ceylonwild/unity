/*
# UNITY Core Schema — Citizens, Posts, Comments

1. Purpose
   Lays the data foundation for the UNITY global civilization platform.
   Single-tenant (no auth) shared/public data model: any visitor can read
   and contribute to the public social feed and citizen directory.

2. New Tables
   - `citizens` — Digital Citizen Identity profiles.
   - `posts` — Social feed posts.
   - `comments` — Comments on posts.

3. Indexes
   - posts.created_at desc (feed ordering)
   - comments.post_id (comment lookup)
   - citizens.handle unique

4. Security (RLS)
   All tables enable RLS. No-auth, intentionally public/shared platform —
   every policy is TO anon, authenticated with USING(true)/WITH CHECK(true),
   documented as intentional public shared data.
*/

-- Citizens ---------------------------------------------------------------
CREATE TABLE IF NOT EXISTS citizens (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  handle text UNIQUE NOT NULL,
  country text NOT NULL DEFAULT 'Global',
  country_code text NOT NULL DEFAULT 'WO',
  language text NOT NULL DEFAULT 'Universal',
  bio text NOT NULL DEFAULT '',
  skills text[] NOT NULL DEFAULT '{}',
  education text NOT NULL DEFAULT '',
  achievements text[] NOT NULL DEFAULT '{}',
  interests text[] NOT NULL DEFAULT '{}',
  avatar_url text,
  verified boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now()
);

-- Posts ------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS posts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  author_id uuid REFERENCES citizens(id) ON DELETE CASCADE,
  content text NOT NULL,
  image_url text,
  likes_count integer NOT NULL DEFAULT 0,
  comments_count integer NOT NULL DEFAULT 0,
  saves_count integer NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now()
);

-- Comments ---------------------------------------------------------------
CREATE TABLE IF NOT EXISTS comments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  post_id uuid REFERENCES posts(id) ON DELETE CASCADE,
  author_id uuid REFERENCES citizens(id) ON DELETE SET NULL,
  content text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);

-- Indexes ----------------------------------------------------------------
CREATE INDEX IF NOT EXISTS idx_posts_created_at ON posts (created_at DESC);
CREATE INDEX IF NOT EXISTS idx_comments_post_id ON comments (post_id);
CREATE INDEX IF NOT EXISTS idx_citizens_handle ON citizens (handle);

-- RLS --------------------------------------------------------------------
ALTER TABLE citizens ENABLE ROW LEVEL SECURITY;
ALTER TABLE posts ENABLE ROW LEVEL SECURITY;
ALTER TABLE comments ENABLE ROW LEVEL SECURITY;

-- citizens: public shared directory
DROP POLICY IF EXISTS "anon_select_citizens" ON citizens;
CREATE POLICY "anon_select_citizens" ON citizens FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_citizens" ON citizens;
CREATE POLICY "anon_insert_citizens" ON citizens FOR INSERT
  TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_update_citizens" ON citizens;
CREATE POLICY "anon_update_citizens" ON citizens FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);

-- posts: public shared feed
DROP POLICY IF EXISTS "anon_select_posts" ON posts;
CREATE POLICY "anon_select_posts" ON posts FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_posts" ON posts;
CREATE POLICY "anon_insert_posts" ON posts FOR INSERT
  TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_update_posts" ON posts;
CREATE POLICY "anon_update_posts" ON posts FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "anon_delete_posts" ON posts;
CREATE POLICY "anon_delete_posts" ON posts FOR DELETE
  TO anon, authenticated USING (true);

-- comments: public shared
DROP POLICY IF EXISTS "anon_select_comments" ON comments;
CREATE POLICY "anon_select_comments" ON comments FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_comments" ON comments;
CREATE POLICY "anon_insert_comments" ON comments FOR INSERT
  TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_delete_comments" ON comments;
CREATE POLICY "anon_delete_comments" ON comments FOR DELETE
  TO anon, authenticated USING (true);
