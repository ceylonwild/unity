/*
# Add suspended flag to citizens

1. Purpose
   Allows the admin to suspend users — a suspended citizen cannot sign in
   (blocked at the edge function / auth level) and is visually flagged in the
   admin dashboard.

2. Changes
   - citizens: new boolean column `suspended` (default false).

3. Security
   No new policies — existing RLS remains. The column is only writable by the
   admin (enforced at the application layer via is_admin check).

4. Notes
   Additive only; safe to re-run.
*/

ALTER TABLE citizens ADD COLUMN IF NOT EXISTS suspended boolean NOT NULL DEFAULT false;
