/*
# Add INSERT policy to notifications table

## Summary
The notifications table has SELECT, UPDATE, DELETE policies but NO INSERT policy.
This means RLS blocks all notification creation. Since notifications are created
by the application when one user acts on another's content (like, comment, follow),
the sender is not the recipient. We add an INSERT policy that allows any
authenticated user to insert notifications.

## Security
- INSERT policy: any authenticated user can insert. This is necessary because
  notifications are cross-user (user A likes user B's post → notification for B).
  The application controls which notifications get created and checks recipient
  preferences before inserting. Users cannot read other users' notifications
  (SELECT policy is still owner-scoped), so inserting a notification for another
  user merely alerts them — it does not expose any data.
*/

DROP POLICY IF EXISTS "insert_notifications" ON notifications;
CREATE POLICY "insert_notifications" ON notifications FOR INSERT
  TO authenticated WITH CHECK (true);
