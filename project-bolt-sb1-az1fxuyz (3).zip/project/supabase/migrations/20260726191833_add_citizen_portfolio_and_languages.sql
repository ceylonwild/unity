/*
# Extend Citizen Identity with portfolio links and secondary languages

1. Purpose
   Restores full Citizen ID data architecture by adding two new attributes
   to the existing `citizens` table: a portfolio links list (text array) and
   a secondary/primary languages list (text array).

2. Modified Tables
   - `citizens`
     - `portfolio_links` (text[], default '{}') — list of URLs to personal
       work, projects, or external profiles.
     - `languages` (text[], default '{}') — the citizen's spoken languages,
       supplementing the existing single-value `language` text column which
       remains as the primary interface language.

3. Security
   - No new tables. RLS already enabled on `citizens` with public
     shared read/write policies (single-tenant, no auth). No policy changes.

4. Notes
   - Additive only — no columns dropped or renamed, no data loss.
   - Both new columns are nullable-via-default arrays so existing rows are
     unaffected.
*/

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'citizens' AND column_name = 'portfolio_links'
  ) THEN
    ALTER TABLE citizens ADD COLUMN portfolio_links text[] NOT NULL DEFAULT '{}';
  END IF;
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'citizens' AND column_name = 'languages'
  ) THEN
    ALTER TABLE citizens ADD COLUMN languages text[] NOT NULL DEFAULT '{}';
  END IF;
END $$;
