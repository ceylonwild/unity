/*
# Notification Preferences + Platform Settings

## Summary
Adds per-user notification preference storage and admin-editable platform settings.

## 1. New Tables
- `notification_preferences` — one row per citizen, stores which notification types the user wants to receive.
  - `user_id` (uuid, PK, references auth.users) — the owner.
  - `followers` (bool, default true) — new follower alerts.
  - `comments` (bool, default true) — comment replies on the user's posts.
  - `governance` (bool, default false) — new governance proposals.
  - `orion` (bool, default true) — ORION AI updates.
  - `missions` (bool, default false) — space mission launches.
  - `announcements` (bool, default true) — platform-wide announcements.
  - `push_enabled` (bool, default true) — master push toggle.
  - `email_enabled` (bool, default false) — master email toggle.
  - `updated_at` (timestamptz) — last change timestamp.

- `platform_settings` — single-row admin-controlled settings table.
  - `id` (int, PK, default 1) — enforced singleton.
  - `site_name` (text, default 'UNITY') — platform display name.
  - `site_description` (text) — meta description.
  - `maintenance_mode` (bool, default false) — if true, shows maintenance banner.
  - `registration_open` (bool, default true) — if false, new signups blocked.
  - `announcement_banner` (text, nullable) — optional banner text shown site-wide.
  - `updated_at` (timestamptz) — last change timestamp.
  - `updated_by` (uuid, nullable, references auth.users) — admin who last changed.

## 2. Security
- `notification_preferences`: RLS enabled, owner-scoped CRUD (authenticated only).
- `platform_settings`: RLS enabled. All authenticated users can SELECT (needed to check maintenance/registration).
  Only admins can UPDATE (enforced by checking citizens.is_admin via JOIN).

## 3. Notes
- Both tables are safe to re-run (IF NOT EXISTS + DROP POLICY IF EXISTS).
- notification_preferences uses DEFAULT auth.uid() so inserts from the client succeed without passing user_id.
*/

-- Notification preferences
CREATE TABLE IF NOT EXISTS notification_preferences (
  user_id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  followers boolean NOT NULL DEFAULT true,
  comments boolean NOT NULL DEFAULT true,
  governance boolean NOT NULL DEFAULT false,
  orion boolean NOT NULL DEFAULT true,
  missions boolean NOT NULL DEFAULT false,
  announcements boolean NOT NULL DEFAULT true,
  push_enabled boolean NOT NULL DEFAULT true,
  email_enabled boolean NOT NULL DEFAULT false,
  updated_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE notification_preferences ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_own_notif_prefs" ON notification_preferences;
CREATE POLICY "select_own_notif_prefs" ON notification_preferences FOR SELECT
  TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "insert_own_notif_prefs" ON notification_preferences;
CREATE POLICY "insert_own_notif_prefs" ON notification_preferences FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "update_own_notif_prefs" ON notification_preferences;
CREATE POLICY "update_own_notif_prefs" ON notification_preferences FOR UPDATE
  TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "delete_own_notif_prefs" ON notification_preferences;
CREATE POLICY "delete_own_notif_prefs" ON notification_preferences FOR DELETE
  TO authenticated USING (auth.uid() = user_id);

-- Platform settings (singleton)
CREATE TABLE IF NOT EXISTS platform_settings (
  id int PRIMARY KEY DEFAULT 1,
  site_name text NOT NULL DEFAULT 'UNITY',
  site_description text NOT NULL DEFAULT 'A digital civilization layer connecting humanity.',
  maintenance_mode boolean NOT NULL DEFAULT false,
  registration_open boolean NOT NULL DEFAULT true,
  announcement_banner text,
  updated_at timestamptz NOT NULL DEFAULT now(),
  updated_by uuid REFERENCES auth.users(id),
  CONSTRAINT singleton CHECK (id = 1)
);

ALTER TABLE platform_settings ENABLE ROW LEVEL SECURITY;

-- All authenticated users can read platform settings
DROP POLICY IF EXISTS "read_platform_settings" ON platform_settings;
CREATE POLICY "read_platform_settings" ON platform_settings FOR SELECT
  TO authenticated USING (true);

-- Only admins can update (check via citizens table)
DROP POLICY IF EXISTS "update_platform_settings" ON platform_settings;
CREATE POLICY "update_platform_settings" ON platform_settings FOR UPDATE
  TO authenticated USING (
    EXISTS (SELECT 1 FROM citizens WHERE citizens.user_id = auth.uid() AND citizens.is_admin = true)
  ) WITH CHECK (
    EXISTS (SELECT 1 FROM citizens WHERE citizens.user_id = auth.uid() AND citizens.is_admin = true)
  );

-- Only admins can insert (for initial row)
DROP POLICY IF EXISTS "insert_platform_settings" ON platform_settings;
CREATE POLICY "insert_platform_settings" ON platform_settings FOR INSERT
  TO authenticated WITH CHECK (
    EXISTS (SELECT 1 FROM citizens WHERE citizens.user_id = auth.uid() AND citizens.is_admin = true)
  );

-- Seed the singleton row if it doesn't exist
INSERT INTO platform_settings (id) VALUES (1) ON CONFLICT (id) DO NOTHING;
