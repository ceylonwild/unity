/*
# UNITY Governance & Wallet tables

1. Purpose
   Adds real Supabase-backed governance (proposals + votes) and wallet
   (transactions + balance) to replace the static demo data.

2. New Tables
   - proposals, proposal_votes, wallet_transactions

3. Triggers
   - recount_proposal_votes maintains denormalized vote counts.

4. Security (RLS)
   - proposals: SELECT global, INSERT/UPDATE own author.
   - proposal_votes: SELECT global, INSERT/DELETE own user.
   - wallet_transactions: SELECT/INSERT own citizen only.
*/

CREATE TABLE IF NOT EXISTS proposals (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  author_id uuid NOT NULL REFERENCES citizens(id) ON DELETE CASCADE,
  title text NOT NULL,
  description text NOT NULL DEFAULT '',
  status text NOT NULL DEFAULT 'active',
  votes_for integer NOT NULL DEFAULT 0,
  votes_against integer NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_proposals_created ON proposals (created_at DESC);
ALTER TABLE proposals ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_proposals" ON proposals;
CREATE POLICY "select_proposals" ON proposals FOR SELECT TO authenticated USING (true);
DROP POLICY IF EXISTS "insert_own_proposals" ON proposals;
CREATE POLICY "insert_own_proposals" ON proposals FOR INSERT TO authenticated WITH CHECK (EXISTS (SELECT 1 FROM citizens c WHERE c.id = author_id AND c.user_id = auth.uid()));
DROP POLICY IF EXISTS "update_own_proposals" ON proposals;
CREATE POLICY "update_own_proposals" ON proposals FOR UPDATE TO authenticated USING (EXISTS (SELECT 1 FROM citizens c WHERE c.id = author_id AND c.user_id = auth.uid())) WITH CHECK (EXISTS (SELECT 1 FROM citizens c WHERE c.id = author_id AND c.user_id = auth.uid()));

CREATE TABLE IF NOT EXISTS proposal_votes (
  proposal_id uuid NOT NULL REFERENCES proposals(id) ON DELETE CASCADE,
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  vote text NOT NULL DEFAULT 'for',
  created_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (proposal_id, user_id),
  CHECK (vote IN ('for', 'against'))
);
ALTER TABLE proposal_votes ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_proposal_votes" ON proposal_votes;
CREATE POLICY "select_proposal_votes" ON proposal_votes FOR SELECT TO authenticated USING (true);
DROP POLICY IF EXISTS "insert_own_vote" ON proposal_votes;
CREATE POLICY "insert_own_vote" ON proposal_votes FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);
DROP POLICY IF EXISTS "delete_own_vote" ON proposal_votes;
CREATE POLICY "delete_own_vote" ON proposal_votes FOR DELETE TO authenticated USING (auth.uid() = user_id);

CREATE OR REPLACE FUNCTION recount_proposal_votes() RETURNS trigger AS $$
BEGIN
  UPDATE proposals SET
    votes_for = (SELECT COUNT(*) FROM proposal_votes WHERE proposal_id = COALESCE(NEW.proposal_id, OLD.proposal_id) AND vote = 'for'),
    votes_against = (SELECT COUNT(*) FROM proposal_votes WHERE proposal_id = COALESCE(NEW.proposal_id, OLD.proposal_id) AND vote = 'against')
  WHERE id = COALESCE(NEW.proposal_id, OLD.proposal_id);
  RETURN NULL;
END;
$$ LANGUAGE plpgsql;
DROP TRIGGER IF EXISTS proposal_votes_recount ON proposal_votes;
CREATE TRIGGER proposal_votes_recount AFTER INSERT OR DELETE ON proposal_votes FOR EACH ROW EXECUTE FUNCTION recount_proposal_votes();

CREATE TABLE IF NOT EXISTS wallet_transactions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  citizen_id uuid NOT NULL REFERENCES citizens(id) ON DELETE CASCADE,
  type text NOT NULL DEFAULT 'credit',
  amount integer NOT NULL DEFAULT 0,
  counterparty text NOT NULL DEFAULT '',
  description text NOT NULL DEFAULT '',
  created_at timestamptz NOT NULL DEFAULT now(),
  CHECK (type IN ('credit', 'debit'))
);
CREATE INDEX IF NOT EXISTS idx_wallet_txn_citizen ON wallet_transactions (citizen_id, created_at DESC);
ALTER TABLE wallet_transactions ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_own_wallet" ON wallet_transactions;
CREATE POLICY "select_own_wallet" ON wallet_transactions FOR SELECT TO authenticated USING (EXISTS (SELECT 1 FROM citizens c WHERE c.id = citizen_id AND c.user_id = auth.uid()));
DROP POLICY IF EXISTS "insert_own_wallet" ON wallet_transactions;
CREATE POLICY "insert_own_wallet" ON wallet_transactions FOR INSERT TO authenticated WITH CHECK (EXISTS (SELECT 1 FROM citizens c WHERE c.id = citizen_id AND c.user_id = auth.uid()));
DROP POLICY IF EXISTS "delete_own_wallet" ON wallet_transactions;
CREATE POLICY "delete_own_wallet" ON wallet_transactions FOR DELETE TO authenticated USING (EXISTS (SELECT 1 FROM citizens c WHERE c.id = citizen_id AND c.user_id = auth.uid()));

DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_publication_tables WHERE pubname = 'supabase_realtime' AND tablename = 'proposals') THEN ALTER PUBLICATION supabase_realtime ADD TABLE proposals; END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_publication_tables WHERE pubname = 'supabase_realtime' AND tablename = 'proposal_votes') THEN ALTER PUBLICATION supabase_realtime ADD TABLE proposal_votes; END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_publication_tables WHERE pubname = 'supabase_realtime' AND tablename = 'wallet_transactions') THEN ALTER PUBLICATION supabase_realtime ADD TABLE wallet_transactions; END IF;
END $$;
