/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        // UNITY premium dark palette
        ink: {
          950: '#000000',
          900: '#050505',
          850: '#0a0a0b',
          800: '#0f0f10',
          700: '#161618',
          600: '#1c1c1f',
          500: '#242428',
          400: '#2e2e33',
          300: '#3a3a40',
        },
        glass: {
          50: 'rgba(255,255,255,0.04)',
          100: 'rgba(255,255,255,0.06)',
          200: 'rgba(255,255,255,0.08)',
          300: 'rgba(255,255,255,0.12)',
        },
        orion: {
          400: '#e8e8ee',
          500: '#c7c7d1',
        },
      },
      fontFamily: {
        sans: ['Inter', 'system-ui', '-apple-system', 'sans-serif'],
      },
      fontSize: {
        '2xs': ['0.6875rem', { lineHeight: '1rem' }],
      },
      letterSpacing: {
        'tightest': '-0.04em',
      },
      animation: {
        'fade-in': 'fadeIn 0.4s ease-out both',
        'fade-up': 'fadeUp 0.5s cubic-bezier(0.22, 1, 0.36, 1) both',
        'scale-in': 'scaleIn 0.3s cubic-bezier(0.22, 1, 0.36, 1) both',
      },
    },
  },
  plugins: [],
};
